// app/dashboard/invoices/page.tsx
'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { FileText, Download, AlertCircle, CheckCircle, Clock, XCircle } from 'lucide-react';
import toast from 'react-hot-toast';

export default function InvoicesPage() {
  const [invoices, setInvoices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);

  const token = typeof window !== 'undefined' ? localStorage.getItem('hci_token') : null;
  const headers = token ? { Authorization: `Bearer ${token}` } : {};

  useEffect(() => { loadInvoices(); }, []);

  const loadInvoices = async () => {
    try {
      const res = await fetch('/api/invoices?limit=50', { headers, credentials: 'include' });
      const data = await res.json();
      setInvoices(data.invoices || []);
      setTotal(data.total || 0);
    } catch { toast.error('Failed to load invoices'); }
    finally { setLoading(false); }
  };

  const statusIcon = (status: string) => {
    switch (status) {
      case 'paid': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'pending': return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'failed': return <XCircle className="w-4 h-4 text-red-500" />;
      default: return <AlertCircle className="w-4 h-4 text-gray-400" />;
    }
  };

  const totalPaid = invoices.filter(i => i.status === 'paid').reduce((s, i) => s + (i.total_amount || 0), 0);
  const totalPending = invoices.filter(i => i.status === 'pending').reduce((s, i) => s + (i.total_amount || 0), 0);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-5xl mx-auto px-6 py-10">
        <div className="mb-6">
          <Link href="/dashboard" className="text-sm text-gray-500 hover:text-gray-700">← Dashboard</Link>
          <h1 className="text-2xl font-bold text-gray-900 mt-3">Invoices</h1>
          <p className="text-sm text-gray-500 mt-1">Automatically generated every 31 minutes of usage + subscriptions.</p>
        </div>

        {/* Summary cards */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <div className="text-xs text-gray-500 mb-1">Total Invoices</div>
            <div className="text-2xl font-black text-gray-900">{total}</div>
          </div>
          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <div className="text-xs text-gray-500 mb-1">Total Paid</div>
            <div className="text-2xl font-black text-green-700">€{totalPaid.toFixed(2)}</div>
          </div>
          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <div className="text-xs text-gray-500 mb-1">Pending</div>
            <div className="text-2xl font-black text-yellow-700">€{totalPending.toFixed(2)}</div>
          </div>
        </div>

        {/* Invoices table */}
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
          {loading ? (
            <div className="flex items-center justify-center h-40">
              <div className="w-6 h-6 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
            </div>
          ) : invoices.length === 0 ? (
            <div className="text-center py-16 text-gray-400">
              <FileText className="w-10 h-10 mx-auto mb-3 opacity-50" />
              <p className="font-medium">No invoices yet</p>
              <p className="text-sm mt-1">Invoices are generated automatically every 31 minutes of active use.</p>
            </div>
          ) : (
            <table className="w-full data-table">
              <thead>
                <tr>
                  <th>Invoice #</th>
                  <th>Period</th>
                  <th>Minutes</th>
                  <th>Amount</th>
                  <th>Status</th>
                  <th>Date</th>
                  <th>PDF</th>
                </tr>
              </thead>
              <tbody>
                {invoices.map((inv: any) => (
                  <tr key={inv.id}>
                    <td className="font-mono text-xs font-semibold text-blue-700">{inv.invoice_number}</td>
                    <td className="text-xs text-gray-500">
                      {inv.period_start ? new Date(inv.period_start).toLocaleDateString() : '—'}
                      {' → '}
                      {inv.period_end ? new Date(inv.period_end).toLocaleDateString() : '—'}
                    </td>
                    <td className="text-right">{inv.minutes_used ? `${parseFloat(inv.minutes_used).toFixed(1)} min` : '—'}</td>
                    <td className="font-bold">{inv.currency} {parseFloat(inv.total_amount || 0).toFixed(2)}</td>
                    <td>
                      <div className="flex items-center gap-1.5">
                        {statusIcon(inv.status)}
                        <span className={`text-xs font-medium capitalize ${
                          inv.status === 'paid' ? 'text-green-700' :
                          inv.status === 'failed' ? 'text-red-700' :
                          inv.status === 'pending' ? 'text-yellow-700' : 'text-gray-600'
                        }`}>{inv.status}</span>
                      </div>
                    </td>
                    <td className="text-xs text-gray-400">{new Date(inv.created_at).toLocaleString()}</td>
                    <td>
                      {inv.pdf_url ? (
                        <a href={inv.pdf_url} target="_blank" rel="noreferrer"
                          className="flex items-center gap-1 text-xs text-blue-600 hover:text-blue-800 font-medium">
                          <Download className="w-3.5 h-3.5" /> PDF
                        </a>
                      ) : (
                        <span className="text-xs text-gray-300">—</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
