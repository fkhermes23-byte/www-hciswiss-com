// app/api/admin/stats/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { requireAdmin } from '@/backend/auth/auth';
import { supabaseAdmin } from '@/backend/lib/db';

export async function GET(req: NextRequest) {
  try {
    await requireAdmin(req);
    const now = new Date();
    const dayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
    const hourAgo = new Date(now.getTime() - 60 * 60 * 1000).toISOString();

    // Total users
    const { count: totalUsers } = await supabaseAdmin
      .from('users').select('*', { count: 'exact', head: true });

    // Active users
    const { count: activeUsers } = await supabaseAdmin
      .from('users').select('*', { count: 'exact', head: true })
      .eq('account_status', 'active');

    // Suspended users
    const { count: suspendedUsers } = await supabaseAdmin
      .from('users').select('*', { count: 'exact', head: true })
      .eq('account_status', 'suspended');

    // Currently active sessions
    const { count: activeSessions } = await supabaseAdmin
      .from('usage_sessions').select('*', { count: 'exact', head: true })
      .is('end_time', null);

    // Revenue today
    const { data: revenueToday } = await supabaseAdmin
      .from('invoices')
      .select('total_amount')
      .eq('status', 'paid')
      .gte('paid_at', dayStart);

    const todayRevenue = (revenueToday || []).reduce((sum, i) => sum + (i.total_amount || 0), 0);

    // Revenue this month
    const { data: revenueMonth } = await supabaseAdmin
      .from('invoices')
      .select('total_amount')
      .eq('status', 'paid')
      .gte('paid_at', monthStart);

    const monthRevenue = (revenueMonth || []).reduce((sum, i) => sum + (i.total_amount || 0), 0);

    // Revenue last hour
    const { data: revenueHour } = await supabaseAdmin
      .from('invoices')
      .select('total_amount')
      .eq('status', 'paid')
      .gte('paid_at', hourAgo);

    const hourRevenue = (revenueHour || []).reduce((sum, i) => sum + (i.total_amount || 0), 0);

    // Revenue per minute (based on active sessions)
    const { data: activeSess } = await supabaseAdmin
      .from('usage_sessions')
      .select('price_per_minute')
      .is('end_time', null);

    const revenuePerMinute = (activeSess || []).reduce((sum, s) => sum + (s.price_per_minute || 0), 0);

    // Total all-time revenue
    const { data: allRevenue } = await supabaseAdmin
      .from('invoices')
      .select('total_amount')
      .eq('status', 'paid');

    const totalRevenue = (allRevenue || []).reduce((sum, i) => sum + (i.total_amount || 0), 0);

    // Recent invoices
    const { data: recentInvoices } = await supabaseAdmin
      .from('invoices')
      .select('*, users(email, role)')
      .order('created_at', { ascending: false })
      .limit(10);

    // Users by role
    const { data: usersByRole } = await supabaseAdmin
      .from('users')
      .select('role')
      .neq('role', 'admin');

    const roleCount = (usersByRole || []).reduce((acc: any, u) => {
      acc[u.role] = (acc[u.role] || 0) + 1;
      return acc;
    }, {});

    // Revenue by day (last 30 days)
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
    const { data: dailyRevenue } = await supabaseAdmin
      .from('invoices')
      .select('total_amount, paid_at')
      .eq('status', 'paid')
      .gte('paid_at', thirtyDaysAgo)
      .order('paid_at', { ascending: true });

    // Group by day
    const revenueByDay: Record<string, number> = {};
    for (const inv of dailyRevenue || []) {
      const day = inv.paid_at.substring(0, 10);
      revenueByDay[day] = (revenueByDay[day] || 0) + inv.total_amount;
    }

    return NextResponse.json({
      users: { total: totalUsers, active: activeUsers, suspended: suspendedUsers },
      activeSessions,
      revenue: {
        perMinute: Math.round(revenuePerMinute * 1000) / 1000,
        perHour: Math.round(hourRevenue * 100) / 100,
        today: Math.round(todayRevenue * 100) / 100,
        thisMonth: Math.round(monthRevenue * 100) / 100,
        total: Math.round(totalRevenue * 100) / 100,
      },
      usersByRole: roleCount,
      recentInvoices: recentInvoices || [],
      dailyRevenue: revenueByDay,
    });

  } catch (err: any) {
    if (err.message === 'UNAUTHORIZED') return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (err.message === 'FORBIDDEN') return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
