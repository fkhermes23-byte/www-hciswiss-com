// lib/db.ts - Supabase client + direct PostgreSQL connection
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

// Service role client (backend only - full access)
export const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
});

// Public client (frontend)
export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Generic query wrapper with error handling
export async function dbQuery<T = any>(
  table: string,
  query: (client: typeof supabaseAdmin) => Promise<{ data: T | null; error: any }>
): Promise<T> {
  const { data, error } = await query(supabaseAdmin);
  if (error) {
    console.error(`DB Error [${table}]:`, error);
    throw new Error(error.message || 'Database error');
  }
  return data as T;
}

// Raw SQL execution
export async function rawQuery(sql: string, params?: any[]) {
  const { data, error } = await supabaseAdmin.rpc('exec_sql', {
    query: sql,
    params: params || [],
  });
  if (error) throw new Error(error.message);
  return data;
}

export default supabaseAdmin;
