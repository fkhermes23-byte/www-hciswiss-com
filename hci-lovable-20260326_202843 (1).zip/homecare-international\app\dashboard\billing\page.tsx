// app/dashboard/billing/page.tsx
'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { CreditCard, CheckCircle, AlertTriangle, Shield, Zap, Calendar, Bitcoin } from 'lucide-react';
import toast from 'react-hot-toast';

const SUBSCRIPTION_PLANS = [
  { id: 'daily', label: 'Daily', price: { private: 3.60, professional: 7.20, enterprise: 10.80 }, desc: '24h access' },
  { id: 'weekly', label: 'Weekly', price: { private: 21.00, professional: 42.00, enterprise: 63.00 }, desc: '7 days access' },
  { id: 'monthly', label: 'Monthly', price: { private: 72.00, professional: 144.00, enterprise: 216.00 }, desc: '30 days access', popular: true },
  { id: 'annual', label: 'Annual', price: { private: 720.00, professional: 1440.00, enterprise: 2160.00 }, desc: '365 days — 2 months free' },
];

const PAYMENT_PROVIDERS = [
  { id: 'stripe', label: 'Credit / Debit Card', icon: CreditCard, desc: 'Visa, Mastercard, American Express' },
  { id: 'paypal', label: 'PayPal', icon: Zap, desc: 'PayPal account or card' },
  { id: 'crypto', label: 'Cryptocurrency', icon: Bitcoin, desc: 'BTC, ETH, USDT, USDC, SOL' },
];

export default function BillingPage() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [selectedPlan, setSelectedPlan] = useState('monthly');
  const [selectedProvider, setSelectedProvider] = useState('stripe');
  const [paymentMethods, setPaymentMethods] = useState<any[]>([]);
  const [setupLoading, setSetupLoading] = useState(false);

  const token = typeof window !== 'undefined' ? localStorage.getItem('hci_token') : null;
  const headers: Record<string, string> = token ? { Authorization: `Bearer ${token}` } : {};

  useEffect(() => {
    loadBillingData();
  }, []);

  const loadBillingData = async () => {
    try {
      const [userRes, methodsRes] = await Promise.all([
        fetch('/api/user', { headers, credentials: 'include' }),
        fetch('/api/payments/setup', { headers, credentials: 'include' }),
      ]);
      const userData = await userRes.json();
      const methodsData = await methodsRes.json();
      setUser(userData.user);
      setPaymentMethods(methodsData.paymentMethods || []);
    } catch {
      toast.error('Failed to load billing data');
    } finally {
      setLoading(false);
    }
  };

  const handleAddCard = async () => {
    setSetupLoading(true);
    try {
      const res = await fetch('/api/payments/setup', {
        method: 'POST',
        headers,
        credentials: 'include',
      });
      const data = await res.json();
      if (data.clientSecret) {
        // In production: use Stripe.js Elements with this clientSecret
        toast.success('Stripe setup initialized. In production: Stripe Elements form opens here.');
      }
    } catch {
      toast.error('Failed to initialize payment setup');
    } finally {
      setSetupLoading(false);
    }
  };

  const handlePayPalSetup = async () => {
    toast('PayPal: Redirect to PayPal authorization page (production)');
  };

  const handleCryptoPayment = async () => {
    try {
      const res = await fetch('/api/payments/crypto', {
        method: 'POST',
        headers: { ...headers, 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ plan: selectedPlan }),
      });
      const data = await res.json();
      if (data.hostedUrl) window.open(data.hostedUrl, '_blank');
    } catch {
      toast.error('Crypto payment initialization failed');
    }
  };

  const planPrice = (plan: any) => {
    const role = user?.role || 'private';
    return plan.price[role] || plan.price.private;
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-6 py-10">
        <div className="mb-8">
          <Link href="/dashboard" className="text-sm text-gray-500 hover:text-gray-700">← Back to Dashboard</Link>
          <h1 className="text-2xl font-bold text-gray-900 mt-3">Billing & Subscriptions</h1>
          <p className="text-gray-500 text-sm mt-1">
            Subscription base + usage-based billing every 31 minutes of active use.
          </p>
        </div>

        {/* Account suspended banner */}
        {user?.account_status === 'suspended' && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-4 mb-6 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-red-800">Account Suspended</p>
              <p className="text-sm text-red-600 mt-1">Your account was suspended due to a failed payment. Add a payment method to reactivate.</p>
            </div>
          </div>
        )}

        {/* Billing model explanation */}
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
          <div className="flex items-start gap-3">
            <Shield className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-blue-800 text-sm">How billing works</p>
              <ul className="text-sm text-blue-700 mt-2 space-y-1">
                <li>• <strong>Subscription</strong>: flat fee for base access (daily / weekly / monthly / annual)</li>
                <li>• <strong>Usage billing</strong>: every 31 minutes of active use, automatic invoice generated</li>
                <li>• <strong>Rate</strong>: {user?.role === 'private' ? '€0.25' : user?.role === 'professional' ? '€0.50' : '€0.75'}/minute ({user?.role || 'private'} account)</li>
                <li>• <strong>Automatic charge</strong>: Stripe / PayPal / Crypto charged automatically</li>
                <li>• <strong>Non-payment</strong>: account suspended immediately, all access blocked</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-6">
          {/* Subscription Plans */}
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h2 className="font-bold text-gray-900 mb-1">Subscription Plan</h2>
            <p className="text-xs text-gray-500 mb-4">Base access fee. Usage billed separately every 31 minutes.</p>
            <div className="space-y-2">
              {SUBSCRIPTION_PLANS.map(plan => (
                <button
                  key={plan.id}
                  onClick={() => setSelectedPlan(plan.id)}
                  className={`w-full flex items-center justify-between p-3 rounded-xl border-2 transition-all ${
                    selectedPlan === plan.id ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${selectedPlan === plan.id ? 'border-blue-500' : 'border-gray-300'}`}>
                      {selectedPlan === plan.id && <div className="w-2 h-2 rounded-full bg-blue-500" />}
                    </div>
                    <div className="text-left">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-sm text-gray-900">{plan.label}</span>
                        {plan.popular && <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full font-medium">Popular</span>}
                      </div>
                      <div className="text-xs text-gray-400">{plan.desc}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-gray-900">€{planPrice(plan).toFixed(2)}</div>
                    <div className="text-xs text-gray-400">{user?.currency || 'EUR'}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Payment Method */}
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h2 className="font-bold text-gray-900 mb-1">Payment Method</h2>
            <p className="text-xs text-gray-500 mb-4">Used for subscription and automatic 31-minute usage invoices.</p>

            {/* Existing payment methods */}
            {paymentMethods.length > 0 && (
              <div className="mb-4 space-y-2">
                {paymentMethods.map((method: any) => (
                  <div key={method.id} className="flex items-center gap-3 p-3 bg-green-50 border border-green-200 rounded-xl">
                    <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0" />
                    <div>
                      <div className="text-sm font-medium text-gray-800 capitalize">
                        {method.card?.brand} •••• {method.card?.last4}
                      </div>
                      <div className="text-xs text-gray-400">
                        Expires {method.card?.exp_month}/{method.card?.exp_year}
                      </div>
                    </div>
                    <span className="ml-auto text-xs text-green-600 font-medium">Active</span>
                  </div>
                ))}
              </div>
            )}

            {/* Provider selection */}
            <div className="space-y-2 mb-4">
              {PAYMENT_PROVIDERS.map(provider => (
                <button
                  key={provider.id}
                  onClick={() => setSelectedProvider(provider.id)}
                  className={`w-full flex items-center gap-3 p-3 rounded-xl border-2 transition-all ${
                    selectedProvider === provider.id ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <provider.icon className={`w-5 h-5 ${selectedProvider === provider.id ? 'text-blue-600' : 'text-gray-400'}`} />
                  <div className="text-left flex-1">
                    <div className="text-sm font-medium text-gray-900">{provider.label}</div>
                    <div className="text-xs text-gray-400">{provider.desc}</div>
                  </div>
                  {selectedProvider === provider.id && <CheckCircle className="w-4 h-4 text-blue-500" />}
                </button>
              ))}
            </div>

            {/* Action button */}
            {selectedProvider === 'stripe' && (
              <button
                onClick={handleAddCard}
                disabled={setupLoading}
                className="w-full bg-blue-600 text-white py-3 rounded-xl font-semibold text-sm hover:bg-blue-700 transition-all disabled:opacity-60"
              >
                {setupLoading ? 'Initializing...' : paymentMethods.length > 0 ? 'Update Card' : 'Add Credit Card'}
              </button>
            )}
            {selectedProvider === 'paypal' && (
              <button
                onClick={handlePayPalSetup}
                className="w-full bg-[#003087] text-white py-3 rounded-xl font-semibold text-sm hover:bg-[#002a75] transition-all"
              >
                Connect PayPal
              </button>
            )}
            {selectedProvider === 'crypto' && (
              <button
                onClick={handleCryptoPayment}
                className="w-full bg-orange-500 text-white py-3 rounded-xl font-semibold text-sm hover:bg-orange-600 transition-all"
              >
                Pay with Crypto (BTC/ETH/USDT/USDC/SOL)
              </button>
            )}

            <p className="text-xs text-gray-400 text-center mt-3">
              <Shield className="w-3 h-3 inline mr-1" />
              Payments secured via Stripe PCI-DSS Level 1
            </p>
          </div>
        </div>

        {/* Credit balance and current period */}
        <div className="mt-6 bg-white rounded-xl border border-gray-200 p-6">
          <h2 className="font-bold text-gray-900 mb-4">Account Balance</h2>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center p-4 bg-gray-50 rounded-xl">
              <div className="text-2xl font-black text-gray-900">€{(user?.credit_balance || 0).toFixed(2)}</div>
              <div className="text-xs text-gray-500 mt-1">Credit Balance</div>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-xl">
              <div className="text-2xl font-black text-gray-900 capitalize">{user?.subscription_status || 'none'}</div>
              <div className="text-xs text-gray-500 mt-1">Subscription Status</div>
            </div>
            <div className="text-center p-4 bg-gray-50 rounded-xl">
              <div className="text-2xl font-black text-gray-900">31 min</div>
              <div className="text-xs text-gray-500 mt-1">Usage Billing Cycle</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
