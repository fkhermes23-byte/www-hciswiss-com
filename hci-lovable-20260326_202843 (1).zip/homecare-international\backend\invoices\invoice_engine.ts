// backend/invoices/invoice_engine.ts
import PDFDocument from 'pdfkit';
import { supabaseAdmin } from '../lib/db';
import { logger } from '../lib/logger';
import { chargeCustomer } from '../payments/stripe_engine';
import { calculateUnbilledUsage, DEFAULT_TAX_RATE } from '../billing/billing_engine';
import { Readable } from 'stream';

export interface InvoiceData {
  invoiceNumber: string;
  userId: string;
  userEmail: string;
  userName?: string;
  role: string;
  minutesUsed: number;
  pricePerMinute: number;
  subtotal: number;
  taxRate: number;
  taxAmount: number;
  totalAmount: number;
  currency: string;
  periodStart: Date;
  periodEnd: Date;
  sessions: any[];
  createdAt: Date;
}

// Generate invoice for user
export async function generateAndChargeInvoice(userId: string): Promise<string | null> {
  try {
    const { data: user } = await supabaseAdmin
      .from('users')
      .select('*')
      .eq('id', userId)
      .single();

    if (!user) return null;

    const { minutesUsed, totalCost, periodStart, periodEnd, sessions } =
      await calculateUnbilledUsage(userId);

    // Minimum billable amount: 0.01 EUR
    if (totalCost < 0.01) {
      // Update last billing timestamp even for zero amounts
      await supabaseAdmin
        .from('users')
        .update({ last_billing_timestamp: new Date().toISOString() })
        .eq('id', userId);
      return null;
    }

    const pricePerMinute = minutesUsed > 0 ? totalCost / minutesUsed : 0;
    const taxAmount = Math.round(totalCost * DEFAULT_TAX_RATE * 100) / 100;
    const totalAmount = Math.round((totalCost + taxAmount) * 100) / 100;

    // Create invoice record
    const { data: invoice } = await supabaseAdmin
      .from('invoices')
      .insert({
        user_id: userId,
        amount: totalCost,
        tax_amount: taxAmount,
        total_amount: totalAmount,
        currency: user.currency || 'EUR',
        status: 'pending',
        minutes_used: minutesUsed,
        price_per_minute: pricePerMinute,
        period_start: periodStart.toISOString(),
        period_end: periodEnd.toISOString(),
        due_date: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
        line_items: sessions.map(s => ({
          description: `Usage ${new Date(s.start_time).toISOString()} - ${new Date(s.end_time || periodEnd).toISOString()}`,
          minutes: s.minutes_used,
          rate: s.price_per_minute,
          amount: s.amount_charged,
        })),
      })
      .select()
      .single();

    if (!invoice) throw new Error('Failed to create invoice');

    // Generate PDF
    const pdfBuffer = await generateInvoicePDF({
      invoiceNumber: invoice.invoice_number,
      userId,
      userEmail: user.email,
      role: user.role,
      minutesUsed,
      pricePerMinute,
      subtotal: totalCost,
      taxRate: DEFAULT_TAX_RATE,
      taxAmount,
      totalAmount,
      currency: user.currency || 'EUR',
      periodStart,
      periodEnd,
      sessions,
      createdAt: new Date(),
    });

    // Upload PDF to Supabase Storage
    const fileName = `${user.id}/${invoice.invoice_number}.pdf`;
    const { error: uploadError } = await supabaseAdmin.storage
      .from(process.env.SUPABASE_STORAGE_BUCKET || 'invoices')
      .upload(fileName, pdfBuffer, {
        contentType: 'application/pdf',
        upsert: true,
      });

    if (!uploadError) {
      const { data: urlData } = supabaseAdmin.storage
        .from(process.env.SUPABASE_STORAGE_BUCKET || 'invoices')
        .getPublicUrl(fileName);

      await supabaseAdmin
        .from('invoices')
        .update({ pdf_url: urlData.publicUrl, pdf_path: fileName })
        .eq('id', invoice.id);
    }

    // Mark sessions as billed
    const sessionIds = sessions.map(s => s.id);
    if (sessionIds.length > 0) {
      await supabaseAdmin
        .from('usage_sessions')
        .update({ billed: true, invoice_id: invoice.id })
        .in('id', sessionIds);
    }

    // Attempt automatic payment
    const paymentResult = await chargeCustomer(
      userId,
      totalAmount,
      invoice.id,
      `Invoice ${invoice.invoice_number} - ${minutesUsed.toFixed(2)} minutes`
    );

    if (paymentResult.success) {
      await supabaseAdmin
        .from('invoices')
        .update({
          status: 'paid',
          paid_at: new Date().toISOString(),
          stripe_payment_id: paymentResult.paymentIntentId,
        })
        .eq('id', invoice.id);

      // Credit user balance
      await supabaseAdmin.rpc('add_credit', {
        p_user_id: userId,
        p_amount: totalAmount,
      });
    } else {
      await supabaseAdmin
        .from('invoices')
        .update({ status: 'failed' })
        .eq('id', invoice.id);
    }

    // Update last billing timestamp
    await supabaseAdmin
      .from('users')
      .update({ last_billing_timestamp: new Date().toISOString() })
      .eq('id', userId);

    logger.info('invoice_generated', {
      userId,
      invoiceId: invoice.id,
      invoiceNumber: invoice.invoice_number,
      totalAmount,
      paymentSuccess: paymentResult.success,
    });

    return invoice.id;

  } catch (err) {
    logger.error('invoice_generation_failed', { userId, error: err });
    return null;
  }
}

// Generate PDF invoice
export async function generateInvoicePDF(data: InvoiceData): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    const doc = new PDFDocument({
      size: 'A4',
      margin: 50,
    });

    doc.on('data', (chunk: Buffer) => chunks.push(chunk));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    const primaryColor = '#1a365d';
    const accentColor = '#3182ce';
    const lightGray = '#f7fafc';
    const darkGray = '#4a5568';
    const green = '#276749';

    // Header background
    doc.rect(0, 0, doc.page.width, 140).fill(primaryColor);

    // Logo / Company name
    doc
      .fillColor('#ffffff')
      .fontSize(24)
      .font('Helvetica-Bold')
      .text('HOME CARE INTERNATIONAL', 50, 40);

    doc
      .fillColor('#90cdf4')
      .fontSize(10)
      .font('Helvetica')
      .text('homecareinternational.ch | homecareinternational.org', 50, 70);

    doc
      .fillColor('#ffffff')
      .fontSize(10)
      .text('Via della Salute 1, CH-6900 Lugano, Switzerland', 50, 88)
      .text('billing@homecareinternational.ch | +41 91 000 0000', 50, 103);

    // Invoice title (right side)
    doc
      .fillColor('#ffffff')
      .fontSize(32)
      .font('Helvetica-Bold')
      .text('INVOICE', 350, 40, { align: 'right' });

    doc
      .fillColor('#90cdf4')
      .fontSize(12)
      .font('Helvetica')
      .text(`#${data.invoiceNumber}`, 350, 82, { align: 'right' });

    doc
      .fillColor('#63b3ed')
      .fontSize(10)
      .text(new Date(data.createdAt).toLocaleDateString('en-CH'), 350, 103, { align: 'right' });

    // Status badge
    const statusColor = '#276749';
    doc.roundedRect(420, 110, 80, 22, 4).fill(statusColor);
    doc.fillColor('#ffffff').fontSize(9).font('Helvetica-Bold').text('INVOICE', 430, 117);

    // Info boxes below header
    doc.rect(0, 140, doc.page.width, 8).fill('#e2e8f0');

    // Bill To section
    doc
      .fillColor(primaryColor)
      .fontSize(10)
      .font('Helvetica-Bold')
      .text('BILLED TO', 50, 165);

    doc
      .fillColor(darkGray)
      .fontSize(11)
      .font('Helvetica')
      .text(data.userEmail, 50, 182)
      .text(`Account Role: ${data.role.charAt(0).toUpperCase() + data.role.slice(1)}`, 50, 198)
      .text(`User ID: ${data.userId.substring(0, 8)}...`, 50, 214);

    // Invoice details (right)
    const detailsX = 350;
    doc.fillColor(primaryColor).fontSize(10).font('Helvetica-Bold').text('INVOICE DETAILS', detailsX, 165);

    const details = [
      ['Invoice Number:', data.invoiceNumber],
      ['Invoice Date:', new Date(data.createdAt).toLocaleDateString('en-CH')],
      ['Period Start:', new Date(data.periodStart).toLocaleString('en-CH')],
      ['Period End:', new Date(data.periodEnd).toLocaleString('en-CH')],
      ['Currency:', data.currency],
    ];

    details.forEach(([label, value], i) => {
      doc
        .fillColor(darkGray).fontSize(9).font('Helvetica-Bold').text(label, detailsX, 182 + i * 14)
        .fillColor('#2d3748').fontSize(9).font('Helvetica').text(value, detailsX + 100, 182 + i * 14);
    });

    // Summary box
    doc.rect(50, 250, doc.page.width - 100, 70).fill(lightGray).stroke('#e2e8f0');
    const summaryItems = [
      { label: 'Minutes Used', value: data.minutesUsed.toFixed(2), x: 70 },
      { label: 'Rate/Minute', value: `${data.currency} ${data.pricePerMinute.toFixed(4)}`, x: 220 },
      { label: 'Subtotal', value: `${data.currency} ${data.subtotal.toFixed(2)}`, x: 370 },
      { label: 'Tax (7.7%)', value: `${data.currency} ${data.taxAmount.toFixed(2)}`, x: 480 },
    ];

    summaryItems.forEach(item => {
      doc.fillColor(darkGray).fontSize(9).font('Helvetica').text(item.label, item.x, 265);
      doc.fillColor(primaryColor).fontSize(12).font('Helvetica-Bold').text(item.value, item.x, 280);
    });

    // Line items table
    const tableTop = 340;
    const tableHeaders = ['#', 'Description', 'Duration', 'Rate/Min', 'Amount'];
    const colWidths = [30, 250, 70, 70, 70];
    const colPositions = [50, 80, 330, 400, 470];

    // Table header
    doc.rect(50, tableTop, doc.page.width - 100, 22).fill(primaryColor);
    tableHeaders.forEach((header, i) => {
      doc
        .fillColor('#ffffff')
        .fontSize(9)
        .font('Helvetica-Bold')
        .text(header, colPositions[i], tableTop + 7);
    });

    // Table rows
    const items = data.sessions.length > 0 ? data.sessions : [{
      start_time: data.periodStart,
      end_time: data.periodEnd,
      minutes_used: data.minutesUsed,
      price_per_minute: data.pricePerMinute,
      amount_charged: data.subtotal,
    }];

    let rowY = tableTop + 22;
    items.slice(0, 15).forEach((session, i) => {
      const bg = i % 2 === 0 ? '#ffffff' : lightGray;
      doc.rect(50, rowY, doc.page.width - 100, 20).fill(bg);

      const start = new Date(session.start_time).toLocaleString('en-CH', { month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' });
      const end = session.end_time ? new Date(session.end_time).toLocaleString('en-CH', { hour: '2-digit', minute: '2-digit' }) : 'ongoing';

      doc.fillColor('#2d3748').fontSize(8).font('Helvetica');
      doc.text(`${i + 1}`, colPositions[0], rowY + 6);
      doc.text(`${start} – ${end}`, colPositions[1], rowY + 6);
      doc.text(`${(session.minutes_used || 0).toFixed(2)} min`, colPositions[2], rowY + 6);
      doc.text(`${(session.price_per_minute || data.pricePerMinute).toFixed(4)}`, colPositions[3], rowY + 6);
      doc.text(`${data.currency} ${(session.amount_charged || session.amount || 0).toFixed(4)}`, colPositions[4], rowY + 6);

      rowY += 20;
    });

    if (items.length > 15) {
      doc.fillColor(darkGray).fontSize(8).text(`... and ${items.length - 15} more line items`, 50, rowY + 4);
      rowY += 20;
    }

    // Totals section
    rowY += 15;
    const totalsX = 380;

    const totals = [
      { label: 'Subtotal', value: `${data.currency} ${data.subtotal.toFixed(2)}` },
      { label: `Tax (${(data.taxRate * 100).toFixed(1)}%)`, value: `${data.currency} ${data.taxAmount.toFixed(2)}` },
    ];

    totals.forEach(({ label, value }) => {
      doc.fillColor(darkGray).fontSize(10).font('Helvetica').text(label, totalsX, rowY);
      doc.fillColor('#2d3748').fontSize(10).font('Helvetica').text(value, 460, rowY);
      rowY += 18;
    });

    // Total due line
    doc.rect(370, rowY, doc.page.width - 420, 2).fill(primaryColor);
    rowY += 8;
    doc.rect(370, rowY, doc.page.width - 420, 32).fill(primaryColor);
    doc.fillColor('#ffffff').fontSize(11).font('Helvetica-Bold').text('TOTAL DUE', totalsX + 10, rowY + 9);
    doc.fillColor('#ffffff').fontSize(14).font('Helvetica-Bold').text(`${data.currency} ${data.totalAmount.toFixed(2)}`, 440, rowY + 7);

    rowY += 55;

    // Payment info
    doc
      .fillColor(primaryColor)
      .fontSize(10)
      .font('Helvetica-Bold')
      .text('PAYMENT INFORMATION', 50, rowY);

    doc
      .fillColor(darkGray)
      .fontSize(9)
      .font('Helvetica')
      .text(
        'Payment is processed automatically via your saved payment method (Stripe/PayPal/Crypto).\n' +
        'If payment fails, your account will be temporarily suspended until payment is completed.\n' +
        'For billing inquiries: billing@homecareinternational.ch',
        50,
        rowY + 16,
        { width: doc.page.width - 100 }
      );

    // Footer
    const footerY = doc.page.height - 60;
    doc.rect(0, footerY - 15, doc.page.width, 1).fill('#e2e8f0');

    doc
      .fillColor(darkGray)
      .fontSize(8)
      .font('Helvetica')
      .text(
        'Home Care International SA | CHE-XXX.XXX.XXX | VAT ID: CHE-XXX.XXX.XXX MWST',
        50,
        footerY,
        { align: 'center', width: doc.page.width - 100 }
      )
      .text(
        `Invoice generated on ${new Date().toISOString()} | homecareinternational.ch`,
        50,
        footerY + 14,
        { align: 'center', width: doc.page.width - 100 }
      );

    doc.end();
  });
}
