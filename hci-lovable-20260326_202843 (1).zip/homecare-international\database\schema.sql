-- ============================================================
-- HOME CARE INTERNATIONAL — ENTERPRISE DATABASE SCHEMA
-- PostgreSQL / Supabase Compatible
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================
-- ENUM TYPES
-- ============================================================

CREATE TYPE user_role AS ENUM ('private', 'professional', 'enterprise', 'admin');
CREATE TYPE account_status AS ENUM ('active', 'suspended', 'blocked', 'pending', 'deleted');
CREATE TYPE subscription_type AS ENUM ('daily', 'weekly', 'monthly', 'annual', 'pay_per_use');
CREATE TYPE subscription_status AS ENUM ('active', 'cancelled', 'expired', 'past_due');
CREATE TYPE invoice_status AS ENUM ('pending', 'paid', 'failed', 'cancelled', 'refunded');
CREATE TYPE payment_provider AS ENUM ('stripe', 'paypal', 'crypto', 'manual');
CREATE TYPE payment_status AS ENUM ('pending', 'succeeded', 'failed', 'cancelled', 'refunded');
CREATE TYPE log_level AS ENUM ('info', 'warn', 'error', 'debug');
CREATE TYPE currency_code AS ENUM ('EUR', 'CHF', 'USD', 'GBP');
CREATE TYPE geo_level AS ENUM ('country', 'region', 'continent');
CREATE TYPE data_quality AS ENUM ('ok', 'estimated', 'stale');

-- ============================================================
-- USERS TABLE
-- ============================================================

CREATE TABLE users (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email                   TEXT UNIQUE NOT NULL,
    password_hash           TEXT NOT NULL,
    role                    user_role NOT NULL DEFAULT 'private',
    account_status          account_status NOT NULL DEFAULT 'active',
    credit_balance          NUMERIC(12,4) NOT NULL DEFAULT 0.00,
    subscription_status     subscription_status,
    subscription_type       subscription_type DEFAULT 'pay_per_use',
    stripe_customer_id      TEXT UNIQUE,
    stripe_payment_method   TEXT,
    paypal_customer_id      TEXT UNIQUE,
    crypto_wallet           TEXT,
    last_billing_timestamp  TIMESTAMPTZ,
    last_login_at           TIMESTAMPTZ,
    email_verified          BOOLEAN NOT NULL DEFAULT FALSE,
    verification_token      TEXT,
    reset_token             TEXT,
    reset_token_expires_at  TIMESTAMPTZ,
    two_factor_enabled      BOOLEAN NOT NULL DEFAULT FALSE,
    two_factor_secret       TEXT,
    monthly_usage_minutes   NUMERIC(12,2) NOT NULL DEFAULT 0,
    monthly_usage_reset_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    price_multiplier        NUMERIC(4,2) NOT NULL DEFAULT 1.00,
    currency                currency_code NOT NULL DEFAULT 'EUR',
    metadata                JSONB DEFAULT '{}',
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_status ON users(account_status);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_stripe ON users(stripe_customer_id);

-- ============================================================
-- SESSIONS TABLE (JWT/Auth)
-- ============================================================

CREATE TABLE sessions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash      TEXT NOT NULL UNIQUE,
    ip_address      INET,
    user_agent      TEXT,
    expires_at      TIMESTAMPTZ NOT NULL,
    revoked         BOOLEAN NOT NULL DEFAULT FALSE,
    revoked_at      TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_sessions_user_id ON sessions(user_id);
CREATE INDEX idx_sessions_token ON sessions(token_hash);
CREATE INDEX idx_sessions_expires ON sessions(expires_at);

-- ============================================================
-- USAGE SESSIONS TABLE
-- ============================================================

CREATE TABLE usage_sessions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    start_time      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    end_time        TIMESTAMPTZ,
    last_heartbeat  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    duration_seconds INTEGER NOT NULL DEFAULT 0,
    minutes_used    NUMERIC(10,4) NOT NULL DEFAULT 0,
    price_per_minute NUMERIC(8,4) NOT NULL,
    amount_charged  NUMERIC(12,4) NOT NULL DEFAULT 0,
    currency        currency_code NOT NULL DEFAULT 'EUR',
    billed          BOOLEAN NOT NULL DEFAULT FALSE,
    invoice_id      UUID,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_usage_sessions_user_id ON usage_sessions(user_id);
CREATE INDEX idx_usage_sessions_start ON usage_sessions(start_time);
CREATE INDEX idx_usage_sessions_billed ON usage_sessions(billed);
CREATE INDEX idx_usage_sessions_active ON usage_sessions(end_time) WHERE end_time IS NULL;

-- ============================================================
-- BILLING TABLE (periodic snapshots)
-- ============================================================

CREATE TABLE billing (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    period_start    TIMESTAMPTZ NOT NULL,
    period_end      TIMESTAMPTZ NOT NULL,
    minutes_used    NUMERIC(10,4) NOT NULL DEFAULT 0,
    price_per_minute NUMERIC(8,4) NOT NULL,
    subtotal        NUMERIC(12,4) NOT NULL,
    tax_rate        NUMERIC(5,4) NOT NULL DEFAULT 0.077,
    tax_amount      NUMERIC(12,4) NOT NULL,
    total           NUMERIC(12,4) NOT NULL,
    currency        currency_code NOT NULL DEFAULT 'EUR',
    status          invoice_status NOT NULL DEFAULT 'pending',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_billing_user_id ON billing(user_id);
CREATE INDEX idx_billing_period ON billing(period_start, period_end);

-- ============================================================
-- INVOICES TABLE
-- ============================================================

CREATE TABLE invoices (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    invoice_number      TEXT UNIQUE NOT NULL,
    user_id             UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    billing_id          UUID REFERENCES billing(id),
    amount              NUMERIC(12,4) NOT NULL,
    tax_amount          NUMERIC(12,4) NOT NULL DEFAULT 0,
    total_amount        NUMERIC(12,4) NOT NULL,
    currency            currency_code NOT NULL DEFAULT 'EUR',
    status              invoice_status NOT NULL DEFAULT 'pending',
    payment_provider    payment_provider,
    stripe_invoice_id   TEXT,
    stripe_payment_id   TEXT,
    paypal_order_id     TEXT,
    crypto_charge_id    TEXT,
    pdf_url             TEXT,
    pdf_path            TEXT,
    line_items          JSONB NOT NULL DEFAULT '[]',
    minutes_used        NUMERIC(10,4),
    price_per_minute    NUMERIC(8,4),
    period_start        TIMESTAMPTZ,
    period_end          TIMESTAMPTZ,
    due_date            TIMESTAMPTZ,
    paid_at             TIMESTAMPTZ,
    retry_count         INTEGER NOT NULL DEFAULT 0,
    last_retry_at       TIMESTAMPTZ,
    notes               TEXT,
    metadata            JSONB DEFAULT '{}',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_invoices_user_id ON invoices(user_id);
CREATE INDEX idx_invoices_status ON invoices(status);
CREATE INDEX idx_invoices_number ON invoices(invoice_number);
CREATE INDEX idx_invoices_stripe ON invoices(stripe_invoice_id);

-- ============================================================
-- PAYMENTS TABLE
-- ============================================================

CREATE TABLE payments (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id             UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    invoice_id          UUID REFERENCES invoices(id),
    provider            payment_provider NOT NULL,
    status              payment_status NOT NULL DEFAULT 'pending',
    amount              NUMERIC(12,4) NOT NULL,
    currency            currency_code NOT NULL DEFAULT 'EUR',
    transaction_id      TEXT,
    stripe_payment_intent_id TEXT,
    paypal_capture_id   TEXT,
    crypto_tx_hash      TEXT,
    error_code          TEXT,
    error_message       TEXT,
    metadata            JSONB DEFAULT '{}',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_payments_user_id ON payments(user_id);
CREATE INDEX idx_payments_invoice ON payments(invoice_id);
CREATE INDEX idx_payments_status ON payments(status);
CREATE INDEX idx_payments_provider ON payments(provider);

-- ============================================================
-- SUBSCRIPTIONS TABLE
-- ============================================================

CREATE TABLE subscriptions (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id             UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    plan_type           subscription_type NOT NULL,
    status              subscription_status NOT NULL DEFAULT 'active',
    price               NUMERIC(12,4) NOT NULL,
    currency            currency_code NOT NULL DEFAULT 'EUR',
    stripe_sub_id       TEXT UNIQUE,
    paypal_sub_id       TEXT UNIQUE,
    start_date          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    end_date            TIMESTAMPTZ,
    trial_end           TIMESTAMPTZ,
    cancel_at           TIMESTAMPTZ,
    cancelled_at        TIMESTAMPTZ,
    current_period_start TIMESTAMPTZ,
    current_period_end  TIMESTAMPTZ,
    metadata            JSONB DEFAULT '{}',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_subscriptions_user_id ON subscriptions(user_id);
CREATE INDEX idx_subscriptions_status ON subscriptions(status);

-- ============================================================
-- LOGS TABLE
-- ============================================================

CREATE TABLE logs (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    level       log_level NOT NULL DEFAULT 'info',
    category    TEXT NOT NULL,
    message     TEXT NOT NULL,
    user_id     UUID REFERENCES users(id) ON DELETE SET NULL,
    ip_address  INET,
    metadata    JSONB DEFAULT '{}',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_logs_level ON logs(level);
CREATE INDEX idx_logs_category ON logs(category);
CREATE INDEX idx_logs_user_id ON logs(user_id);
CREATE INDEX idx_logs_created ON logs(created_at);

-- Partition logs by month for performance at scale
-- (Implement partitioning in production for millions of rows)

-- ============================================================
-- WEBHOOK EVENTS TABLE
-- ============================================================

CREATE TABLE webhook_events (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    provider        payment_provider NOT NULL,
    event_id        TEXT NOT NULL,
    event_type      TEXT NOT NULL,
    payload         JSONB NOT NULL,
    processed       BOOLEAN NOT NULL DEFAULT FALSE,
    processed_at    TIMESTAMPTZ,
    error           TEXT,
    retry_count     INTEGER NOT NULL DEFAULT 0,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX idx_webhook_events_event_id ON webhook_events(provider, event_id);
CREATE INDEX idx_webhook_events_processed ON webhook_events(processed);
CREATE INDEX idx_webhook_events_type ON webhook_events(event_type);

-- ============================================================
-- HEALTH METRICS TABLES
-- ============================================================

CREATE TABLE health_metrics (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    metric_key          TEXT UNIQUE NOT NULL,
    metric_name         TEXT NOT NULL,
    description         TEXT,
    unit                TEXT NOT NULL,
    source_name         TEXT NOT NULL,
    source_url          TEXT,
    update_frequency    TEXT NOT NULL DEFAULT 'daily',
    category            TEXT NOT NULL DEFAULT 'general',
    is_higher_better    BOOLEAN,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_health_metrics_key ON health_metrics(metric_key);

CREATE TABLE health_metric_values (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    metric_key      TEXT NOT NULL REFERENCES health_metrics(metric_key),
    geo_level       geo_level NOT NULL DEFAULT 'country',
    geo_code        TEXT NOT NULL,
    timestamp       TIMESTAMPTZ NOT NULL,
    value           NUMERIC NOT NULL,
    value_min       NUMERIC,
    value_max       NUMERIC,
    trend_24h       NUMERIC,
    trend_7d        NUMERIC,
    quality_flag    data_quality NOT NULL DEFAULT 'ok',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_health_values_key ON health_metric_values(metric_key);
CREATE INDEX idx_health_values_geo ON health_metric_values(geo_code, geo_level);
CREATE INDEX idx_health_values_time ON health_metric_values(timestamp DESC);
CREATE UNIQUE INDEX idx_health_values_unique ON health_metric_values(metric_key, geo_code, geo_level, timestamp);

CREATE TABLE health_map_events (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID REFERENCES users(id) ON DELETE SET NULL,
    session_id  TEXT,
    event_key   TEXT NOT NULL,
    payload     JSONB DEFAULT '{}',
    ip_address  INET,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_health_events_key ON health_map_events(event_key);
CREATE INDEX idx_health_events_user ON health_map_events(user_id);

CREATE TABLE countries (
    country_code    TEXT PRIMARY KEY,
    country_name    TEXT NOT NULL,
    continent       TEXT NOT NULL,
    population      BIGINT,
    flag_emoji      TEXT,
    iso3            TEXT,
    lat             NUMERIC,
    lng             NUMERIC,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- FUNCTIONS & TRIGGERS
-- ============================================================

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER invoices_updated_at BEFORE UPDATE ON invoices FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER payments_updated_at BEFORE UPDATE ON payments FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER subscriptions_updated_at BEFORE UPDATE ON subscriptions FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER usage_sessions_updated_at BEFORE UPDATE ON usage_sessions FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Auto-generate invoice number
CREATE OR REPLACE FUNCTION generate_invoice_number()
RETURNS TRIGGER AS $$
DECLARE
    year_part TEXT;
    seq_part TEXT;
    new_number TEXT;
BEGIN
    IF NEW.invoice_number IS NULL OR NEW.invoice_number = '' THEN
        year_part := TO_CHAR(NOW(), 'YYYY');
        seq_part := LPAD(nextval('invoice_seq')::TEXT, 6, '0');
        NEW.invoice_number := 'HCI-' || year_part || '-' || seq_part;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE SEQUENCE invoice_seq START 1;
CREATE TRIGGER auto_invoice_number BEFORE INSERT ON invoices FOR EACH ROW EXECUTE FUNCTION generate_invoice_number();

-- Price multiplier based on usage
CREATE OR REPLACE FUNCTION calculate_price_multiplier(user_id UUID)
RETURNS NUMERIC AS $$
DECLARE
    monthly_minutes NUMERIC;
    multiplier NUMERIC;
BEGIN
    SELECT COALESCE(SUM(minutes_used), 0)
    INTO monthly_minutes
    FROM usage_sessions
    WHERE usage_sessions.user_id = calculate_price_multiplier.user_id
    AND start_time >= DATE_TRUNC('month', NOW());

    IF monthly_minutes > 10000 THEN multiplier := 1.30;
    ELSIF monthly_minutes > 5000 THEN multiplier := 1.20;
    ELSIF monthly_minutes > 1000 THEN multiplier := 1.10;
    ELSE multiplier := 1.00;
    END IF;

    RETURN multiplier;
END;
$$ LANGUAGE plpgsql;

-- Get price per minute based on role
CREATE OR REPLACE FUNCTION get_price_per_minute(p_role user_role, p_multiplier NUMERIC DEFAULT 1.00)
RETURNS NUMERIC AS $$
DECLARE
    base_price NUMERIC;
BEGIN
    CASE p_role
        WHEN 'private' THEN base_price := 0.25;
        WHEN 'professional' THEN base_price := 0.50;
        WHEN 'enterprise' THEN base_price := 0.75;
        WHEN 'admin' THEN base_price := 0.00;
        ELSE base_price := 0.25;
    END CASE;
    RETURN ROUND(base_price * p_multiplier, 4);
END;
$$ LANGUAGE plpgsql;

-- ============================================================
-- ROW LEVEL SECURITY (Supabase)
-- ============================================================

ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE usage_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own data" ON users FOR SELECT USING (auth.uid()::uuid = id);
CREATE POLICY "Users can view own usage" ON usage_sessions FOR SELECT USING (auth.uid()::uuid = user_id);
CREATE POLICY "Users can view own invoices" ON invoices FOR SELECT USING (auth.uid()::uuid = user_id);
CREATE POLICY "Users can view own payments" ON payments FOR SELECT USING (auth.uid()::uuid = user_id);
CREATE POLICY "Users can view own subscriptions" ON subscriptions FOR SELECT USING (auth.uid()::uuid = user_id);

-- Admin has full access
CREATE POLICY "Admin full access users" ON users FOR ALL USING (
    EXISTS (SELECT 1 FROM users WHERE id = auth.uid()::uuid AND role = 'admin')
);

-- ============================================================
-- SEED HEALTH METRICS DEFINITIONS
-- ============================================================

INSERT INTO health_metrics (metric_key, metric_name, description, unit, source_name, source_url, update_frequency, category, is_higher_better) VALUES
('diabetes_prevalence', 'Diabetes Prevalence', 'Percentage of adults aged 20-79 with diabetes', '%', 'IDF Diabetes Atlas', 'https://diabetesatlas.org', 'annual', 'chronic_disease', false),
('hypertension_prevalence', 'Hypertension Prevalence', 'Percentage of adults with raised blood pressure', '%', 'WHO Global Health Observatory', 'https://www.who.int/data/gho', 'annual', 'chronic_disease', false),
('obesity_prevalence', 'Obesity Prevalence', 'Percentage of adults with BMI >= 30', '%', 'WHO Global Health Observatory', 'https://www.who.int/data/gho', 'annual', 'chronic_disease', false),
('life_expectancy', 'Life Expectancy at Birth', 'Average number of years a newborn is expected to live', 'years', 'WHO Global Health Observatory', 'https://www.who.int/data/gho', 'annual', 'demographics', true),
('infant_mortality', 'Infant Mortality Rate', 'Deaths per 1,000 live births under age 1', 'per 1000', 'UNICEF', 'https://data.unicef.org', 'annual', 'demographics', false),
('birth_rate', 'Birth Rate', 'Number of live births per 1,000 population', 'per 1000', 'World Bank', 'https://data.worldbank.org', 'annual', 'demographics', null),
('death_rate', 'Death Rate', 'Number of deaths per 1,000 population', 'per 1000', 'World Bank', 'https://data.worldbank.org', 'annual', 'demographics', null),
('smoking_prevalence', 'Smoking Prevalence', 'Percentage of adults who currently smoke', '%', 'WHO Global Health Observatory', 'https://www.who.int/data/gho', 'annual', 'risk_factors', false),
('doctors_per_1000', 'Physicians per 1,000', 'Number of physicians per 1,000 population', 'per 1000', 'WHO Global Health Observatory', 'https://www.who.int/data/gho', 'annual', 'health_system', true),
('health_expenditure_gdp', 'Health Expenditure (% GDP)', 'Current health expenditure as percentage of GDP', '%', 'World Bank', 'https://data.worldbank.org', 'annual', 'health_system', true),
('pm25_exposure', 'PM2.5 Air Pollution', 'Mean annual exposure to PM2.5 particulate matter', 'µg/m³', 'WHO Global Ambient Air Quality Database', 'https://www.who.int/data/gho/data/themes/air-pollution', 'annual', 'environment', false),
('cardiovascular_mortality', 'Cardiovascular Mortality Rate', 'Age-standardized mortality rate from cardiovascular diseases', 'per 100k', 'WHO Global Health Observatory', 'https://www.who.int/data/gho', 'annual', 'chronic_disease', false),
('road_accident_mortality', 'Road Traffic Mortality', 'Estimated road traffic death rate per 100,000 population', 'per 100k', 'WHO Global Status Report on Road Safety', 'https://www.who.int/publications', 'annual', 'safety', false),
('vaccination_coverage', 'DTP3 Vaccination Coverage', 'Immunization coverage among 1-year-olds for DTP3', '%', 'WHO/UNICEF Joint Reporting Form', 'https://www.who.int/data/gho', 'annual', 'prevention', true),
('ubi_index', 'Universal Health Coverage Index', 'UHC service coverage index (0-100)', 'index', 'WHO/World Bank', 'https://www.who.int/data/gho', 'annual', 'health_system', true);

-- ============================================================
-- SEED COUNTRIES (sample - full list in seed file)
-- ============================================================

INSERT INTO countries (country_code, country_name, continent, population, flag_emoji, iso3, lat, lng) VALUES
('CH', 'Switzerland', 'Europe', 8796669, '🇨🇭', 'CHE', 46.8182, 8.2275),
('DE', 'Germany', 'Europe', 83900473, '🇩🇪', 'DEU', 51.1657, 10.4515),
('FR', 'France', 'Europe', 68042591, '🇫🇷', 'FRA', 46.2276, 2.2137),
('IT', 'Italy', 'Europe', 60317116, '🇮🇹', 'ITA', 41.8719, 12.5674),
('US', 'United States', 'North America', 331893745, '🇺🇸', 'USA', 37.0902, -95.7129),
('GB', 'United Kingdom', 'Europe', 68207116, '🇬🇧', 'GBR', 55.3781, -3.4360),
('JP', 'Japan', 'Asia', 125681593, '🇯🇵', 'JPN', 36.2048, 138.2529),
('CN', 'China', 'Asia', 1412600000, '🇨🇳', 'CHN', 35.8617, 104.1954),
('BR', 'Brazil', 'South America', 214326223, '🇧🇷', 'BRA', -14.2350, -51.9253),
('IN', 'India', 'Asia', 1380004385, '🇮🇳', 'IND', 20.5937, 78.9629),
('AU', 'Australia', 'Oceania', 25978935, '🇦🇺', 'AUS', -25.2744, 133.7751),
('CA', 'Canada', 'North America', 38436447, '🇨🇦', 'CAN', 56.1304, -106.3468),
('ZA', 'South Africa', 'Africa', 60041994, '🇿🇦', 'ZAF', -30.5595, 22.9375),
('NG', 'Nigeria', 'Africa', 218541212, '🇳🇬', 'NGA', 9.0820, 8.6753),
('RU', 'Russia', 'Europe', 145912025, '🇷🇺', 'RUS', 61.5240, 105.3188),
('MX', 'Mexico', 'North America', 130262216, '🇲🇽', 'MEX', 23.6345, -102.5528),
('ES', 'Spain', 'Europe', 47431256, '🇪🇸', 'ESP', 40.4637, -3.7492),
('SE', 'Sweden', 'Europe', 10379295, '🇸🇪', 'SWE', 60.1282, 18.6435),
('NO', 'Norway', 'Europe', 5434319, '🇳🇴', 'NOR', 60.4720, 8.4689),
('NL', 'Netherlands', 'Europe', 17617421, '🇳🇱', 'NLD', 52.1326, 5.2913);
