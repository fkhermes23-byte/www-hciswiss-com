// app/global-health/page.tsx
'use client';
import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { Globe, Info, Layers, X, TrendingUp, TrendingDown, Minus, ArrowRight, Heart } from 'lucide-react';

const HEALTH_METRICS = [
  { key: 'life_expectancy', label: 'Life Expectancy', unit: 'years', category: 'Demographics', isHigherBetter: true },
  { key: 'diabetes_prevalence', label: 'Diabetes', unit: '%', category: 'Chronic Disease', isHigherBetter: false },
  { key: 'hypertension_prevalence', label: 'Hypertension', unit: '%', category: 'Chronic Disease', isHigherBetter: false },
  { key: 'obesity_prevalence', label: 'Obesity', unit: '%', category: 'Chronic Disease', isHigherBetter: false },
  { key: 'infant_mortality', label: 'Infant Mortality', unit: 'per 1000', category: 'Demographics', isHigherBetter: false },
  { key: 'birth_rate', label: 'Birth Rate', unit: 'per 1000', category: 'Demographics', isHigherBetter: null },
  { key: 'smoking_prevalence', label: 'Smoking Rate', unit: '%', category: 'Risk Factors', isHigherBetter: false },
  { key: 'doctors_per_1000', label: 'Physicians / 1000', unit: 'per 1k', category: 'Health System', isHigherBetter: true },
  { key: 'health_expenditure_gdp', label: 'Health Spend % GDP', unit: '%', category: 'Health System', isHigherBetter: true },
  { key: 'pm25_exposure', label: 'Air Pollution PM2.5', unit: 'µg/m³', category: 'Environment', isHigherBetter: false },
  { key: 'vaccination_coverage', label: 'Vaccination Coverage', unit: '%', category: 'Prevention', isHigherBetter: true },
  { key: 'cardiovascular_mortality', label: 'CV Mortality', unit: 'per 100k', category: 'Chronic Disease', isHigherBetter: false },
  { key: 'road_accident_mortality', label: 'Road Accidents', unit: 'per 100k', category: 'Safety', isHigherBetter: false },
  { key: 'ubi_index', label: 'UHC Coverage Index', unit: 'index', category: 'Health System', isHigherBetter: true },
];

function getColor(value: number, min: number, max: number, isHigherBetter: boolean | null): string {
  if (value == null) return '#374151';
  const normalized = max > min ? (value - min) / (max - min) : 0.5;
  const score = isHigherBetter === false ? 1 - normalized : normalized;
  if (score >= 0.66) return '#16a34a';
  if (score >= 0.33) return '#ca8a04';
  return '#dc2626';
}

// Approximate country positions on the SVG map (lat/lng → x/y %)
function latLngToXY(lat: number, lng: number) {
  const x = ((lng + 180) / 360) * 100;
  const y = ((90 - lat) / 180) * 100;
  return { x, y };
}

export default function GlobalHealthPage() {
  const [selectedMetricKey, setSelectedMetricKey] = useState('life_expectancy');
  const [mapData, setMapData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [selectedCountry, setSelectedCountry] = useState<any>(null);
  const [showLayers, setShowLayers] = useState(false);
  const [storyMode, setStoryMode] = useState(false);
  const [storyStep, setStoryStep] = useState(0);

  const selectedMetric = HEALTH_METRICS.find(m => m.key === selectedMetricKey)!;
  const categories = [...new Set(HEALTH_METRICS.map(m => m.category))];

  const STORIES = [
    { metric: 'life_expectancy', title: 'Living Longer', insight: 'Japan and Switzerland lead the world with life expectancy above 83 years. Sub-Saharan Africa lags by 25+ years.' },
    { metric: 'pm25_exposure', title: 'Breathing Clean Air', insight: 'India and China face severe PM2.5 pollution. Nordic countries have the cleanest air globally.' },
    { metric: 'diabetes_prevalence', title: 'The Diabetes Crisis', insight: 'Mexico and the US have diabetes rates above 10%. Pacific islands face the highest rates globally.' },
    { metric: 'doctors_per_1000', title: 'Access to Care', insight: 'Norway has 5.2 physicians per 1,000 people. Nigeria has only 0.4 — a 13x gap.' },
    { metric: 'vaccination_coverage', title: 'Immunization Coverage', insight: 'Switzerland and Japan achieve 97%+ coverage. Some African nations struggle below 60%.' },
  ];

  useEffect(() => {
    fetchMapData(selectedMetricKey);
  }, [selectedMetricKey]);

  useEffect(() => {
    if (!storyMode) return;
    const story = STORIES[storyStep];
    setSelectedMetricKey(story.metric);
    const timer = setTimeout(() => {
      setStoryStep(s => (s + 1) % STORIES.length);
    }, 6000);
    return () => clearTimeout(timer);
  }, [storyMode, storyStep]);

  const fetchMapData = async (metricKey: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/health/map-data?metric_key=${metricKey}`);
      const data = await res.json();
      // Build lookup map
      const lookup: Record<string, any> = {};
      let min = Infinity, max = -Infinity;
      for (const c of data.countries || []) {
        if (c.value != null) {
          lookup[c.country_code] = c;
          if (c.value < min) min = c.value;
          if (c.value > max) max = c.value;
        }
      }
      lookup._min = min === Infinity ? 0 : min;
      lookup._max = max === -Infinity ? 100 : max;
      setMapData({ countries: data.countries || [], lookup, metric: data.metric, stats: data.stats });
    } catch {
      setMapData(null);
    } finally {
      setLoading(false);
    }
  };

  const countries = mapData?.countries || [];
  const lookup = mapData?.lookup || {};
  const min = lookup._min || 0;
  const max = lookup._max || 100;

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      {/* Nav */}
      <header className="border-b border-white/10 px-6 py-4 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-7 h-7 bg-blue-600 rounded-lg flex items-center justify-center">
            <Heart className="w-3.5 h-3.5 text-white" />
          </div>
          <span className="font-bold text-sm">HomeCare International</span>
        </Link>
        <h1 className="font-bold text-lg flex items-center gap-2">
          <Globe className="w-5 h-5 text-blue-400" />
          Global Health Intelligence Globe
        </h1>
        <div className="flex items-center gap-3">
          <button
            onClick={() => { setStoryMode(!storyMode); setStoryStep(0); }}
            className={`text-sm px-3 py-1.5 rounded-lg font-medium transition-all ${storyMode ? 'bg-blue-600 text-white' : 'bg-white/10 text-gray-300 hover:bg-white/20'}`}
          >
            {storyMode ? '⏹ Stop Story' : '▶ Story Mode'}
          </button>
          <Link href="/auth/register" className="flex items-center gap-1.5 text-sm bg-blue-600 px-3 py-1.5 rounded-lg font-medium hover:bg-blue-700">
            Get Full Access <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </header>

      {/* Disclaimer */}
      <div className="bg-yellow-900/40 border-b border-yellow-700/30 px-6 py-2 text-center text-xs text-yellow-300">
        ⚠️ Dati aggregati a scopo educativo e informativo. Non sostituisce servizi sanitari o consulenza medica. Fonti: WHO, World Bank, IDF, UNICEF.
      </div>

      <div className="flex h-[calc(100vh-120px)]">
        {/* Left Panel - Layer Controls */}
        <aside className="w-72 border-r border-white/10 bg-gray-900 flex flex-col overflow-hidden">
          <div className="p-4 border-b border-white/10">
            <div className="flex items-center gap-2 mb-3">
              <Layers className="w-4 h-4 text-blue-400" />
              <span className="font-semibold text-sm">Health Indicators</span>
            </div>
            <input
              type="text"
              placeholder="Search indicators..."
              className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-gray-500 outline-none focus:border-blue-500"
            />
          </div>

          <div className="flex-1 overflow-y-auto p-3 space-y-4">
            {categories.map(cat => (
              <div key={cat}>
                <div className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2 px-1">{cat}</div>
                <div className="space-y-1">
                  {HEALTH_METRICS.filter(m => m.category === cat).map(metric => (
                    <button
                      key={metric.key}
                      onClick={() => setSelectedMetricKey(metric.key)}
                      className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-all ${
                        selectedMetricKey === metric.key
                          ? 'bg-blue-600 text-white'
                          : 'text-gray-400 hover:bg-white/5 hover:text-white'
                      }`}
                    >
                      <div className="font-medium">{metric.label}</div>
                      <div className={`text-xs mt-0.5 ${selectedMetricKey === metric.key ? 'text-blue-200' : 'text-gray-600'}`}>
                        {metric.unit} · {metric.isHigherBetter === true ? '↑ higher = better' : metric.isHigherBetter === false ? '↓ lower = better' : 'neutral'}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Legend */}
          <div className="p-4 border-t border-white/10">
            <div className="text-xs text-gray-500 mb-2">
              {selectedMetric?.label} · {selectedMetric?.unit}
            </div>
            <div className="flex items-center gap-1 mb-1">
              <div className="h-3 flex-1 rounded" style={{ background: 'linear-gradient(to right, #dc2626, #ca8a04, #16a34a)' }} />
            </div>
            <div className="flex justify-between text-xs text-gray-500">
              <span>{selectedMetric?.isHigherBetter === false ? 'Better' : 'Worse'} ({min.toFixed(1)})</span>
              <span>{selectedMetric?.isHigherBetter === false ? 'Worse' : 'Better'} ({max.toFixed(1)})</span>
            </div>
            <div className="mt-3 flex gap-2">
              <div className="flex items-center gap-1 text-xs text-gray-500"><span className="w-3 h-3 rounded-full bg-green-600 inline-block" /> Good</div>
              <div className="flex items-center gap-1 text-xs text-gray-500"><span className="w-3 h-3 rounded-full bg-yellow-600 inline-block" /> Medium</div>
              <div className="flex items-center gap-1 text-xs text-gray-500"><span className="w-3 h-3 rounded-full bg-red-600 inline-block" /> Poor</div>
            </div>
          </div>
        </aside>

        {/* Map Area */}
        <div className="flex-1 relative overflow-hidden bg-gray-950">
          {/* Story Mode Banner */}
          {storyMode && (
            <div className="absolute top-4 left-1/2 -translate-x-1/2 z-20 bg-blue-900/90 border border-blue-500/30 rounded-xl px-6 py-3 max-w-md text-center backdrop-blur-sm">
              <div className="text-xs text-blue-300 font-semibold mb-1">{STORIES[storyStep].title}</div>
              <div className="text-sm text-white">{STORIES[storyStep].insight}</div>
              <div className="flex justify-center gap-1 mt-2">
                {STORIES.map((_, i) => (
                  <div key={i} className={`h-1 rounded-full transition-all ${i === storyStep ? 'w-6 bg-blue-400' : 'w-1.5 bg-gray-600'}`} />
                ))}
              </div>
            </div>
          )}

          {loading && (
            <div className="absolute inset-0 flex items-center justify-center z-10 bg-gray-950/80">
              <div className="text-center">
                <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
                <p className="text-gray-400 text-sm">Loading health data...</p>
              </div>
            </div>
          )}

          {/* SVG World Map */}
          <div className="absolute inset-0 flex items-center justify-center p-4">
            <div className="relative w-full h-full">
              {/* Background globe effect */}
              <svg viewBox="0 0 1000 500" className="absolute inset-0 w-full h-full">
                {/* Ocean background */}
                <rect width="1000" height="500" fill="#0f172a" />
                {/* Grid lines */}
                {[...Array(7)].map((_, i) => (
                  <line key={`lat${i}`} x1="0" y1={i * 83} x2="1000" y2={i * 83} stroke="#1e3a5f" strokeWidth="0.5" />
                ))}
                {[...Array(13)].map((_, i) => (
                  <line key={`lng${i}`} x1={i * 83} y1="0" x2={i * 83} y2="500" stroke="#1e3a5f" strokeWidth="0.5" />
                ))}
                {/* Equator */}
                <line x1="0" y1="250" x2="1000" y2="250" stroke="#1e40af" strokeWidth="1" strokeDasharray="4,4" />
                {/* Prime meridian */}
                <line x1="500" y1="0" x2="500" y2="500" stroke="#1e40af" strokeWidth="1" strokeDasharray="4,4" />

                {/* Country dots */}
                {countries.map((country: any) => {
                  if (!country.lat || !country.lng) return null;
                  const { x, y } = latLngToXY(country.lat, country.lng);
                  const px = (x / 100) * 1000;
                  const py = (y / 100) * 500;
                  const value = country.value;
                  const color = value != null
                    ? getColor(value, min, max, selectedMetric?.isHigherBetter)
                    : '#374151';
                  const isSelected = selectedCountry?.country_code === country.country_code;
                  const radius = isSelected ? 10 : 6;

                  return (
                    <g key={country.country_code}>
                      <circle
                        cx={px}
                        cy={py}
                        r={radius + 3}
                        fill={color}
                        opacity={0.2}
                        className="cursor-pointer"
                      />
                      <circle
                        cx={px}
                        cy={py}
                        r={radius}
                        fill={color}
                        stroke={isSelected ? 'white' : 'rgba(255,255,255,0.2)'}
                        strokeWidth={isSelected ? 2 : 0.5}
                        className="cursor-pointer transition-all"
                        onClick={() => setSelectedCountry(country)}
                      >
                        <title>{country.country_name}: {value?.toFixed(1)} {selectedMetric?.unit}</title>
                      </circle>
                    </g>
                  );
                })}
              </svg>

              {/* Axis labels */}
              <div className="absolute bottom-2 left-1/2 -translate-x-1/2 text-xs text-gray-600">Longitude</div>
              <div className="absolute left-2 top-1/2 -translate-y-1/2 text-xs text-gray-600 -rotate-90">Latitude</div>
            </div>
          </div>

          {/* Current metric label */}
          <div className="absolute top-4 right-4 bg-gray-900/90 border border-white/10 rounded-xl px-4 py-3 backdrop-blur-sm">
            <div className="text-xs text-gray-400">Currently showing</div>
            <div className="font-bold text-white">{selectedMetric?.label}</div>
            <div className="text-xs text-gray-400">{selectedMetric?.unit} · {mapData?.countries?.filter((c: any) => c.value != null).length || 0} countries</div>
          </div>

          {/* CTA */}
          <div className="absolute bottom-4 right-4 bg-blue-900/80 border border-blue-500/30 rounded-xl px-4 py-3 backdrop-blur-sm max-w-xs">
            <div className="text-xs text-blue-300 mb-1">Educational access is free</div>
            <Link href="/auth/register" className="flex items-center gap-1 text-sm font-medium text-white hover:text-blue-200">
              Start guided health journey <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>

        {/* Right Panel - Country Detail */}
        {selectedCountry && (
          <aside className="w-72 border-l border-white/10 bg-gray-900 flex flex-col">
            <div className="p-4 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-2xl">{selectedCountry.flag_emoji}</span>
                <div>
                  <div className="font-bold">{selectedCountry.country_name}</div>
                  <div className="text-xs text-gray-400">{selectedCountry.continent}</div>
                </div>
              </div>
              <button onClick={() => setSelectedCountry(null)} className="text-gray-500 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {/* Current metric highlight */}
              <div className="bg-blue-900/40 border border-blue-500/20 rounded-xl p-3">
                <div className="text-xs text-blue-300 mb-1">{selectedMetric?.label}</div>
                <div className="text-2xl font-black text-white">
                  {selectedCountry.value?.toFixed(2) ?? 'N/A'}
                  <span className="text-sm font-normal text-gray-400 ml-1">{selectedMetric?.unit}</span>
                </div>
                {selectedCountry.trend_7d != null && (
                  <div className={`flex items-center gap-1 text-xs mt-1 ${selectedCountry.trend_7d > 0 ? 'text-green-400' : selectedCountry.trend_7d < 0 ? 'text-red-400' : 'text-gray-400'}`}>
                    {selectedCountry.trend_7d > 0 ? <TrendingUp className="w-3 h-3" /> : selectedCountry.trend_7d < 0 ? <TrendingDown className="w-3 h-3" /> : <Minus className="w-3 h-3" />}
                    {Math.abs(selectedCountry.trend_7d).toFixed(1)}% vs last year
                  </div>
                )}
                <div className="text-xs text-gray-500 mt-1">
                  Quality: <span className={`font-medium ${selectedCountry.quality_flag === 'ok' ? 'text-green-400' : 'text-yellow-400'}`}>{selectedCountry.quality_flag || 'ok'}</span>
                </div>
              </div>

              {/* Population */}
              <div className="bg-white/5 rounded-xl p-3">
                <div className="text-xs text-gray-400 mb-1">Population</div>
                <div className="font-semibold">{selectedCountry.population?.toLocaleString() || 'N/A'}</div>
              </div>

              {/* Last updated */}
              <div className="bg-white/5 rounded-xl p-3">
                <div className="text-xs text-gray-400 mb-1">Data last updated</div>
                <div className="text-sm">{selectedCountry.last_updated ? new Date(selectedCountry.last_updated).toLocaleDateString() : 'N/A'}</div>
              </div>

              {/* All metrics for this country */}
              <div>
                <div className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">All Indicators</div>
                <div className="space-y-2">
                  {HEALTH_METRICS.map(metric => (
                    <button
                      key={metric.key}
                      onClick={() => setSelectedMetricKey(metric.key)}
                      className="w-full flex items-center justify-between text-xs p-2 rounded-lg hover:bg-white/5 transition-colors"
                    >
                      <span className="text-gray-400">{metric.label}</span>
                      <span className="font-medium text-white">
                        {metric.key === selectedMetricKey ? (selectedCountry.value?.toFixed(1) ?? '—') : '—'} {metric.unit}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-3 border-t border-white/10 text-xs text-gray-600 text-center">
              Fonti: WHO GHO · World Bank · IDF · UNICEF<br />
              Solo dati aggregati. Non consulenza medica.
            </div>
          </aside>
        )}
      </div>
    </div>
  );
}
