// app/api/webhooks/paypal/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { handlePayPalWebhook, verifyPayPalWebhook } from '@/backend/payments/paypal_engine';
import { logger } from '@/backend/lib/logger';

export async function POST(req: NextRequest) {
  try {
    const rawBody = await req.text();
    const headers: Record<string, string> = {};
    req.headers.forEach((value, key) => { headers[key] = value; });

    if (!verifyPayPalWebhook(headers, rawBody)) {
      logger.warn('paypal_webhook_invalid_signature');
      return NextResponse.json({ error: 'Invalid signature' }, { status: 400 });
    }

    const event = JSON.parse(rawBody);
    await handlePayPalWebhook(event, headers, rawBody);
    return NextResponse.json({ received: true });
  } catch (err: any) {
    logger.error('paypal_webhook_error', { error: err.message });
    return NextResponse.json({ error: 'Webhook processing failed' }, { status: 500 });
  }
}

// ============================================================
// app/api/webhooks/crypto/route.ts
// ============================================================
