# 🏥 PROMPT OMEGA HCI — Home Care International Workspace

**Monorepo multisegmento per Property, Care & Compliance - Swiss Edition**

---

## 📁 Struttura Workspace

```
PROMPT OMEGA HCI/
├── hci-v2/                    ← V2 legacy (mantiene per riferimento)
├── hci-os/                    ← Main OS core (architettura modello)
├── hci-backend/               ← Backend produzione (pagamenti, invoice, GDPR)
└── homecare-international/    ← Deploy PRINCIPALE (Next.js + Workers)
```

---

## 🚀 Quick Start

### Setup locale rapido

```bash
# 1. Ogni progetto ha package.json — installa dipendenze
cd hci-os && npm install
cd hci-backend && npm install
cd homecare-international && npm install

# 2. Copia .env.example in .env
cp hci-os/.env.example hci-os/.env
cp hci-backend/.env.example hci-backend/.env
cp homecare-international/.env.example homecare-international/.env

# 3. Compila i .env con credenziali reali (Supabase, Stripe, SMTP)

# 4. Avvia singoli progetti
cd hci-os && npm run dev
cd hci-backend && npm start
cd homecare-international && npm run dev
```

---

## 📊 Progetti nel Workspace

### **1. hci-v2** ⚪ (Reference/Legacy)
- **Status**: Incompleto — mantiene per storia e architettura
- **Stack**: Express backend (senza package.json ancora)
- **Uso**: Consultare per patterns architetturali
- **Non in produzione** ❌

```
hci-v2/
├── frontend/      ← Landing HTML/CSS/JS
├── backend/src/   ← Express routes (incomplete)
└── database/      ← Legacy SQL migrations
```

---

### **2. hci-os** ✅ (Production Reference)
- **Status**: Solido — OS di riferimento con 10 comandamenti (R1-R10)
- **Stack**: Express + React + Supabase
- **Segmenti**: Property OS, Care OS, Project OS, Admin, Franchise
- **Key Features**:
  - Row Level Security (RLS)
  - Dunning, Metering, Royalty workers
  - OpenAPI 3.1 spec (`docs/api/openapi.yaml`)
  - Architettura multi-tenant

```
hci-os/
├── backend/       ← Express.js core
│   ├── src/index.js
│   ├── routes/    ← auth, property, care, payments...
│   ├── services/  ← business logic
│   ├── workers/   ← dunning, metering, royalty, rde...
│   └── lib/       ← supabase, stripe
├── frontend/      ← React dashboards + landing
├── database/      ← 6 migration files (init → functions)
├── docs/
│   ├── api/openapi.yaml
│   ├── internal/architecture.md
│   └── internal/threat-model.md
└── README.md
```

**Installazione**:
```bash
cd hci-os
npm install
npm run dev        # localhost:4000
```

---

### **3. hci-backend** ⚙️ (Production Services)
- **Status**: Production v4.1 — servizi critici
- **Stack**: Express + Supabase + SumUp/Stripe + PDFKit
- **Key Features**:
  - Checkout server-side (SumUp + Stripe)
  - Invoicing automatico (PDF generazione)
  - GDPR/nLPD cancellazione dati
  - Webhooks idempotenti (Stripe/SumUp)
  - Crypto payments
  - IBAN management
  - Audit log immutabile

```
hci-backend/
├── src/
│   ├── server.js  ← Entry point
│   ├── routes/    ← checkout, webhooks, crypto, iban, invoice, gdpr, admin, pricing
│   ├── services/  ← paymentHandler (MASTER ENGINE 10-step), invoice, email, ledger, audit
│   └── lib/       ← supabase, stripe, queue
├── config/        ← plans.js, supabase.js
├── invoices/      ← PDF storage (gitignored)
├── logs/          ← Audit logs (gitignored)
└── README.md
```

**Installazione**:
```bash
cd hci-backend
npm install
npm run dev        # localhost:5000 (configurabile)
```

---

### **4. homecare-international** 🎯 (Main Production)
**⭐ QUESTO È IL DEPLOY PRINCIPALE**

- **Status**: Production — stack moderno Next.js 14
- **Stack**: Next.js 14 + React 18 + TypeScript + Supabase + Stripe v15 + Cesium (3D maps)
- **Key Features**:
  - UI moderna (Tailwind + Lucide icons)
  - Workers per billing, crediti, health data, invoicing
  - Integrazione Cesium per mappe 3D sanitarie
  - Stripe + PayPal payments
  - Global health monitoring
  - API routes Next.js (`app/api/*`)

```
homecare-international/
├── app/           ← Next.js 14 app directory
│   ├── page.tsx   ← Home
│   ├── api/       ← API routes
│   ├── auth/      ← Authentication
│   ├── dashboard/ ← Main dashboard
│   ├── billing/   ← Billing UI
│   └── global-health/ ← Health monitoring UI
├── backend/       ← Node.js API layers
│   ├── api/
│   ├── workers/   ← async jobs
│   ├── billing/
│   ├── payments/
│   ├── auth/
│   └── lib/
├── database/      ← schema.sql
├── workers/       ← Background workers
│   ├── index.js
│   ├── billing_worker.js
│   ├── credit_worker.js
│   ├── health_data_worker.js
│   └── invoice_worker.js
├── next.config.ts
├── tsconfig.json
├── tailwind.config.ts
└── DEPLOY.md      ← Istruzioni deploy Vercel
```

**Installazione**:
```bash
cd homecare-international
npm install
npm run dev        # localhost:3000
npm run build      # Production build
```

**Deploy**:
```bash
# Vercel (configurato in vercel.json)
vercel deploy
```

---

## 📋 Configurazione Workspace Unificata

Tutti i progetti hanno standardizzato:

✅ **Node.js Engine**: `>=18.0.0`
✅ **Linting**: `.eslintrc.json` (stesso per tutti)
✅ **.prettierrc.json** (formattazione uniforme)
✅ **.gitignore** (ignora node_modules, .env, logs, etc.)
✅ **.env.example** (template env variables)

---

## 🔄 Flusso Dati Tra Progetti

```
┌─────────────────────────────────────────────────────────────┐
│ homecare-international (Frontend + API)                     │
│  ├─ Next.js 14 UI                                          │
│  └─ app/api routes → chiama hci-backend                    │
└───────────────────┬─────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────────────────────┐
│ hci-backend (Production Services)                           │
│  ├─ checkout, payments, invoicing                          │
│  ├─ webhooks (Stripe/SumUp)                                │
│  └─ GDPR cleanup                                           │
└───────────────────┬─────────────────────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────────────────────┐
│ Supabase PostgreSQL (Database)                             │
│  └─ RLS, Audit log, Credit ledger                         │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│ hci-os (Reference Architecture)                             │
│  ├─ Workers: dunning, metering, royalty, rde, retention   │
│  └─ Not directly in production flow                        │
└─────────────────────────────────────────────────────────────┘
```

---

## 📝 10 Comandamenti (R1–R10)

Questi principi governano TUTTO il workspace:

| R | Regola | Implementazione |
|---|--------|-----------------|
| R1 | Sito pubblico sanitizzato | `/landing` pages senza secrets |
| R2 | Non medico — supporto only | No diagnosi, solo supporto |
| R3 | Zero secrets nel code | `.env.example` + gitignore |
| R4 | Credits Facade | Utente vede N crediti, non formule |
| R5 | No-loss pricing | Prezzi finali coprono costi |
| R6 | Owner zero-touch | Automazione totale |
| R7 | Safe-mode SOS inderogabile | SOS sempre attivo |
| R8 | No PHI su mappe | Solo dati aggregati |
| R9 | Webhook idempotenti | Inbox deduplication |
| R10 | Audit log immutabile | Append-only enforced |

---

## 🛠️ Comandi Comuni

### Sviluppo

```bash
# Installare dipendenze (da ogni folder)
npm install

# Dev mode con nodemon/next reload
npm run dev

# Build produzione
npm run build
npm start

# Lint check
npm run lint        # (quando aggiunto al package.json)

# Format code
npm run format      # (quando aggiunto al package.json)
```

### Database

```bash
# hci-os: applicare migrations su Supabase
1. Vai a Supabase SQL Editor
2. Copia-incolla 001_init.sql
3. Copia-incolla 002-006_all.sql
```

### Workers (homecare-international)

```bash
npm run workers:start      # All workers
npm run workers:credit     # Credit only
npm run workers:billing    # Billing only
```

---

## 🚨 Important Notes

⚠️ **NEVER commit .env files** — uso `.env.example` come template

⚠️ **Node.js version**: Assicurati >=18.0.0 installato (`node --version`)

⚠️ **Supabase creds**: Conserva `SUPABASE_SERVICE_ROLE_KEY` in vault/secrets, mai nel repo

⚠️ **Stripe keys**: `STRIPE_SECRET_KEY` must be in .env (prod vault)

⚠️ **Database migrations**: Sempre testare in staging prima di prod

---

## 📚 Key Resources

- **hci-os/docs/api/openapi.yaml** — Complete API spec
- **hci-os/docs/internal/architecture.md** — System architecture
- **hci-os/docs/internal/threat-model.md** — Security analysis
- **homecare-international/DEPLOY.md** — Vercel deployment guide
- **hci-backend/README.md** — Backend service docs

---

## 🎯 Next Steps (Post-Cleanup)

1. **Run `npm install`** in each project to verify dependencies
2. **Test `npm run dev`** in each (should start without errors)
3. **Lint entire workspace** once scripts enabled
4. **Database migrations** only on homecare-international
5. **Deploy** via `vercel deploy` (homecare-international main)

---

**Last Updated**: March 26, 2026
**Workspace Owner**: PROMPT OMEGA HCI Team
**Maintained by**: GitHub Copilot
