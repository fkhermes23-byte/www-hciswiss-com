// backend/payments/paypal_engine.ts
import { supabaseAdmin } from '../lib/db';
import { logger } from '../lib/logger';
import { blockUser, reactivateUser } from '../billing/billing_engine';
import crypto from 'crypto';

const PAYPAL_BASE_URL = process.env.PAYPAL_MODE === 'live'
  ? 'https://api-m.paypal.com'
  : 'https://api-m.sandbox.paypal.com';

let accessToken: string | null = null;
let tokenExpiry: Date | null = null;

async function getAccessToken(): Promise<string> {
  if (accessToken && tokenExpiry && tokenExpiry > new Date()) {
    return accessToken;
  }

  const credentials = Buffer.from(
    `${process.env.PAYPAL_CLIENT_ID}:${process.env.PAYPAL_CLIENT_SECRET}`
  ).toString('base64');

  const response = await fetch(`${PAYPAL_BASE_URL}/v1/oauth2/token`, {
    method: 'POST',
    headers: {
      Authorization: `Basic ${credentials}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: 'grant_type=client_credentials',
  });

  const data = await response.json();
  accessToken = data.access_token;
  tokenExpiry = new Date(Date.now() + (data.expires_in - 60) * 1000);
  return accessToken!;
}

// Create PayPal order
export async function createPayPalOrder(
  userId: string,
  amountEUR: number,
  invoiceId: string
): Promise<{ orderId: string; approveUrl: string }> {
  const token = await getAccessToken();

  const response = await fetch(`${PAYPAL_BASE_URL}/v2/checkout/orders`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
      'PayPal-Request-Id': `hci-${invoiceId}`,
    },
    body: JSON.stringify({
      intent: 'CAPTURE',
      purchase_units: [{
        reference_id: invoiceId,
        amount: {
          currency_code: 'EUR',
          value: amountEUR.toFixed(2),
        },
        description: `HomeCareInternational.ch - Invoice ${invoiceId}`,
        custom_id: userId,
      }],
      application_context: {
        brand_name: 'Home Care International',
        return_url: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard/billing?paypal=success`,
        cancel_url: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard/billing?paypal=cancel`,
      },
    }),
  });

  const order = await response.json();
  if (!response.ok) throw new Error(order.message || 'PayPal order creation failed');

  const approveLink = order.links?.find((l: any) => l.rel === 'approve');
  return { orderId: order.id, approveUrl: approveLink?.href };
}

// Capture PayPal payment
export async function capturePayPalOrder(
  orderId: string
): Promise<{ success: boolean; captureId?: string }> {
  const token = await getAccessToken();

  const response = await fetch(`${PAYPAL_BASE_URL}/v2/checkout/orders/${orderId}/capture`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
  });

  const capture = await response.json();
  if (!response.ok) return { success: false };

  const captureUnit = capture.purchase_units?.[0]?.payments?.captures?.[0];
  if (captureUnit?.status === 'COMPLETED') {
    return { success: true, captureId: captureUnit.id };
  }

  return { success: false };
}

// Verify PayPal webhook signature
export function verifyPayPalWebhook(
  headers: Record<string, string>,
  body: string
): boolean {
  // PayPal webhook verification - in production use PayPal's verification API
  const webhookId = process.env.PAYPAL_WEBHOOK_ID;
  if (!webhookId) return false;

  const transmissionId = headers['paypal-transmission-id'];
  const timestamp = headers['paypal-transmission-time'];
  const certUrl = headers['paypal-cert-url'];
  const actualSig = headers['paypal-transmission-sig'];

  if (!transmissionId || !timestamp || !certUrl || !actualSig) return false;

  const message = `${transmissionId}|${timestamp}|${webhookId}|${crypto.createHash('crc32').update(body).digest('hex')}`;
  // Full verification requires downloading cert - simplified here
  return true; // In production: verify signature against PayPal's cert
}

// Handle PayPal webhook
export async function handlePayPalWebhook(
  event: any,
  headers: Record<string, string>,
  rawBody: string
): Promise<void> {
  // Store event
  await supabaseAdmin.from('webhook_events').insert({
    provider: 'paypal',
    event_id: event.id,
    event_type: event.event_type,
    payload: event,
  }).onConflict('event_id,provider').ignore();

  switch (event.event_type) {
    case 'PAYMENT.CAPTURE.COMPLETED': {
      const resource = event.resource;
      const invoiceId = resource.supplementary_data?.related_ids?.order_id;
      const userId = resource.custom_id;

      if (invoiceId) {
        await supabaseAdmin
          .from('invoices')
          .update({
            status: 'paid',
            paid_at: new Date().toISOString(),
            paypal_order_id: resource.id,
          })
          .eq('id', invoiceId);

        await supabaseAdmin.from('payments').insert({
          user_id: userId,
          invoice_id: invoiceId,
          provider: 'paypal',
          status: 'succeeded',
          amount: parseFloat(resource.amount.value),
          currency: resource.amount.currency_code,
          paypal_capture_id: resource.id,
          transaction_id: resource.id,
        });
      }

      if (userId) {
        const { data: user } = await supabaseAdmin
          .from('users')
          .select('account_status')
          .eq('id', userId)
          .single();
        if (user?.account_status === 'suspended') await reactivateUser(userId);
      }
      break;
    }

    case 'PAYMENT.CAPTURE.DENIED': {
      const resource = event.resource;
      const userId = resource.custom_id;
      if (userId) await blockUser(userId, 'PayPal payment denied');
      break;
    }
  }

  await supabaseAdmin
    .from('webhook_events')
    .update({ processed: true, processed_at: new Date().toISOString() })
    .eq('event_id', event.id)
    .eq('provider', 'paypal');
}
