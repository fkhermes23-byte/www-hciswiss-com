// app/api/auth/logout/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { revokeSession } from '@/backend/auth/auth';

export async function POST(req: NextRequest) {
  const token = req.cookies.get('hci_token')?.value ||
    req.headers.get('authorization')?.replace('Bearer ', '');

  if (token) await revokeSession(token);

  const response = NextResponse.json({ success: true });
  response.cookies.delete('hci_token');
  return response;
}
