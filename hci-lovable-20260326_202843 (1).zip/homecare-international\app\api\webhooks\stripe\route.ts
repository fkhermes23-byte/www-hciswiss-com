// app/api/webhooks/stripe/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { handleStripeWebhook } from '@/backend/payments/stripe_engine';
import { logger } from '@/backend/lib/logger';

export const config = { api: { bodyParser: false } };

export async function POST(req: NextRequest) {
  const signature = req.headers.get('stripe-signature');
  if (!signature) {
    return NextResponse.json({ error: 'Missing signature' }, { status: 400 });
  }

  try {
    const payload = await req.text();
    await handleStripeWebhook(payload, signature);
    return NextResponse.json({ received: true });
  } catch (err: any) {
    logger.error('stripe_webhook_error', { error: err.message });
    return NextResponse.json({ error: err.message }, { status: 400 });
  }
}
