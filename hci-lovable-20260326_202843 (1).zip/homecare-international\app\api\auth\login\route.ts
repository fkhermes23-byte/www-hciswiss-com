// app/api/auth/login/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/backend/lib/db';
import { verifyPassword, generateToken, createSession } from '@/backend/auth/auth';
import { logger } from '@/backend/lib/logger';
import { z } from 'zod';

const LoginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const validation = LoginSchema.safeParse(body);

    if (!validation.success) {
      return NextResponse.json({ error: 'Invalid credentials' }, { status: 422 });
    }

    const { email, password } = validation.data;

    const { data: user } = await supabaseAdmin
      .from('users')
      .select('id, email, password_hash, role, account_status, credit_balance')
      .eq('email', email.toLowerCase())
      .single();

    if (!user) {
      // Timing-safe: still hash even if no user found
      await verifyPassword(password, '$2a$12$invalidhashpadding000000000000000000000000000000000000000');
      return NextResponse.json({ error: 'Invalid email or password' }, { status: 401 });
    }

    const validPassword = await verifyPassword(password, user.password_hash);
    if (!validPassword) {
      logger.warn('login_failed_invalid_password', { email });
      return NextResponse.json({ error: 'Invalid email or password' }, { status: 401 });
    }

    if (user.account_status === 'deleted') {
      return NextResponse.json({ error: 'Account not found' }, { status: 401 });
    }

    if (user.account_status === 'suspended') {
      return NextResponse.json({
        error: 'Account suspended',
        message: 'Your account has been suspended due to a failed payment. Please update your payment method.',
        code: 'ACCOUNT_SUSPENDED',
      }, { status: 403 });
    }

    if (user.account_status === 'blocked') {
      return NextResponse.json({
        error: 'Account blocked',
        code: 'ACCOUNT_BLOCKED',
      }, { status: 403 });
    }

    const token = generateToken({
      userId: user.id,
      email: user.email,
      role: user.role,
      sessionId: 'pending',
    });

    const sessionId = await createSession(user.id, token, req);

    // Update last login
    await supabaseAdmin
      .from('users')
      .update({ last_login_at: new Date().toISOString() })
      .eq('id', user.id);

    logger.info('user_logged_in', { userId: user.id, email: user.email });

    const response = NextResponse.json({
      success: true,
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        accountStatus: user.account_status,
        creditBalance: user.credit_balance,
      },
      token,
    });

    response.cookies.set('hci_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60,
      path: '/',
    });

    return response;

  } catch (err: any) {
    logger.error('login_error', { error: err.message });
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
