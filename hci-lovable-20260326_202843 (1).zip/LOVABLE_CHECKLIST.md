# ✅ LOVABLE LAUNCH CHECKLIST

## 🎯 Pre-Export Checklist

### Code Quality
- [ ] `npm run lint:homecare` — zero errors
- [ ] `npm run format:homecare` — code formatted
- [ ] `npm install` — dependencies clean
- [ ] `npm run build` — builds without errors
- [ ] No console.error/warnings in dev mode
- [ ] No hardcoded secrets in code

### Environment
- [ ] `.env.example` has all required vars documented
- [ ] `.env` file is in `.gitignore` ✅
- [ ] Node.js version >= 18.0.0
- [ ] npm/yarn updated to latest

### Dependencies
- [ ] `package.json` is clean (no unused deps)
- [ ] All peer dependencies resolved
- [ ] No security vulnerabilities: `npm audit`
- [ ] Lock file (package-lock.json) is committed

### Documentation
- [ ] README.md is complete
- [ ] LOVABLE_SETUP.md exists
- [ ] DEPLOY.md is ready
- [ ] API routes documented
- [ ] Database schema (schema.sql) is current
- [ ] Environment variables documented

### Database
- [ ] `database/schema.sql` is executable
- [ ] All migrations tested on Supabase
- [ ] RLS policies configured
- [ ] Audit triggers in place

### Frontend
- [ ] All pages load without errors
- [ ] Responsive design tested (mobile/desktop)
- [ ] Dark mode works (if implemented)
- [ ] Forms validate correctly
- [ ] API calls work with .env vars
- [ ] Images optimized
- [ ] No broken links

### Backend
- [ ] All API routes tested
- [ ] Error handling implemented
- [ ] Rate limiting configured
- [ ] CORS settings correct
- [ ] Webhooks configured
- [ ] Workers can be toggled off for MVP

### Security
- [ ] No secrets in code ✅
- [ ] CORS origins whitelisted
- [ ] Rate limiting active
- [ ] Input validation in place
- [ ] SQL injection prevention (using Supabase ORM)
- [ ] No SQL queries concatenated

### Testing (Optional but Recommended)
- [ ] Unit tests pass
- [ ] Integration tests pass
- [ ] E2E tests pass
- [ ] No flaky tests

---

## 📦 Export Procedure

### Step 1: Prepare Repository
```bash
# Clean build artifacts
rm -rf .next dist node_modules
npm install  # Fresh install

# Run full build
npm run build

# No errors? Good!
```

### Step 2: Run Export Script

**Windows (PowerShell):**
```powershell
.\export-for-lovable.ps1
```

**Mac/Linux (Bash):**
```bash
bash export-for-lovable.sh
```

### Step 3: Verify Archive
```bash
# Extract to test
unzip hci-lovable-*.zip -d test-extract/
cd test-extract/homecare-international
npm install
npm run build  # Should succeed
```

### Step 4: Upload to Lovable
1. Go to https://lovable.dev
2. Sign in / Create account
3. Click "New Project"
4. Select "Import Code"
5. Upload `hci-lovable-*.zip`
6. Wait for import to complete
7. Configure environment variables in Lovable
8. Click "Deploy"

---

## 🔑 Environment Variables to Configure in Lovable

After importing, configure these in Lovable's environment settings:

```
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
STRIPE_PUBLIC_KEY=
STRIPE_SECRET_KEY=
STRIPE_WEBHOOK_SECRET=
PAYPAL_CLIENT_ID=
PAYPAL_CLIENT_SECRET=
SMTP_HOST=
SMTP_PORT=
SMTP_USER=
SMTP_PASS=
EMAIL_FROM=
NODE_ENV=production
NEXT_PUBLIC_APP_URL=
```

---

## 🚀 Post-Deploy Verification

After Lovable deploys:

- [ ] Homepage loads
- [ ] Authentication works
- [ ] Database queries succeed
- [ ] Stripe integration ready (test mode)
- [ ] Email sending works
- [ ] Workers run on schedule
- [ ] All API routes respond
- [ ] Error pages show (404, 500)
- [ ] Webhooks are registered in Stripe
- [ ] Monitoring/logging active

---

## 🆘 Troubleshooting Lovable Issues

### Build Fails
```
Check: Node version in Lovable build settings >= 18
Check: All env vars configured
Check: No hardcoded paths (/Users/..., C:\Users\...)
```

### API Routes Return 404
```
Check: Routes are in app/api/* (Next.js convention)
Check: .env variables match backend expectations
```

### Database Connection Fails
```
Check: SUPABASE_SERVICE_ROLE_KEY is set
Check: Database is public-accessible (not private)
Check: RLS policies allow current user
```

### Stripe Integration Fails
```
Check: STRIPE_SECRET_KEY is correct
Check: Webhook secret is registered in Stripe
Check: Webhook endpoint URL matches Lovable domain
```

---

## 📊 Success Metrics

After deploy in Lovable:

- ✅ All pages load in < 2s
- ✅ API response time < 500ms
- ✅ No 5xx errors
- ✅ Database queries < 100ms
- ✅ Workers execute on schedule
- ✅ Third-party integrations (Stripe, etc.) working
- ✅ Monitoring dashboard shows activity

---

## 🎉 You're Ready!

Package is clean, documented, and ready for Lovable deployment.

**Questions?** Check:
- LOVABLE_SETUP.md
- README.md
- app/**/*.md (component docs)

---

**Deployed Date**: ___________
**Lovable Project URL**: ___________
**Status**: 🟢 Live | 🟡 Staging | 🔴 Development
