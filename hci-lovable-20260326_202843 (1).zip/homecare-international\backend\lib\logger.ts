// backend/lib/logger.ts
import { supabaseAdmin } from './db';

type LogLevel = 'info' | 'warn' | 'error' | 'debug';

class Logger {
  private async writeToDb(level: LogLevel, category: string, message: string, meta?: any): Promise<void> {
    try {
      await supabaseAdmin.from('logs').insert({
        level,
        category,
        message,
        user_id: meta?.userId || null,
        ip_address: meta?.ip || null,
        metadata: meta || {},
      });
    } catch {}
  }

  info(category: string, meta?: any): void {
    console.log(`[INFO] ${category}`, meta || '');
    this.writeToDb('info', category, category, meta);
  }

  warn(category: string, meta?: any): void {
    console.warn(`[WARN] ${category}`, meta || '');
    this.writeToDb('warn', category, category, meta);
  }

  error(category: string, meta?: any): void {
    console.error(`[ERROR] ${category}`, meta || '');
    this.writeToDb('error', category, category, meta);
  }

  debug(category: string, meta?: any): void {
    if (process.env.NODE_ENV !== 'production') {
      console.debug(`[DEBUG] ${category}`, meta || '');
    }
    this.writeToDb('debug', category, category, meta);
  }
}

export const logger = new Logger();
