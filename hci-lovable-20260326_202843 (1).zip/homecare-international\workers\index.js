// workers/index.js - Master worker launcher
'use strict';

require('dotenv').config({ path: '../.env.local' });

const { fork } = require('child_process');
const path = require('path');

const workers = [
  { name: 'CreditWorker', file: './credit_worker.js' },
  { name: 'BillingWorker', file: './billing_worker.js' },
  { name: 'HealthDataWorker', file: './health_data_worker.js' },
];

const processes = [];

function startWorker({ name, file }) {
  const workerPath = path.resolve(__dirname, file);
  console.log(`[Master] Starting ${name}...`);

  const child = fork(workerPath, [], {
    env: process.env,
    silent: false,
  });

  child.on('exit', (code, signal) => {
    console.error(`[Master] ${name} exited with code ${code}, signal ${signal}. Restarting in 5s...`);
    setTimeout(() => startWorker({ name, file }), 5000);
  });

  child.on('error', (err) => {
    console.error(`[Master] ${name} error:`, err);
  });

  processes.push({ name, child });
  return child;
}

// Start all workers
workers.forEach(startWorker);

console.log('[Master] All workers started');
console.log('[Master] Workers running:');
console.log('  - CreditWorker: every 60 seconds');
console.log('  - BillingWorker: every 15 minutes');
console.log('  - HealthDataWorker: daily at 3 AM');

// Graceful shutdown
async function shutdown() {
  console.log('[Master] Shutting down all workers...');
  for (const { name, child } of processes) {
    console.log(`[Master] Stopping ${name}...`);
    child.kill('SIGTERM');
  }
  setTimeout(() => process.exit(0), 3000);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
