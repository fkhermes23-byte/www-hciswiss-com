// app/api/payments/setup/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/backend/auth/auth';
import { createSetupIntent, getPaymentMethods } from '@/backend/payments/stripe_engine';
import { logger } from '@/backend/lib/logger';

export async function GET(req: NextRequest) {
  try {
    const user = await requireAuth(req);
    const methods = await getPaymentMethods(user.id);
    return NextResponse.json({ paymentMethods: methods });
  } catch (err: any) {
    if (err.message === 'UNAUTHORIZED') return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    return NextResponse.json({ error: 'Failed to get payment methods' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await requireAuth(req);
    const clientSecret = await createSetupIntent(user.id);
    logger.info('setup_intent_created', { userId: user.id });
    return NextResponse.json({ clientSecret });
  } catch (err: any) {
    if (err.message === 'UNAUTHORIZED') return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    logger.error('setup_intent_failed', { error: err.message });
    return NextResponse.json({ error: 'Failed to create setup intent' }, { status: 500 });
  }
}
