// app/api/user/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/backend/auth/auth';
import { supabaseAdmin } from '@/backend/lib/db';

export async function GET(req: NextRequest) {
  try {
    const authUser = await requireAuth(req);

    const { data: user } = await supabaseAdmin
      .from('users')
      .select('id, email, role, account_status, credit_balance, currency, subscription_type, subscription_status, created_at, last_login_at, monthly_usage_minutes, price_multiplier')
      .eq('id', authUser.id)
      .single();

    // Get active usage session
    const { data: activeSession } = await supabaseAdmin
      .from('usage_sessions')
      .select('id, start_time, minutes_used, amount_charged, price_per_minute')
      .eq('user_id', authUser.id)
      .is('end_time', null)
      .single();

    // Get payment methods
    const { data: payments } = await supabaseAdmin
      .from('users')
      .select('stripe_payment_method, stripe_customer_id, paypal_customer_id, crypto_wallet')
      .eq('id', authUser.id)
      .single();

    return NextResponse.json({
      user,
      activeSession,
      hasPaymentMethod: !!(payments?.stripe_payment_method || payments?.paypal_customer_id),
    });

  } catch (err: any) {
    if (err.message === 'UNAUTHORIZED') return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (err.message === 'ACCOUNT_SUSPENDED') return NextResponse.json({ error: 'Account suspended', code: 'SUSPENDED' }, { status: 403 });
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
