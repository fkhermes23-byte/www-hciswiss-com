// app/layout.tsx
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { Toaster } from 'react-hot-toast';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'Home Care International — Global Health Platform',
  description: 'Professional global healthcare intelligence and digital health services platform',
  keywords: ['home care', 'health', 'international', 'telemedicine', 'digital health'],
  openGraph: {
    title: 'Home Care International',
    description: 'Global Health Platform',
    url: 'https://homecareinternational.ch',
    siteName: 'Home Care International',
    locale: 'en_US',
    type: 'website',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="h-full">
      <body className={`${inter.className} h-full bg-gray-50`}>
        <Toaster position="top-right" />
        {children}
      </body>
    </html>
  );
}
