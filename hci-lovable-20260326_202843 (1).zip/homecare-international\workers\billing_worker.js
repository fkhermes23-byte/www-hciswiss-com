// workers/billing_worker.js — Usage billing every 31 minutes + subscription renewal
'use strict';

const BILLING_CYCLE_MINUTES = 31;
const SUBSCRIPTION_PRICES = {
  daily:   { private: 3.60,  professional: 7.20,  enterprise: 10.80 },
  weekly:  { private: 21.00, professional: 42.00, enterprise: 63.00 },
  monthly: { private: 72.00, professional: 144.00, enterprise: 216.00 },
  annual:  { private: 720.00, professional: 1440.00, enterprise: 2160.00 },
};

const cron = require('node-cron');
const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

const BILLING_CYCLE_MINUTES = parseInt(process.env.BILLING_CYCLE_MINUTES || '15');
const DEFAULT_TAX_RATE = parseFloat(process.env.DEFAULT_TAX_RATE || '0.077');
const MIN_CHARGE_EUR = 0.50; // Minimum charge to trigger billing

async function runBillingCycle() {
  const now = new Date();
  console.log(`[BillingWorker] Running billing cycle at ${now.toISOString()}`);

  const cycleCutoff = new Date(now.getTime() - BILLING_CYCLE_MINUTES * 60 * 1000);

  try {
    // Get users due for billing
    const { data: users } = await supabase
      .from('users')
      .select('id, email, role, currency, stripe_customer_id, stripe_payment_method, paypal_customer_id, last_billing_timestamp, credit_balance, account_status')
      .neq('role', 'admin')
      .or(`last_billing_timestamp.is.null,last_billing_timestamp.lt.${cycleCutoff.toISOString()}`);

    if (!users || users.length === 0) {
      console.log('[BillingWorker] No users due for billing');
      return;
    }

    console.log(`[BillingWorker] Processing ${users.length} users`);

    for (const user of users) {
      try {
        await processUserBilling(user, now);
      } catch (err) {
        console.error(`[BillingWorker] Error processing user ${user.id}:`, err);
      }
    }

  } catch (err) {
    console.error('[BillingWorker] Fatal error:', err);
  }
}

async function processUserBilling(user, now) {
  const periodStart = user.last_billing_timestamp
    ? new Date(user.last_billing_timestamp)
    : new Date(now.getTime() - BILLING_CYCLE_MINUTES * 60 * 1000);
  const periodEnd = now;

  // Get unbilled completed sessions
  const { data: sessions } = await supabase
    .from('usage_sessions')
    .select('*')
    .eq('user_id', user.id)
    .eq('billed', false)
    .gte('start_time', periodStart.toISOString())
    .not('end_time', 'is', null)
    .order('start_time', { ascending: true });

  const minutesUsed = (sessions || []).reduce((sum, s) => sum + (s.minutes_used || 0), 0);
  const totalCost = (sessions || []).reduce((sum, s) => sum + (s.amount_charged || 0), 0);

  // Always update last billing timestamp
  await supabase
    .from('users')
    .update({ last_billing_timestamp: now.toISOString() })
    .eq('id', user.id);

  if (totalCost < MIN_CHARGE_EUR) {
    console.log(`[BillingWorker] User ${user.id}: Cost €${totalCost.toFixed(4)} below minimum, skipping invoice`);
    return;
  }

  const taxAmount = Math.round(totalCost * DEFAULT_TAX_RATE * 100) / 100;
  const totalAmount = Math.round((totalCost + taxAmount) * 100) / 100;
  const pricePerMinute = minutesUsed > 0 ? totalCost / minutesUsed : 0;

  // Create invoice
  const lineItems = (sessions || []).map(s => ({
    description: `${new Date(s.start_time).toLocaleString()} – ${new Date(s.end_time || now).toLocaleString()}`,
    minutes: s.minutes_used,
    rate: s.price_per_minute,
    amount: s.amount_charged,
  }));

  const { data: invoice, error: invoiceError } = await supabase
    .from('invoices')
    .insert({
      user_id: user.id,
      amount: totalCost,
      tax_amount: taxAmount,
      total_amount: totalAmount,
      currency: user.currency || 'EUR',
      status: 'pending',
      minutes_used: minutesUsed,
      price_per_minute: pricePerMinute,
      period_start: periodStart.toISOString(),
      period_end: periodEnd.toISOString(),
      payment_provider: user.stripe_payment_method ? 'stripe' : user.paypal_customer_id ? 'paypal' : null,
      due_date: new Date(now.getTime() + 24 * 60 * 60 * 1000).toISOString(),
      line_items: lineItems,
    })
    .select()
    .single();

  if (invoiceError || !invoice) {
    console.error(`[BillingWorker] Failed to create invoice for user ${user.id}:`, invoiceError);
    return;
  }

  console.log(`[BillingWorker] Created invoice ${invoice.invoice_number} for user ${user.id}: €${totalAmount}`);

  // Mark sessions as billed
  const sessionIds = (sessions || []).map(s => s.id);
  if (sessionIds.length > 0) {
    await supabase
      .from('usage_sessions')
      .update({ billed: true, invoice_id: invoice.id })
      .in('id', sessionIds);
  }

  // Attempt payment
  let paymentSuccess = false;

  if (user.stripe_payment_method && user.stripe_customer_id) {
    paymentSuccess = await attemptStripePayment(user, invoice, totalAmount);
  } else if (user.paypal_customer_id) {
    paymentSuccess = await attemptPayPalPayment(user, invoice, totalAmount);
  }

  if (paymentSuccess) {
    await supabase
      .from('invoices')
      .update({ status: 'paid', paid_at: now.toISOString() })
      .eq('id', invoice.id);

    console.log(`[BillingWorker] Payment succeeded for invoice ${invoice.invoice_number}`);

  } else {
    await supabase
      .from('invoices')
      .update({ status: 'failed' })
      .eq('id', invoice.id);

    // Suspend user
    if (user.account_status === 'active') {
      await supabase
        .from('users')
        .update({ account_status: 'suspended' })
        .eq('id', user.id);

      // Revoke all sessions
      await supabase
        .from('sessions')
        .update({ revoked: true, revoked_at: now.toISOString() })
        .eq('user_id', user.id)
        .eq('revoked', false);

      await supabase
        .from('usage_sessions')
        .update({ end_time: now.toISOString() })
        .eq('user_id', user.id)
        .is('end_time', null);

      await supabase.from('logs').insert({
        level: 'warn',
        category: 'user_suspended_payment_failed',
        message: `User suspended: payment failed for invoice ${invoice.invoice_number}`,
        user_id: user.id,
        metadata: { invoice_id: invoice.id, amount: totalAmount },
      });

      console.log(`[BillingWorker] User ${user.id} SUSPENDED - payment failed`);
    }
  }

  await supabase.from('logs').insert({
    level: 'info',
    category: 'billing_cycle_completed',
    message: `Billing cycle completed for user`,
    user_id: user.id,
    metadata: {
      invoice_id: invoice.id,
      invoice_number: invoice.invoice_number,
      amount: totalAmount,
      minutes_used: minutesUsed,
      payment_success: paymentSuccess,
    },
  });
}

async function attemptStripePayment(user, invoice, amountEUR) {
  try {
    const Stripe = require('stripe');
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

    const amountCents = Math.round(amountEUR * 100);
    if (amountCents < 50) return true; // Below Stripe minimum

    const paymentIntent = await stripe.paymentIntents.create({
      amount: amountCents,
      currency: (user.currency || 'EUR').toLowerCase(),
      customer: user.stripe_customer_id,
      payment_method: user.stripe_payment_method,
      off_session: true,
      confirm: true,
      description: `Invoice ${invoice.invoice_number}`,
      metadata: {
        userId: user.id,
        invoiceId: invoice.id,
      },
    });

    if (paymentIntent.status === 'succeeded') {
      await supabase
        .from('invoices')
        .update({ stripe_payment_id: paymentIntent.id })
        .eq('id', invoice.id);

      await supabase.from('payments').insert({
        user_id: user.id,
        invoice_id: invoice.id,
        provider: 'stripe',
        status: 'succeeded',
        amount: amountEUR,
        currency: user.currency || 'EUR',
        stripe_payment_intent_id: paymentIntent.id,
        transaction_id: paymentIntent.id,
      });

      return true;
    }

    return false;

  } catch (err) {
    console.error(`[BillingWorker] Stripe payment failed for user ${user.id}:`, err.message);
    await supabase.from('payments').insert({
      user_id: user.id,
      invoice_id: invoice.id,
      provider: 'stripe',
      status: 'failed',
      amount: amountEUR,
      error_code: err.code,
      error_message: err.message,
    });
    return false;
  }
}

async function attemptPayPalPayment(user, invoice, amountEUR) {
  // PayPal requires user interaction for initial payment
  // For subscriptions, it can be automated
  // Log for manual processing
  console.log(`[BillingWorker] PayPal payment required for user ${user.id}, invoice ${invoice.id}`);

  await supabase.from('payments').insert({
    user_id: user.id,
    invoice_id: invoice.id,
    provider: 'paypal',
    status: 'pending',
    amount: amountEUR,
    error_message: 'PayPal requires user redirect for payment',
  });

  return false; // Will require user action
}

// Run every 15 minutes
cron.schedule('*/15 * * * *', runBillingCycle);

// Run immediately on start
runBillingCycle();

console.log(`[BillingWorker] Started - running every ${BILLING_CYCLE_MINUTES} minutes`);

process.on('SIGTERM', () => {
  console.log('[BillingWorker] Shutting down gracefully...');
  process.exit(0);
});
