// app/dashboard/admin/page.tsx
'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  Users, TrendingUp, DollarSign, Activity, AlertTriangle,
  CheckCircle, BarChart3, Clock, Globe, Heart
} from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function AdminDashboard() {
  const router = useRouter();
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const token = typeof window !== 'undefined' ? localStorage.getItem('hci_token') : null;
  const headers = token ? { Authorization: `Bearer ${token}` } : {};

  useEffect(() => {
    loadStats();
    const interval = setInterval(loadStats, 30000); // Refresh every 30s
    return () => clearInterval(interval);
  }, []);

  const loadStats = async () => {
    try {
      const res = await fetch('/api/admin/stats', { headers, credentials: 'include' });
      if (res.status === 401) { router.push('/auth/login'); return; }
      if (res.status === 403) { router.push('/dashboard'); return; }
      const data = await res.json();
      setStats(data);
    } catch {} finally {
      setLoading(false);
    }
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
    </div>
  );

  const dailyRevenueData = stats ? Object.entries(stats.dailyRevenue || {})
    .map(([date, amount]) => ({ date: date.slice(5), amount: Math.round(amount as number * 100) / 100 }))
    .slice(-14) : [];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-8 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <Heart className="w-4 h-4 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-gray-900">Admin Dashboard</h1>
              <p className="text-xs text-gray-500">HomeCare International</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-sm text-green-600">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              Live
            </div>
            <Link href="/dashboard" className="text-sm text-gray-500 hover:text-gray-700">User View</Link>
          </div>
        </div>
      </header>

      <div className="p-8">
        {/* Revenue metrics */}
        <div className="grid grid-cols-5 gap-4 mb-6">
          {[
            { label: 'Revenue/min', value: `€${(stats?.revenue?.perMinute || 0).toFixed(3)}`, icon: Zap, color: 'text-blue-600', bg: 'bg-blue-50' },
            { label: 'Revenue/hour', value: `€${(stats?.revenue?.perHour || 0).toFixed(2)}`, icon: Clock, color: 'text-violet-600', bg: 'bg-violet-50' },
            { label: 'Today', value: `€${(stats?.revenue?.today || 0).toFixed(2)}`, icon: TrendingUp, color: 'text-green-600', bg: 'bg-green-50' },
            { label: 'This Month', value: `€${(stats?.revenue?.thisMonth || 0).toFixed(2)}`, icon: BarChart3, color: 'text-orange-600', bg: 'bg-orange-50' },
            { label: 'Total Revenue', value: `€${(stats?.revenue?.total || 0).toFixed(2)}`, icon: DollarSign, color: 'text-emerald-600', bg: 'bg-emerald-50' },
          ].map((m, i) => (
            <div key={i} className="bg-white rounded-xl border border-gray-200 p-4">
              <div className={`w-8 h-8 ${m.bg} rounded-lg flex items-center justify-center mb-3`}>
                <m.icon className={`w-4 h-4 ${m.color}`} />
              </div>
              <div className="text-xl font-black text-gray-900">{m.value}</div>
              <div className="text-xs text-gray-500 mt-0.5">{m.label}</div>
            </div>
          ))}
        </div>

        {/* User stats */}
        <div className="grid grid-cols-4 gap-4 mb-6">
          {[
            { label: 'Total Users', value: stats?.users?.total || 0, icon: Users, color: 'text-blue-600' },
            { label: 'Active Users', value: stats?.users?.active || 0, icon: CheckCircle, color: 'text-green-600' },
            { label: 'Suspended', value: stats?.users?.suspended || 0, icon: AlertTriangle, color: 'text-red-600' },
            { label: 'Live Sessions', value: stats?.activeSessions || 0, icon: Activity, color: 'text-purple-600' },
          ].map((s, i) => (
            <div key={i} className="bg-white rounded-xl border border-gray-200 p-4 flex items-center gap-3">
              <s.icon className={`w-6 h-6 ${s.color}`} />
              <div>
                <div className="text-2xl font-black text-gray-900">{s.value}</div>
                <div className="text-xs text-gray-500">{s.label}</div>
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-6">
          {/* Revenue chart */}
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h2 className="font-bold text-gray-900 mb-4">Revenue (Last 14 Days)</h2>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={dailyRevenueData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip formatter={(v) => [`€${v}`, 'Revenue']} />
                <Area type="monotone" dataKey="amount" stroke="#3182ce" fill="#ebf4ff" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Users by role */}
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h2 className="font-bold text-gray-900 mb-4">Users by Role</h2>
            <div className="space-y-3">
              {Object.entries(stats?.usersByRole || {}).map(([role, count]) => {
                const total = Object.values(stats?.usersByRole || {}).reduce((a: any, b: any) => a + b, 0) as number;
                const pct = total > 0 ? Math.round((count as number) / total * 100) : 0;
                return (
                  <div key={role}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium text-gray-700 capitalize">{role}</span>
                      <span className="text-sm text-gray-500">{count as number} ({pct}%)</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-blue-500 rounded-full"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Recent invoices */}
          <div className="bg-white rounded-xl border border-gray-200 p-6 col-span-2">
            <h2 className="font-bold text-gray-900 mb-4">Recent Invoices</h2>
            <div className="overflow-x-auto">
              <table className="w-full data-table">
                <thead>
                  <tr>
                    <th>Invoice #</th>
                    <th>User</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Date</th>
                  </tr>
                </thead>
                <tbody>
                  {(stats?.recentInvoices || []).map((inv: any) => (
                    <tr key={inv.id}>
                      <td className="font-mono text-xs font-medium">{inv.invoice_number}</td>
                      <td>
                        <div>{inv.users?.email}</div>
                        <div className="text-xs text-gray-400 capitalize">{inv.users?.role}</div>
                      </td>
                      <td className="font-semibold">€{(inv.total_amount || 0).toFixed(2)}</td>
                      <td>
                        <span className={`badge ${inv.status === 'paid' ? 'badge-success' : inv.status === 'failed' ? 'badge-danger' : 'badge-warning'}`}>
                          {inv.status}
                        </span>
                      </td>
                      <td className="text-xs text-gray-400">{new Date(inv.created_at).toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Need to import Zap
import { Zap } from 'lucide-react';
