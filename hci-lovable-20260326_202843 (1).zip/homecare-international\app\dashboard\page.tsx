// app/dashboard/page.tsx
'use client';
import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  BarChart3, CreditCard, FileText, Globe, Clock, TrendingUp,
  AlertTriangle, CheckCircle, Activity, LogOut, Settings,
  Heart, User, Shield, Bell, ChevronRight, Zap
} from 'lucide-react';
import toast from 'react-hot-toast';

interface UserData {
  id: string;
  email: string;
  role: string;
  account_status: string;
  credit_balance: number;
  currency: string;
  monthly_usage_minutes: number;
}

interface ActiveSession {
  id: string;
  start_time: string;
  minutes_used: number;
  amount_charged: number;
  price_per_minute: number;
}

export default function DashboardPage() {
  const router = useRouter();
  const [user, setUser] = useState<UserData | null>(null);
  const [activeSession, setActiveSession] = useState<ActiveSession | null>(null);
  const [invoices, setInvoices] = useState<any[]>([]);
  const [usage, setUsage] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [liveMinutes, setLiveMinutes] = useState(0);
  const [liveCost, setLiveCost] = useState(0);
  const heartbeatRef = useRef<NodeJS.Timeout | null>(null);
  const tickRef = useRef<NodeJS.Timeout | null>(null);

  const token = typeof window !== 'undefined' ? localStorage.getItem('hci_token') : null;
  const headers = token ? { Authorization: `Bearer ${token}` } : {};

  useEffect(() => {
    loadDashboard();
  }, []);

  useEffect(() => {
    if (!sessionId) return;

    // Send heartbeat every 30 seconds
    heartbeatRef.current = setInterval(async () => {
      await fetch('/api/usage/session', {
        method: 'PUT',
        headers: { ...headers, 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ sessionId }),
      });
    }, 30000);

    // Update live timer every second
    tickRef.current = setInterval(() => {
      if (activeSession) {
        const start = new Date(activeSession.start_time).getTime();
        const elapsed = (Date.now() - start) / 1000 / 60; // minutes
        setLiveMinutes(Math.round(elapsed * 100) / 100);
        setLiveCost(Math.round(elapsed * (activeSession.price_per_minute || 0.25) * 100) / 100);
      }
    }, 1000);

    return () => {
      if (heartbeatRef.current) clearInterval(heartbeatRef.current);
      if (tickRef.current) clearInterval(tickRef.current);
    };
  }, [sessionId, activeSession]);

  const loadDashboard = async () => {
    try {
      const [userRes, invoiceRes, usageRes] = await Promise.all([
        fetch('/api/user', { headers, credentials: 'include' }),
        fetch('/api/invoices?limit=5', { headers, credentials: 'include' }),
        fetch('/api/usage/session?days=30', { headers, credentials: 'include' }),
      ]);

      if (userRes.status === 401) {
        router.push('/auth/login');
        return;
      }

      if (userRes.status === 403) {
        const data = await userRes.json();
        if (data.code === 'SUSPENDED') {
          router.push('/dashboard/suspended');
          return;
        }
      }

      const userData = await userRes.json();
      const invoiceData = await invoiceRes.json();
      const usageData = await usageRes.json();

      setUser(userData.user);
      setActiveSession(userData.activeSession);
      setInvoices(invoiceData.invoices || []);
      setUsage(usageData.summary);

      if (userData.activeSession) {
        setSessionId(userData.activeSession.id);
      } else {
        // Start a new session
        startSession();
      }

    } catch (err) {
      toast.error('Failed to load dashboard');
    } finally {
      setLoading(false);
    }
  };

  const startSession = async () => {
    try {
      const res = await fetch('/api/usage/session', {
        method: 'POST',
        headers,
        credentials: 'include',
      });
      if (res.ok) {
        const data = await res.json();
        setSessionId(data.sessionId);
        // Refresh to get full session data
        const sess = await fetch('/api/user', { headers, credentials: 'include' });
        const d = await sess.json();
        setActiveSession(d.activeSession);
      }
    } catch {}
  };

  const handleLogout = async () => {
    // End session first
    if (sessionId) {
      await fetch('/api/usage/session', { method: 'DELETE', headers, credentials: 'include' });
    }
    await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' });
    localStorage.removeItem('hci_token');
    router.push('/auth/login');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'badge-success';
      case 'suspended': return 'badge-danger';
      case 'paid': return 'badge-success';
      case 'pending': return 'badge-warning';
      case 'failed': return 'badge-danger';
      default: return 'badge-gray';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-500 text-sm">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-gray-200 flex flex-col fixed h-full z-10">
        <div className="p-6 border-b border-gray-100">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <Heart className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className="font-bold text-gray-900 text-sm">HomeCare</div>
              <div className="text-xs text-gray-500">International</div>
            </div>
          </Link>
        </div>

        <nav className="flex-1 p-4 space-y-1">
          <Link href="/dashboard" className="sidebar-link active">
            <BarChart3 className="w-4 h-4" /> Dashboard
          </Link>
          <Link href="/dashboard/billing" className="sidebar-link">
            <CreditCard className="w-4 h-4" /> Billing
          </Link>
          <Link href="/dashboard/invoices" className="sidebar-link">
            <FileText className="w-4 h-4" /> Invoices
          </Link>
          <Link href="/dashboard/usage" className="sidebar-link">
            <Activity className="w-4 h-4" /> Usage
          </Link>
          <Link href="/global-health" className="sidebar-link">
            <Globe className="w-4 h-4" /> Health Globe
          </Link>
          <Link href="/dashboard/settings" className="sidebar-link">
            <Settings className="w-4 h-4" /> Settings
          </Link>
        </nav>

        <div className="p-4 border-t border-gray-100">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
              <User className="w-4 h-4 text-blue-600" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium text-gray-900 truncate">{user?.email}</div>
              <div className="text-xs text-gray-500 capitalize">{user?.role}</div>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 w-full text-sm text-gray-500 hover:text-red-600 transition-colors px-2 py-1.5 rounded-lg hover:bg-red-50"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="ml-64 flex-1 p-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
            <p className="text-gray-500 text-sm mt-1">{new Date().toLocaleDateString('en-CH', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
          </div>
          {user?.account_status === 'suspended' && (
            <div className="flex items-center gap-2 bg-red-50 text-red-700 px-4 py-2 rounded-xl border border-red-200 text-sm">
              <AlertTriangle className="w-4 h-4" />
              Account Suspended — <Link href="/dashboard/billing" className="font-medium underline">Update Payment</Link>
            </div>
          )}
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-4 gap-6 mb-8">
          <div className="metric-card">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-medium text-gray-500">Credit Balance</span>
              <CreditCard className="w-4 h-4 text-gray-400" />
            </div>
            <div className="text-2xl font-black text-gray-900">
              {user?.currency} {(user?.credit_balance || 0).toFixed(2)}
            </div>
            <div className="text-xs text-gray-400 mt-1">Available credits</div>
          </div>

          <div className="metric-card">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-medium text-gray-500">Live Session</span>
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            </div>
            <div className="text-2xl font-black text-gray-900">{liveMinutes.toFixed(1)} min</div>
            <div className="text-xs text-gray-400 mt-1">
              {user?.currency} {liveCost.toFixed(4)} this session
            </div>
          </div>

          <div className="metric-card">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-medium text-gray-500">Monthly Usage</span>
              <TrendingUp className="w-4 h-4 text-gray-400" />
            </div>
            <div className="text-2xl font-black text-gray-900">{(usage?.totalMinutes || 0).toFixed(0)} min</div>
            <div className="text-xs text-gray-400 mt-1">{user?.currency} {(usage?.totalCost || 0).toFixed(2)} spent</div>
          </div>

          <div className="metric-card">
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm font-medium text-gray-500">Account Status</span>
              <Shield className="w-4 h-4 text-gray-400" />
            </div>
            <div className="flex items-center gap-2">
              <span className={`badge ${getStatusColor(user?.account_status || '')}`}>
                {user?.account_status}
              </span>
            </div>
            <div className="text-xs text-gray-400 mt-1 capitalize">{user?.role} plan</div>
          </div>
        </div>

        {/* Live Billing Alert */}
        {sessionId && (
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6 flex items-center gap-4">
            <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse flex-shrink-0" />
            <div className="flex-1">
              <p className="text-sm font-medium text-blue-800">
                Active billing session — {user?.currency}{' '}
                {user?.role === 'private' ? '0.25' : user?.role === 'professional' ? '0.50' : '0.75'}/minute
              </p>
              <p className="text-xs text-blue-600 mt-0.5">
                Automatic invoice generated every 15 minutes. Session started: {activeSession ? new Date(activeSession.start_time).toLocaleTimeString() : 'now'}
              </p>
            </div>
            <div className="text-right">
              <div className="text-lg font-bold text-blue-700">{user?.currency} {liveCost.toFixed(4)}</div>
              <div className="text-xs text-blue-500">current cost</div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-2 gap-6">
          {/* Recent Invoices */}
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-bold text-gray-900">Recent Invoices</h2>
              <Link href="/dashboard/invoices" className="text-sm text-blue-600 hover:text-blue-700 flex items-center gap-1">
                View all <ChevronRight className="w-3 h-3" />
              </Link>
            </div>
            {invoices.length === 0 ? (
              <div className="text-center py-8 text-gray-400 text-sm">No invoices yet</div>
            ) : (
              <table className="w-full data-table">
                <thead>
                  <tr>
                    <th>Invoice</th>
                    <th>Amount</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {invoices.map((inv: any) => (
                    <tr key={inv.id}>
                      <td>
                        <div className="font-medium text-gray-800">{inv.invoice_number}</div>
                        <div className="text-xs text-gray-400">{new Date(inv.created_at).toLocaleDateString()}</div>
                      </td>
                      <td className="font-semibold">{inv.currency} {(inv.total_amount || 0).toFixed(2)}</td>
                      <td><span className={`badge ${getStatusColor(inv.status)}`}>{inv.status}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h2 className="font-bold text-gray-900 mb-4">Quick Actions</h2>
            <div className="space-y-2">
              {[
                { href: '/dashboard/billing', icon: CreditCard, label: 'Manage Payment Methods', desc: 'Add or update card, PayPal, or crypto' },
                { href: '/dashboard/invoices', icon: FileText, label: 'View All Invoices', desc: 'Download PDF invoices' },
                { href: '/global-health', icon: Globe, label: 'Explore Health Globe', desc: 'View 190+ country health data' },
                { href: '/dashboard/usage', icon: Activity, label: 'Usage Analytics', desc: 'Detailed usage reports and graphs' },
              ].map(action => (
                <Link
                  key={action.href}
                  href={action.href}
                  className="flex items-center gap-3 p-3 rounded-xl hover:bg-gray-50 transition-colors group"
                >
                  <div className="w-9 h-9 bg-blue-50 rounded-lg flex items-center justify-center group-hover:bg-blue-100 transition-colors">
                    <action.icon className="w-4 h-4 text-blue-600" />
                  </div>
                  <div className="flex-1">
                    <div className="text-sm font-medium text-gray-800">{action.label}</div>
                    <div className="text-xs text-gray-400">{action.desc}</div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-300 group-hover:text-gray-500" />
                </Link>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
