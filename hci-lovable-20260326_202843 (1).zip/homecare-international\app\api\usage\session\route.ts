// app/api/usage/session/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/backend/auth/auth';
import { startUsageSession, endUsageSession, heartbeatSession } from '@/backend/billing/billing_engine';
import { supabaseAdmin } from '@/backend/lib/db';

// Start session
export async function POST(req: NextRequest) {
  try {
    const user = await requireAuth(req);
    const sessionId = await startUsageSession(user.id);
    return NextResponse.json({ sessionId, started: true });
  } catch (err: any) {
    if (err.message === 'UNAUTHORIZED') return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (err.message === 'ACCOUNT_SUSPENDED') return NextResponse.json({ error: 'Account suspended', code: 'SUSPENDED' }, { status: 403 });
    return NextResponse.json({ error: 'Failed to start session' }, { status: 500 });
  }
}

// Heartbeat
export async function PUT(req: NextRequest) {
  try {
    const user = await requireAuth(req);
    const { sessionId } = await req.json();
    if (sessionId) await heartbeatSession(sessionId);
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ ok: false }, { status: 200 }); // Don't break the app on heartbeat failure
  }
}

// End session
export async function DELETE(req: NextRequest) {
  try {
    const user = await requireAuth(req);
    await endUsageSession(user.id);
    return NextResponse.json({ ended: true });
  } catch (err: any) {
    return NextResponse.json({ error: 'Failed to end session' }, { status: 500 });
  }
}

// Get usage stats
export async function GET(req: NextRequest) {
  try {
    const user = await requireAuth(req);
    const { searchParams } = new URL(req.url);
    const days = parseInt(searchParams.get('days') || '30');
    const from = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();

    const { data: sessions } = await supabaseAdmin
      .from('usage_sessions')
      .select('*')
      .eq('user_id', user.id)
      .gte('start_time', from)
      .order('start_time', { ascending: false });

    const totalMinutes = (sessions || []).reduce((sum, s) => sum + (s.minutes_used || 0), 0);
    const totalCost = (sessions || []).reduce((sum, s) => sum + (s.amount_charged || 0), 0);

    return NextResponse.json({
      sessions: sessions || [],
      summary: {
        totalMinutes: Math.round(totalMinutes * 100) / 100,
        totalCost: Math.round(totalCost * 100) / 100,
        sessionCount: sessions?.length || 0,
        days,
      },
    });
  } catch (err: any) {
    if (err.message === 'UNAUTHORIZED') return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    return NextResponse.json({ error: 'Failed to get usage' }, { status: 500 });
  }
}
