// app/api/health/map-data/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/backend/lib/db';

export const revalidate = 3600; // Cache 1 hour

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const metricKey = searchParams.get('metric_key') || 'life_expectancy';

  try {
    // Get latest value per country for the metric
    const { data: values } = await supabaseAdmin
      .from('health_metric_values')
      .select('geo_code, value, trend_7d, quality_flag, timestamp')
      .eq('metric_key', metricKey)
      .eq('geo_level', 'country')
      .order('timestamp', { ascending: false });

    // Deduplicate - keep latest per country
    const latestByCountry: Record<string, any> = {};
    for (const v of values || []) {
      if (!latestByCountry[v.geo_code]) {
        latestByCountry[v.geo_code] = v;
      }
    }

    // Get countries
    const { data: countries } = await supabaseAdmin
      .from('countries')
      .select('country_code, country_name, continent, population, flag_emoji, lat, lng');

    // Get metric definition
    const { data: metric } = await supabaseAdmin
      .from('health_metrics')
      .select('*')
      .eq('metric_key', metricKey)
      .single();

    // Build response
    const result = (countries || []).map(country => {
      const metricValue = latestByCountry[country.country_code];
      return {
        ...country,
        value: metricValue?.value ?? null,
        trend_7d: metricValue?.trend_7d ?? null,
        quality_flag: metricValue?.quality_flag ?? null,
        last_updated: metricValue?.timestamp ?? null,
      };
    });

    // Calculate min/max for normalization
    const validValues = result.filter(r => r.value !== null).map(r => r.value);
    const minVal = validValues.length ? Math.min(...validValues) : 0;
    const maxVal = validValues.length ? Math.max(...validValues) : 100;

    return NextResponse.json({
      metric,
      countries: result,
      stats: { min: minVal, max: maxVal, count: validValues.length },
    }, {
      headers: {
        'Cache-Control': 'public, s-maxage=3600, stale-while-revalidate=7200',
        'ETag': `"${metricKey}-${Date.now()}"`,
      },
    });

  } catch (err: any) {
    return NextResponse.json({ error: 'Failed to fetch health data' }, { status: 500 });
  }
}
