// app/api/auth/register/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/backend/lib/db';
import { hashPassword, validatePassword, generateToken, createSession } from '@/backend/auth/auth';
import { ensureStripeCustomer } from '@/backend/payments/stripe_engine';
import { logger } from '@/backend/lib/logger';
import { z } from 'zod';

const RegisterSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  role: z.enum(['private', 'professional', 'enterprise']).default('private'),
  currency: z.enum(['EUR', 'CHF', 'USD', 'GBP']).default('EUR'),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const validation = RegisterSchema.safeParse(body);

    if (!validation.success) {
      return NextResponse.json(
        { error: 'Validation failed', details: validation.error.flatten().fieldErrors },
        { status: 422 }
      );
    }

    const { email, password, role, currency } = validation.data;

    // Password strength check
    const { valid, errors } = validatePassword(password);
    if (!valid) {
      return NextResponse.json({ error: 'Password too weak', details: errors }, { status: 422 });
    }

    // Check existing user
    const { data: existingUser } = await supabaseAdmin
      .from('users')
      .select('id')
      .eq('email', email.toLowerCase())
      .single();

    if (existingUser) {
      return NextResponse.json({ error: 'Email already registered' }, { status: 409 });
    }

    const passwordHash = await hashPassword(password);

    // Create user
    const { data: user, error } = await supabaseAdmin
      .from('users')
      .insert({
        email: email.toLowerCase(),
        password_hash: passwordHash,
        role,
        currency,
        account_status: 'active',
        credit_balance: 0,
        subscription_type: 'pay_per_use',
      })
      .select('id, email, role, account_status')
      .single();

    if (error || !user) {
      logger.error('user_registration_failed', { email, error: error?.message });
      return NextResponse.json({ error: 'Registration failed' }, { status: 500 });
    }

    // Create Stripe customer in background
    ensureStripeCustomer(user.id).catch(err =>
      logger.error('stripe_customer_creation_failed', { userId: user.id, error: err.message })
    );

    // Generate token and session
    const sessionId = 'temp-' + Date.now();
    const token = generateToken({
      userId: user.id,
      email: user.email,
      role: user.role,
      sessionId,
    });

    await createSession(user.id, token, req).catch(() => {});

    logger.info('user_registered', { userId: user.id, email: user.email, role });

    const response = NextResponse.json({
      success: true,
      user: { id: user.id, email: user.email, role: user.role },
      token,
    }, { status: 201 });

    // Set secure HTTP-only cookie
    response.cookies.set('hci_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60,
      path: '/',
    });

    return response;

  } catch (err: any) {
    logger.error('register_error', { error: err.message });
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
