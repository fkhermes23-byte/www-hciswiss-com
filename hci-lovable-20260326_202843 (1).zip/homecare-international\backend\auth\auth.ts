// backend/auth/auth.ts - Authentication utilities
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { supabaseAdmin } from '../lib/db';
import { NextRequest } from 'next/server';
import crypto from 'crypto';

const JWT_SECRET = process.env.JWT_SECRET!;
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d';

export interface JWTPayload {
  userId: string;
  email: string;
  role: string;
  sessionId: string;
  iat?: number;
  exp?: number;
}

export interface AuthUser {
  id: string;
  email: string;
  role: string;
  account_status: string;
  credit_balance: number;
}

// Hash password with bcrypt (cost factor 12)
export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12);
}

// Verify password
export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

// Generate JWT token
export function generateToken(payload: Omit<JWTPayload, 'iat' | 'exp'>): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN } as jwt.SignOptions);
}

// Verify JWT token
export function verifyToken(token: string): JWTPayload {
  return jwt.verify(token, JWT_SECRET) as JWTPayload;
}

// Create session in DB
export async function createSession(
  userId: string,
  token: string,
  req: NextRequest
): Promise<string> {
  const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + 7);

  const { data, error } = await supabaseAdmin
    .from('sessions')
    .insert({
      user_id: userId,
      token_hash: tokenHash,
      ip_address: req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip'),
      user_agent: req.headers.get('user-agent'),
      expires_at: expiresAt.toISOString(),
    })
    .select('id')
    .single();

  if (error) throw new Error('Failed to create session');
  return data.id;
}

// Validate session
export async function validateSession(token: string): Promise<JWTPayload | null> {
  try {
    const payload = verifyToken(token);
    const tokenHash = crypto.createHash('sha256').update(token).digest('hex');

    const { data: session } = await supabaseAdmin
      .from('sessions')
      .select('id, revoked, expires_at')
      .eq('token_hash', tokenHash)
      .single();

    if (!session || session.revoked || new Date(session.expires_at) < new Date()) {
      return null;
    }

    return payload;
  } catch {
    return null;
  }
}

// Revoke session (logout)
export async function revokeSession(token: string): Promise<void> {
  const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
  await supabaseAdmin
    .from('sessions')
    .update({ revoked: true, revoked_at: new Date().toISOString() })
    .eq('token_hash', tokenHash);
}

// Extract auth user from request
export async function getAuthUser(req: NextRequest): Promise<AuthUser | null> {
  const authHeader = req.headers.get('authorization');
  const cookieToken = req.cookies.get('hci_token')?.value;
  const token = authHeader?.replace('Bearer ', '') || cookieToken;

  if (!token) return null;

  const payload = await validateSession(token);
  if (!payload) return null;

  const { data: user } = await supabaseAdmin
    .from('users')
    .select('id, email, role, account_status, credit_balance')
    .eq('id', payload.userId)
    .single();

  if (!user || user.account_status === 'deleted') return null;

  return user;
}

// Require auth middleware
export async function requireAuth(req: NextRequest): Promise<AuthUser> {
  const user = await getAuthUser(req);
  if (!user) throw new Error('UNAUTHORIZED');
  if (user.account_status === 'suspended') throw new Error('ACCOUNT_SUSPENDED');
  if (user.account_status === 'blocked') throw new Error('ACCOUNT_BLOCKED');
  return user;
}

// Require admin middleware
export async function requireAdmin(req: NextRequest): Promise<AuthUser> {
  const user = await requireAuth(req);
  if (user.role !== 'admin') throw new Error('FORBIDDEN');
  return user;
}

// Validate password strength
export function validatePassword(password: string): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  if (password.length < 8) errors.push('Minimum 8 characters');
  if (!/[A-Z]/.test(password)) errors.push('At least one uppercase letter');
  if (!/[a-z]/.test(password)) errors.push('At least one lowercase letter');
  if (!/[0-9]/.test(password)) errors.push('At least one number');
  return { valid: errors.length === 0, errors };
}

// Generate verification token
export function generateVerificationToken(): string {
  return crypto.randomBytes(32).toString('hex');
}
