// app/page.tsx - Landing Page
'use client';
import Link from 'next/link';
import { motion } from 'framer-motion';
import {
  Globe, Shield, Zap, BarChart3, Clock, CheckCircle,
  ArrowRight, Heart, Activity, Users, CreditCard
} from 'lucide-react';

const FEATURES = [
  { icon: Globe, title: 'Global Health Intelligence', desc: 'Interactive 3D satellite globe with real-time health indicators for every nation on Earth.' },
  { icon: Zap, title: 'Per-Minute Billing', desc: 'Pay only for what you use. Automatic billing every 15 minutes with instant invoice generation.' },
  { icon: Shield, title: 'Enterprise Security', desc: 'bcrypt encryption, JWT authentication, full HTTPS, SQL injection and XSS protection.' },
  { icon: BarChart3, title: 'Real-time Analytics', desc: 'Live usage dashboards, revenue tracking, and health data visualization at your fingertips.' },
  { icon: Clock, title: 'Automatic Payments', desc: 'Stripe, PayPal and crypto payments processed automatically. Zero manual intervention.' },
  { icon: Heart, title: 'Care Intelligence', desc: 'WHO-sourced health metrics: diabetes, hypertension, life expectancy, vaccination rates and more.' },
];

const PRICING = [
  {
    name: 'Private',
    price: '0.25',
    period: '/minute',
    color: 'from-blue-500 to-blue-600',
    features: ['Personal health dashboard', 'Global health globe access', 'Basic analytics', 'Stripe / PayPal / Crypto', 'Automatic invoicing', 'Email support'],
  },
  {
    name: 'Professional',
    price: '0.50',
    period: '/minute',
    color: 'from-violet-500 to-purple-600',
    popular: true,
    features: ['All Private features', 'Advanced analytics', 'API access', 'Priority support', 'Custom reports', 'Team collaboration'],
  },
  {
    name: 'Enterprise',
    price: '0.75',
    period: '/minute',
    color: 'from-emerald-500 to-green-600',
    features: ['All Professional features', 'White-label options', 'Dedicated account manager', 'Custom integrations', 'SLA guarantee', '24/7 phone support'],
  },
];

const STATS = [
  { value: '190+', label: 'Countries Monitored' },
  { value: '15+', label: 'Health Indicators' },
  { value: '99.9%', label: 'Uptime SLA' },
  { value: '< 1s', label: 'Billing Precision' },
];

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Nav */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-md border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <Heart className="w-4 h-4 text-white" />
              </div>
              <span className="font-bold text-gray-900">HomeCare International</span>
            </div>
            <div className="hidden md:flex items-center gap-8 text-sm text-gray-600">
              <Link href="#features" className="hover:text-gray-900">Features</Link>
              <Link href="#pricing" className="hover:text-gray-900">Pricing</Link>
              <Link href="/global-health" className="hover:text-gray-900">Health Globe</Link>
              <Link href="#sources" className="hover:text-gray-900">Data Sources</Link>
            </div>
            <div className="flex items-center gap-3">
              <Link href="/auth/login" className="text-sm text-gray-600 hover:text-gray-900 px-4 py-2">
                Sign In
              </Link>
              <Link href="/auth/register" className="text-sm bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                Get Started
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="pt-32 pb-20 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <span className="inline-flex items-center gap-2 bg-blue-50 text-blue-700 text-sm font-medium px-4 py-1.5 rounded-full mb-6">
              <Activity className="w-4 h-4" />
              Global Health Intelligence Platform
            </span>
            <h1 className="text-5xl md:text-7xl font-black text-gray-900 leading-none mb-6">
              Healthcare Data.
              <br />
              <span className="text-blue-600">Global Scale.</span>
            </h1>
            <p className="text-xl text-gray-500 max-w-2xl mx-auto mb-10">
              The world's most comprehensive digital health platform. Real-time billing, automatic invoicing, and a live 3D satellite globe showing health indicators for every country.
            </p>
            <div className="flex items-center justify-center gap-4">
              <Link
                href="/auth/register"
                className="flex items-center gap-2 bg-blue-600 text-white px-8 py-4 rounded-xl font-semibold hover:bg-blue-700 transition-all hover:shadow-lg hover:shadow-blue-200"
              >
                Start for Free
                <ArrowRight className="w-5 h-5" />
              </Link>
              <Link
                href="/global-health"
                className="flex items-center gap-2 border border-gray-200 text-gray-700 px-8 py-4 rounded-xl font-semibold hover:border-gray-300 hover:bg-gray-50 transition-all"
              >
                <Globe className="w-5 h-5" />
                Explore Health Globe
              </Link>
            </div>
          </motion.div>

          {/* Stats */}
          <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-8">
            {STATS.map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 + i * 0.1 }}
                className="text-center"
              >
                <div className="text-4xl font-black text-gray-900">{stat.value}</div>
                <div className="text-sm text-gray-500 mt-1">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-20 bg-gray-50 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-black text-gray-900">Everything you need</h2>
            <p className="text-gray-500 mt-4 max-w-xl mx-auto">Built for healthcare professionals, enterprises, and individuals who demand precision, security, and global reach.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {FEATURES.map((f, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="bg-white p-6 rounded-2xl border border-gray-100 hover:border-blue-200 hover:shadow-lg transition-all"
              >
                <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center mb-4">
                  <f.icon className="w-5 h-5 text-blue-600" />
                </div>
                <h3 className="font-bold text-gray-900 mb-2">{f.title}</h3>
                <p className="text-sm text-gray-500 leading-relaxed">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-black text-gray-900">Simple, usage-based pricing</h2>
            <p className="text-gray-500 mt-4">Pay per minute of use. Automatic billing every 15 minutes. Cancel anytime.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {PRICING.map((plan, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className={`relative rounded-2xl border-2 ${plan.popular ? 'border-violet-400 shadow-xl shadow-violet-100' : 'border-gray-200'} overflow-hidden`}
              >
                {plan.popular && (
                  <div className="bg-violet-600 text-white text-xs font-bold text-center py-1.5 tracking-wider">
                    MOST POPULAR
                  </div>
                )}
                <div className="p-8">
                  <div className={`inline-flex items-center justify-center w-12 h-12 rounded-xl bg-gradient-to-br ${plan.color} mb-6`}>
                    <Users className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900">{plan.name}</h3>
                  <div className="mt-4 mb-6">
                    <span className="text-5xl font-black text-gray-900">€{plan.price}</span>
                    <span className="text-gray-500 text-sm">{plan.period}</span>
                  </div>
                  <ul className="space-y-3 mb-8">
                    {plan.features.map((f, j) => (
                      <li key={j} className="flex items-center gap-2 text-sm text-gray-600">
                        <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                        {f}
                      </li>
                    ))}
                  </ul>
                  <Link
                    href="/auth/register"
                    className={`block text-center py-3 rounded-xl font-semibold text-sm transition-all ${
                      plan.popular
                        ? 'bg-violet-600 text-white hover:bg-violet-700'
                        : 'border-2 border-gray-200 text-gray-700 hover:border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    Get Started
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
          <div className="text-center mt-8 text-sm text-gray-500">
            <CreditCard className="w-4 h-4 inline mr-2" />
            Stripe · PayPal · Bitcoin · Ethereum · USDT · USDC · Solana
          </div>
        </div>
      </section>

      {/* Health Globe CTA */}
      <section className="py-20 bg-gradient-to-br from-blue-900 to-blue-700 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <Globe className="w-16 h-16 text-blue-300 mx-auto mb-6" />
          <h2 className="text-4xl font-black text-white mb-4">Explore the Global Health Intelligence Globe</h2>
          <p className="text-blue-200 mb-8 max-w-2xl mx-auto">
            An interactive 3D satellite globe showing real WHO and World Bank health indicators for 190+ countries. Educational and informational — free for everyone.
          </p>
          <div className="inline-flex items-center gap-2 bg-yellow-100 text-yellow-800 text-sm px-4 py-2 rounded-full mb-8">
            ⚠️ Aggregated data for educational purposes only. Not medical advice.
          </div>
          <div className="flex items-center justify-center gap-4">
            <Link
              href="/global-health"
              className="flex items-center gap-2 bg-white text-blue-700 px-8 py-4 rounded-xl font-semibold hover:bg-blue-50 transition-all"
            >
              <Globe className="w-5 h-5" />
              Launch Health Globe
            </Link>
            <Link href="/auth/register" className="flex items-center gap-2 border border-white/30 text-white px-8 py-4 rounded-xl font-semibold hover:bg-white/10 transition-all">
              Create Account
            </Link>
          </div>
        </div>
      </section>

      {/* Data Sources */}
      <section id="sources" className="py-16 bg-gray-50 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Trusted Data Sources</h2>
          <p className="text-gray-500 text-sm mb-8">All health data is sourced from official public institutions and updated automatically.</p>
          <div className="flex flex-wrap justify-center gap-4 text-sm text-gray-600">
            {['WHO Global Health Observatory', 'World Bank Open Data', 'IDF Diabetes Atlas', 'UNICEF', 'WHO/UNICEF JRF'].map(s => (
              <span key={s} className="bg-white border border-gray-200 px-4 py-2 rounded-full">{s}</span>
            ))}
          </div>
          <p className="text-xs text-gray-400 mt-6">
            Data is aggregated at country level. No personal data is collected or displayed. For medical decisions, consult qualified healthcare professionals.
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-12 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-blue-600 rounded flex items-center justify-center">
                <Heart className="w-3 h-3 text-white" />
              </div>
              <span className="text-white font-semibold">HomeCare International</span>
            </div>
            <div className="flex gap-6 text-sm">
              <Link href="/global-health" className="hover:text-white">Health Globe</Link>
              <Link href="/auth/login" className="hover:text-white">Login</Link>
              <Link href="/auth/register" className="hover:text-white">Register</Link>
              <Link href="/privacy" className="hover:text-white">Privacy</Link>
            </div>
            <div className="text-xs">
              © {new Date().getFullYear()} HomeCareInternational.ch | HomeCareInternational.org
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
