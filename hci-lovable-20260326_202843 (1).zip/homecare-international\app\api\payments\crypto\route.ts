// app/api/payments/crypto/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/backend/auth/auth';
import { supabaseAdmin } from '@/backend/lib/db';
import { createCryptoCharge } from '@/backend/payments/crypto_engine';

const SUBSCRIPTION_PRICES: Record<string, Record<string, number>> = {
  daily:   { private: 3.60,  professional: 7.20,  enterprise: 10.80 },
  weekly:  { private: 21.00, professional: 42.00, enterprise: 63.00 },
  monthly: { private: 72.00, professional: 144.00, enterprise: 216.00 },
  annual:  { private: 720.00, professional: 1440.00, enterprise: 2160.00 },
};

export async function POST(req: NextRequest) {
  try {
    const user = await requireAuth(req);
    const { plan, invoiceId } = await req.json();

    const { data: userData } = await supabaseAdmin
      .from('users')
      .select('role, currency')
      .eq('id', user.id)
      .single();

    let amount: number;
    let targetInvoiceId = invoiceId;

    if (plan && SUBSCRIPTION_PRICES[plan]) {
      amount = SUBSCRIPTION_PRICES[plan][userData?.role || 'private'];
    } else if (invoiceId) {
      const { data: inv } = await supabaseAdmin
        .from('invoices')
        .select('total_amount')
        .eq('id', invoiceId)
        .eq('user_id', user.id)
        .single();
      if (!inv) return NextResponse.json({ error: 'Invoice not found' }, { status: 404 });
      amount = inv.total_amount;
    } else {
      return NextResponse.json({ error: 'Must provide plan or invoiceId' }, { status: 400 });
    }

    // Create invoice if not provided
    if (!targetInvoiceId) {
      const taxAmount = Math.round(amount * 0.077 * 100) / 100;
      const totalAmount = Math.round((amount + taxAmount) * 100) / 100;
      const { data: inv } = await supabaseAdmin.from('invoices').insert({
        user_id: user.id,
        amount,
        tax_amount: taxAmount,
        total_amount: totalAmount,
        currency: userData?.currency || 'EUR',
        status: 'pending',
        payment_provider: 'crypto',
        line_items: [{ description: plan ? `${plan} subscription` : 'Usage invoice', amount }],
      }).select().single();
      targetInvoiceId = inv?.id;
    }

    const charge = await createCryptoCharge(user.id, amount, targetInvoiceId);
    return NextResponse.json({ success: true, ...charge });

  } catch (err: any) {
    if (err.message === 'UNAUTHORIZED') return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    return NextResponse.json({ error: 'Failed to create crypto charge' }, { status: 500 });
  }
}
