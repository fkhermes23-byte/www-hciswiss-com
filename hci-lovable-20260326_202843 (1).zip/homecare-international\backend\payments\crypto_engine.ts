// backend/payments/crypto_engine.ts
import { supabaseAdmin } from '../lib/db';
import { logger } from '../lib/logger';
import { reactivateUser, blockUser } from '../billing/billing_engine';
import crypto from 'crypto';

const COINBASE_API_URL = 'https://api.commerce.coinbase.com';
const COINBASE_API_KEY = process.env.COINBASE_COMMERCE_API_KEY!;

// Create crypto charge invoice
export async function createCryptoCharge(
  userId: string,
  amountEUR: number,
  invoiceId: string
): Promise<{ chargeId: string; hostedUrl: string; expiresAt: string }> {
  const response = await fetch(`${COINBASE_API_URL}/charges`, {
    method: 'POST',
    headers: {
      'X-CC-Api-Key': COINBASE_API_KEY,
      'X-CC-Version': '2018-03-22',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      name: 'Home Care International Service',
      description: `Invoice ${invoiceId} - HomeCareInternational.ch`,
      pricing_type: 'fixed_price',
      local_price: {
        amount: amountEUR.toFixed(2),
        currency: 'EUR',
      },
      metadata: {
        userId,
        invoiceId,
        platform: 'homecareinternational',
      },
      redirect_url: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard/billing?crypto=success`,
      cancel_url: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard/billing?crypto=cancel`,
    }),
  });

  const data = await response.json();
  if (!response.ok) throw new Error(data.error?.message || 'Crypto charge creation failed');

  const charge = data.data;

  // Update invoice with crypto charge ID
  await supabaseAdmin
    .from('invoices')
    .update({ crypto_charge_id: charge.id })
    .eq('id', invoiceId);

  return {
    chargeId: charge.id,
    hostedUrl: charge.hosted_url,
    expiresAt: charge.expires_at,
  };
}

// Get charge status
export async function getCryptoChargeStatus(chargeId: string): Promise<string> {
  const response = await fetch(`${COINBASE_API_URL}/charges/${chargeId}`, {
    headers: {
      'X-CC-Api-Key': COINBASE_API_KEY,
      'X-CC-Version': '2018-03-22',
    },
  });

  const data = await response.json();
  const timeline = data.data?.timeline || [];
  const latest = timeline[timeline.length - 1];
  return latest?.status || 'UNKNOWN';
}

// Verify Coinbase Commerce webhook signature
export function verifyCryptoWebhook(payload: string, signature: string): boolean {
  const secret = process.env.COINBASE_COMMERCE_WEBHOOK_SECRET!;
  const expectedSig = crypto
    .createHmac('sha256', secret)
    .update(payload)
    .digest('hex');
  return crypto.timingSafeEqual(
    Buffer.from(signature),
    Buffer.from(expectedSig)
  );
}

// Handle Coinbase Commerce webhook
export async function handleCryptoWebhook(event: any): Promise<void> {
  const eventId = event.id;
  const eventType = event.type;

  // Store event
  const { error } = await supabaseAdmin.from('webhook_events').insert({
    provider: 'crypto',
    event_id: eventId,
    event_type: eventType,
    payload: event,
  });

  if (error?.code === '23505') return; // Duplicate event

  const charge = event.data;
  const { userId, invoiceId } = charge.metadata || {};

  switch (eventType) {
    case 'charge:confirmed':
    case 'charge:resolved': {
      if (invoiceId) {
        // Find confirmed payment in payments array
        const confirmedPayment = charge.payments?.find(
          (p: any) => p.status === 'CONFIRMED' || p.status === 'RESOLVED'
        );

        await supabaseAdmin
          .from('invoices')
          .update({
            status: 'paid',
            paid_at: new Date().toISOString(),
            crypto_charge_id: charge.id,
          })
          .eq('id', invoiceId);

        await supabaseAdmin.from('payments').insert({
          user_id: userId,
          invoice_id: invoiceId,
          provider: 'crypto',
          status: 'succeeded',
          amount: parseFloat(charge.pricing?.local?.amount || '0'),
          currency: 'EUR',
          crypto_tx_hash: confirmedPayment?.transaction_id?.ethereum || confirmedPayment?.transaction_id?.bitcoin,
          transaction_id: charge.id,
        });
      }

      if (userId) {
        const { data: user } = await supabaseAdmin
          .from('users')
          .select('account_status')
          .eq('id', userId)
          .single();
        if (user?.account_status === 'suspended') await reactivateUser(userId);
      }

      logger.info('crypto_payment_confirmed', { chargeId: charge.id, userId, invoiceId });
      break;
    }

    case 'charge:failed':
    case 'charge:expired': {
      if (invoiceId) {
        await supabaseAdmin
          .from('invoices')
          .update({ status: 'failed' })
          .eq('id', invoiceId);
      }

      if (userId) {
        await blockUser(userId, `Crypto payment ${eventType}: charge ${charge.id}`);
      }

      logger.warn('crypto_payment_failed', { chargeId: charge.id, userId, eventType });
      break;
    }

    case 'charge:pending': {
      logger.info('crypto_payment_pending', { chargeId: charge.id, userId });
      break;
    }
  }

  await supabaseAdmin
    .from('webhook_events')
    .update({ processed: true, processed_at: new Date().toISOString() })
    .eq('event_id', eventId)
    .eq('provider', 'crypto');
}

// List supported cryptocurrencies
export const SUPPORTED_CRYPTOS = [
  { code: 'BTC', name: 'Bitcoin', network: 'bitcoin' },
  { code: 'ETH', name: 'Ethereum', network: 'ethereum' },
  { code: 'USDT', name: 'Tether USD', network: 'ethereum' },
  { code: 'USDC', name: 'USD Coin', network: 'ethereum' },
  { code: 'SOL', name: 'Solana', network: 'solana' },
] as const;
