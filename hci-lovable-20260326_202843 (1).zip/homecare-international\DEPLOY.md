# HOME CARE INTERNATIONAL — GUIDA DEPLOY COMPLETA

## Stack
- **Frontend + API**: Next.js 14 → Vercel
- **Database**: Supabase (PostgreSQL)
- **Workers**: Docker (server VPS) o Railway
- **Pagamenti**: Stripe + PayPal + Coinbase Commerce

---

## STEP 1 — SUPABASE (DATABASE)

1. Vai su https://supabase.com → crea progetto
2. Copia: Project URL, anon key, service role key
3. Vai su SQL Editor → esegui il contenuto di `database/schema.sql`
4. Vai su Storage → crea bucket chiamato `invoices` (Public)

---

## STEP 2 — STRIPE

1. Vai su https://dashboard.stripe.com
2. Developers → API Keys → copia:
   - `sk_live_...` → STRIPE_SECRET_KEY
   - `pk_live_...` → STRIPE_PUBLISHABLE_KEY
3. Developers → Webhooks → Add endpoint:
   - URL: `https://tuo-dominio.vercel.app/api/webhooks/stripe`
   - Events: `payment_intent.succeeded`, `payment_intent.payment_failed`, `invoice.payment_succeeded`, `invoice.payment_failed`
   - Copia `whsec_...` → STRIPE_WEBHOOK_SECRET

---

## STEP 3 — PAYPAL

1. Vai su https://developer.paypal.com
2. Apps & Credentials → crea app Live
3. Copia: Client ID e Client Secret
4. Webhooks → crea webhook per: `PAYMENT.CAPTURE.COMPLETED`, `PAYMENT.CAPTURE.DENIED`

---

## STEP 4 — COINBASE COMMERCE (CRYPTO)

1. Vai su https://commerce.coinbase.com
2. Settings → API Keys → crea chiave
3. Settings → Webhooks → aggiungi:
   - URL: `https://tuo-dominio.vercel.app/api/webhooks/crypto`
   - Copia Shared Secret

---

## STEP 5 — VERCEL DEPLOY (FRONTEND + API)

```bash
# Installa Vercel CLI
npm install -g vercel

# Nella cartella del progetto
vercel login
vercel

# Imposta variabili ambiente
vercel env add NEXT_PUBLIC_SUPABASE_URL
vercel env add NEXT_PUBLIC_SUPABASE_ANON_KEY
vercel env add SUPABASE_SERVICE_ROLE_KEY
vercel env add JWT_SECRET
vercel env add STRIPE_SECRET_KEY
vercel env add NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY
vercel env add STRIPE_WEBHOOK_SECRET
vercel env add PAYPAL_CLIENT_ID
vercel env add PAYPAL_CLIENT_SECRET
vercel env add PAYPAL_WEBHOOK_ID
vercel env add NEXT_PUBLIC_PAYPAL_CLIENT_ID
vercel env add COINBASE_COMMERCE_API_KEY
vercel env add COINBASE_COMMERCE_WEBHOOK_SECRET
vercel env add NEXT_PUBLIC_APP_URL

# Deploy produzione
vercel --prod
```

---

## STEP 6 — WORKERS (BILLING AUTOMATICO)

I workers NON girano su Vercel (serverless). Servono su un server sempre attivo.

### Opzione A: Railway (consigliato, facile)
1. Vai su https://railway.app
2. New Project → Deploy from GitHub
3. Aggiungi tutte le env var
4. Start command: `node workers/index.js`

### Opzione B: VPS (DigitalOcean, Hetzner, ecc.)
```bash
# Sul server
git clone il-tuo-repo
cd homecare-international
npm install --production

# Crea file .env con tutte le variabili
cp .env.example .env
nano .env  # incolla i valori reali

# Avvia con PM2 (process manager)
npm install -g pm2
pm2 start workers/index.js --name "hci-workers"
pm2 startup   # avvio automatico al reboot
pm2 save
```

### Opzione C: Docker
```bash
docker build -t hci-workers .
docker run -d \
  --name hci-workers \
  --restart always \
  --env-file .env \
  hci-workers
```

---

## STEP 7 — DOMINIO

In Vercel → Settings → Domains:
- Aggiungi `homecareinternational.ch`
- Aggiungi `homecareinternational.org`
- Configura DNS come indicato da Vercel

---

## ARCHITETTURA BILLING (COME FUNZIONA)

```
Utente accede
     ↓
credit_worker (ogni 60s)
→ calcola minuti usati
→ scala crediti
→ sospende se crediti = 0 e nessun metodo di pagamento

billing_worker (ogni 31 minuti)
→ calcola utilizzo periodo
→ genera fattura PDF
→ addebita Stripe automaticamente
→ se fallisce → sospende utente

billing_worker (ogni ora - subscription)
→ controlla abbonamenti scaduti
→ rinnova automaticamente
→ se fallisce → sospende utente
```

---

## WEBHOOKS STRIPE DA CONFIGURARE

| Evento | Cosa fa |
|--------|---------|
| `payment_intent.succeeded` | Riattiva utente, marca fattura pagata |
| `payment_intent.payment_failed` | Sospende utente |
| `invoice.payment_succeeded` | Riattiva utente |
| `invoice.payment_failed` | Sospende utente |

---

## PREZZI CONFIGURATI

| Ruolo | Prezzo/minuto | Abbonamento mensile |
|-------|--------------|---------------------|
| Private | €0.25/min | €72.00/mese |
| Professional | €0.50/min | €144.00/mese |
| Enterprise | €0.75/min | €216.00/mese |

**Fatturazione utilizzo: ogni 31 minuti di sessione attiva**

---

## SICUREZZA IMPLEMENTATA

- ✅ Password bcrypt (cost 12)
- ✅ JWT HS256 con scadenza 7gg
- ✅ Session revocation nel DB
- ✅ HTTP-only cookies
- ✅ CSRF protection via SameSite cookies
- ✅ SQL injection: solo query parametrizzate Supabase
- ✅ XSS: Content-Security-Policy headers
- ✅ Stripe webhook signature verification
- ✅ Coinbase webhook HMAC-SHA256 verification
- ✅ Rate limiting via Vercel Edge
- ✅ Row Level Security su Supabase
