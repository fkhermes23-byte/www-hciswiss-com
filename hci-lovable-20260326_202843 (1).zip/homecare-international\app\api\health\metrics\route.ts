// app/api/health/metrics/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/backend/lib/db';

export const revalidate = 86400;

export async function GET() {
  const { data: metrics } = await supabaseAdmin
    .from('health_metrics')
    .select('*')
    .order('category', { ascending: true });

  return NextResponse.json({ metrics }, {
    headers: { 'Cache-Control': 'public, s-maxage=86400' },
  });
}
