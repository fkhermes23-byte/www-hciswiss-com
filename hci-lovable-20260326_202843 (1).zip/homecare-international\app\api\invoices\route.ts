// app/api/invoices/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/backend/auth/auth';
import { supabaseAdmin } from '@/backend/lib/db';

export async function GET(req: NextRequest) {
  try {
    const authUser = await requireAuth(req);
    const { searchParams } = new URL(req.url);
    const limit = Math.min(parseInt(searchParams.get('limit') || '20'), 100);
    const page = parseInt(searchParams.get('page') || '1');
    const offset = (page - 1) * limit;

    const { data: invoices, count } = await supabaseAdmin
      .from('invoices')
      .select('*', { count: 'exact' })
      .eq('user_id', authUser.id)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    return NextResponse.json({ invoices, total: count, page, limit });

  } catch (err: any) {
    if (err.message === 'UNAUTHORIZED') return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
