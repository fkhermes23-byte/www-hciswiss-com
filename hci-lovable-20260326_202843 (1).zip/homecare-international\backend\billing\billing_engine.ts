// backend/billing/billing_engine.ts
import { supabaseAdmin } from '../lib/db';
import { logger } from '../lib/logger';

export const PRICING = {
  private: 0.25,
  professional: 0.50,
  enterprise: 0.75,
  admin: 0.00,
} as const;

export const BILLING_CYCLE_MINUTES = parseInt(process.env.BILLING_CYCLE_MINUTES || '15');
export const DEFAULT_TAX_RATE = parseFloat(process.env.DEFAULT_TAX_RATE || '0.077');

export function getPricePerMinute(role: string, multiplier: number = 1.0): number {
  const base = PRICING[role as keyof typeof PRICING] ?? PRICING.private;
  return Math.round(base * multiplier * 10000) / 10000;
}

export function calculatePriceMultiplier(monthlyMinutes: number): number {
  if (monthlyMinutes > 10000) return 1.30;
  if (monthlyMinutes > 5000) return 1.20;
  if (monthlyMinutes > 1000) return 1.10;
  return 1.00;
}

// Start usage session for user
export async function startUsageSession(userId: string): Promise<string> {
  const { data: user } = await supabaseAdmin
    .from('users')
    .select('role, price_multiplier, monthly_usage_minutes, currency')
    .eq('id', userId)
    .single();

  if (!user) throw new Error('User not found');

  const multiplier = calculatePriceMultiplier(user.monthly_usage_minutes || 0);
  const pricePerMinute = getPricePerMinute(user.role, multiplier);

  // Close any existing open sessions
  await supabaseAdmin
    .from('usage_sessions')
    .update({ end_time: new Date().toISOString() })
    .eq('user_id', userId)
    .is('end_time', null);

  const { data, error } = await supabaseAdmin
    .from('usage_sessions')
    .insert({
      user_id: userId,
      start_time: new Date().toISOString(),
      last_heartbeat: new Date().toISOString(),
      price_per_minute: pricePerMinute,
      currency: user.currency || 'EUR',
    })
    .select('id')
    .single();

  if (error) throw new Error('Failed to start usage session');

  // Update user price multiplier
  if (multiplier !== user.price_multiplier) {
    await supabaseAdmin
      .from('users')
      .update({ price_multiplier: multiplier })
      .eq('id', userId);
  }

  logger.info('usage_session_started', { userId, sessionId: data.id, pricePerMinute });
  return data.id;
}

// Update heartbeat for active session
export async function heartbeatSession(sessionId: string): Promise<void> {
  await supabaseAdmin
    .from('usage_sessions')
    .update({ last_heartbeat: new Date().toISOString() })
    .eq('id', sessionId)
    .is('end_time', null);
}

// End usage session
export async function endUsageSession(userId: string): Promise<void> {
  const { data: session } = await supabaseAdmin
    .from('usage_sessions')
    .select('*')
    .eq('user_id', userId)
    .is('end_time', null)
    .single();

  if (!session) return;

  const endTime = new Date();
  const startTime = new Date(session.start_time);
  const durationSeconds = Math.floor((endTime.getTime() - startTime.getTime()) / 1000);
  const minutesUsed = durationSeconds / 60;
  const amountCharged = Math.round(minutesUsed * session.price_per_minute * 10000) / 10000;

  await supabaseAdmin
    .from('usage_sessions')
    .update({
      end_time: endTime.toISOString(),
      duration_seconds: durationSeconds,
      minutes_used: minutesUsed,
      amount_charged: amountCharged,
    })
    .eq('id', session.id);

  logger.info('usage_session_ended', { sessionId: session.id, minutesUsed, amountCharged });
}

// Process all active sessions (called by credit worker every 60s)
export async function processActiveSessionsCredit(): Promise<void> {
  const now = new Date();
  const cutoff = new Date(now.getTime() - 60 * 1000); // sessions older than 60s

  // Get all active sessions with stale heartbeat (no heartbeat in 2 min = ended)
  const staleThreshold = new Date(now.getTime() - 2 * 60 * 1000);

  // Close stale sessions
  await supabaseAdmin
    .from('usage_sessions')
    .update({ end_time: now.toISOString() })
    .is('end_time', null)
    .lt('last_heartbeat', staleThreshold.toISOString());

  // Get all active sessions
  const { data: sessions } = await supabaseAdmin
    .from('usage_sessions')
    .select('id, user_id, start_time, last_heartbeat, price_per_minute, currency')
    .is('end_time', null)
    .eq('billed', false);

  if (!sessions || sessions.length === 0) return;

  for (const session of sessions) {
    try {
      const startTime = new Date(session.start_time);
      const durationSeconds = Math.floor((now.getTime() - startTime.getTime()) / 1000);
      const minutesUsed = durationSeconds / 60;
      const amountCharged = Math.round(minutesUsed * session.price_per_minute * 10000) / 10000;

      // Update session metrics
      await supabaseAdmin
        .from('usage_sessions')
        .update({
          duration_seconds: durationSeconds,
          minutes_used: minutesUsed,
          amount_charged: amountCharged,
        })
        .eq('id', session.id);

      // Deduct from user credit balance
      await supabaseAdmin.rpc('deduct_credit', {
        p_user_id: session.user_id,
        p_amount: amountCharged,
      });

    } catch (err) {
      logger.error('credit_deduction_failed', { sessionId: session.id, error: err });
    }
  }
}

// Calculate unbilled usage for billing cycle
export async function calculateUnbilledUsage(userId: string): Promise<{
  minutesUsed: number;
  totalCost: number;
  periodStart: Date;
  periodEnd: Date;
  sessions: any[];
}> {
  const { data: user } = await supabaseAdmin
    .from('users')
    .select('last_billing_timestamp, role, price_multiplier')
    .eq('id', userId)
    .single();

  const periodStart = user?.last_billing_timestamp
    ? new Date(user.last_billing_timestamp)
    : new Date(Date.now() - BILLING_CYCLE_MINUTES * 60 * 1000);
  const periodEnd = new Date();

  const { data: sessions } = await supabaseAdmin
    .from('usage_sessions')
    .select('*')
    .eq('user_id', userId)
    .eq('billed', false)
    .gte('start_time', periodStart.toISOString())
    .not('end_time', 'is', null);

  const minutesUsed = sessions?.reduce((sum, s) => sum + (s.minutes_used || 0), 0) || 0;
  const totalCost = sessions?.reduce((sum, s) => sum + (s.amount_charged || 0), 0) || 0;

  return { minutesUsed, totalCost, periodStart, periodEnd, sessions: sessions || [] };
}

// Check if user needs billing
export async function usersNeedingBilling(): Promise<string[]> {
  const cycleCutoff = new Date(Date.now() - BILLING_CYCLE_MINUTES * 60 * 1000);

  const { data } = await supabaseAdmin
    .from('users')
    .select('id')
    .eq('account_status', 'active')
    .neq('role', 'admin')
    .or(`last_billing_timestamp.is.null,last_billing_timestamp.lt.${cycleCutoff.toISOString()}`);

  return (data || []).map((u: any) => u.id);
}

// Block user for non-payment
export async function blockUser(userId: string, reason: string): Promise<void> {
  await supabaseAdmin
    .from('users')
    .update({ account_status: 'suspended' })
    .eq('id', userId);

  // Revoke all active sessions
  await supabaseAdmin
    .from('sessions')
    .update({ revoked: true, revoked_at: new Date().toISOString() })
    .eq('user_id', userId)
    .eq('revoked', false);

  // End usage sessions
  await supabaseAdmin
    .from('usage_sessions')
    .update({ end_time: new Date().toISOString() })
    .eq('user_id', userId)
    .is('end_time', null);

  logger.warn('user_blocked', { userId, reason });
}

// Reactivate user after successful payment
export async function reactivateUser(userId: string): Promise<void> {
  await supabaseAdmin
    .from('users')
    .update({ account_status: 'active' })
    .eq('id', userId);

  logger.info('user_reactivated', { userId });
}
