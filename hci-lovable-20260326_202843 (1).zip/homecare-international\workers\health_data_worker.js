// workers/health_data_worker.js
'use strict';

const cron = require('node-cron');
const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

const WORLD_BANK_URL = 'https://api.worldbank.org/v2';
const WHO_GHO_URL = 'https://ghoapi.azureedge.net/api';

// World Bank indicators mapping
const WORLD_BANK_INDICATORS = {
  'SH.STA.DIAB.ZS': 'diabetes_prevalence',
  'SH.STA.BRTC.ZS': 'birth_rate',
  'SP.DYN.CDRT.IN': 'death_rate',
  'SP.DYN.LE00.IN': 'life_expectancy',
  'SH.DYN.MORT': 'infant_mortality',
  'SH.XPD.CHEX.GD.ZS': 'health_expenditure_gdp',
  'SH.MED.PHYS.ZS': 'doctors_per_1000',
  'EN.ATM.PM25.MC.M3': 'pm25_exposure',
  'SH.PRV.SMOK': 'smoking_prevalence',
};

// WHO GHO indicators
const WHO_INDICATORS = {
  'NCD_BMI_30C': 'obesity_prevalence',
  'BP_04': 'hypertension_prevalence',
  'WHOSIS_000001': 'life_expectancy',
  'MDG_0000000001': 'infant_mortality',
  'WHS4_100': 'vaccination_coverage',
  'NCD_CCS_CardiovascularMortality': 'cardiovascular_mortality',
  'RS_198': 'road_accident_mortality',
  'UHC_INDEX_REPORTED': 'ubi_index',
};

// Static fallback dataset (WHO World Health Statistics 2023 - publicly available)
const STATIC_HEALTH_DATA = {
  'CH': { diabetes_prevalence: 5.6, hypertension_prevalence: 29.9, obesity_prevalence: 11.3, life_expectancy: 83.4, infant_mortality: 3.1, birth_rate: 10.4, death_rate: 8.6, smoking_prevalence: 20.1, doctors_per_1000: 4.3, health_expenditure_gdp: 11.3, vaccination_coverage: 97, pm25_exposure: 10.2, cardiovascular_mortality: 118, road_accident_mortality: 2.4, ubi_index: 87 },
  'DE': { diabetes_prevalence: 8.5, hypertension_prevalence: 30.7, obesity_prevalence: 22.3, life_expectancy: 81.1, infant_mortality: 3.2, birth_rate: 9.4, death_rate: 11.9, smoking_prevalence: 22.3, doctors_per_1000: 4.5, health_expenditure_gdp: 12.8, vaccination_coverage: 97, pm25_exposure: 11.4, cardiovascular_mortality: 131, road_accident_mortality: 3.7, ubi_index: 82 },
  'FR': { diabetes_prevalence: 7.3, hypertension_prevalence: 31.7, obesity_prevalence: 17.0, life_expectancy: 82.7, infant_mortality: 3.6, birth_rate: 10.9, death_rate: 9.2, smoking_prevalence: 32.4, doctors_per_1000: 3.2, health_expenditure_gdp: 11.1, vaccination_coverage: 95, pm25_exposure: 12.7, cardiovascular_mortality: 84, road_accident_mortality: 5.1, ubi_index: 81 },
  'IT': { diabetes_prevalence: 6.2, hypertension_prevalence: 30.5, obesity_prevalence: 13.0, life_expectancy: 83.2, infant_mortality: 2.7, birth_rate: 7.6, death_rate: 10.7, smoking_prevalence: 20.5, doctors_per_1000: 4.0, health_expenditure_gdp: 9.7, vaccination_coverage: 94, pm25_exposure: 15.8, cardiovascular_mortality: 101, road_accident_mortality: 5.2, ubi_index: 74 },
  'US': { diabetes_prevalence: 10.7, hypertension_prevalence: 32.5, obesity_prevalence: 36.2, life_expectancy: 78.9, infant_mortality: 5.4, birth_rate: 11.0, death_rate: 10.0, smoking_prevalence: 16.3, doctors_per_1000: 2.6, health_expenditure_gdp: 17.8, vaccination_coverage: 95, pm25_exposure: 7.4, cardiovascular_mortality: 182, road_accident_mortality: 12.4, ubi_index: 75 },
  'GB': { diabetes_prevalence: 6.7, hypertension_prevalence: 26.4, obesity_prevalence: 27.8, life_expectancy: 81.3, infant_mortality: 3.7, birth_rate: 11.1, death_rate: 9.3, smoking_prevalence: 15.4, doctors_per_1000: 3.0, health_expenditure_gdp: 10.2, vaccination_coverage: 93, pm25_exposure: 9.5, cardiovascular_mortality: 113, road_accident_mortality: 2.9, ubi_index: 79 },
  'JP': { diabetes_prevalence: 7.3, hypertension_prevalence: 30.6, obesity_prevalence: 4.3, life_expectancy: 84.3, infant_mortality: 1.8, birth_rate: 6.9, death_rate: 11.4, smoking_prevalence: 20.1, doctors_per_1000: 2.5, health_expenditure_gdp: 11.0, vaccination_coverage: 98, pm25_exposure: 11.7, cardiovascular_mortality: 72, road_accident_mortality: 3.1, ubi_index: 82 },
  'CN': { diabetes_prevalence: 10.6, hypertension_prevalence: 24.5, obesity_prevalence: 6.0, life_expectancy: 77.4, infant_mortality: 6.8, birth_rate: 10.9, death_rate: 7.3, smoking_prevalence: 27.7, doctors_per_1000: 2.0, health_expenditure_gdp: 5.7, vaccination_coverage: 99, pm25_exposure: 35.4, cardiovascular_mortality: 276, road_accident_mortality: 18.8, ubi_index: 75 },
  'BR': { diabetes_prevalence: 10.4, hypertension_prevalence: 29.4, obesity_prevalence: 22.1, life_expectancy: 75.9, infant_mortality: 13.4, birth_rate: 13.6, death_rate: 6.5, smoking_prevalence: 12.4, doctors_per_1000: 2.3, health_expenditure_gdp: 9.6, vaccination_coverage: 96, pm25_exposure: 12.3, cardiovascular_mortality: 219, road_accident_mortality: 19.7, ubi_index: 65 },
  'IN': { diabetes_prevalence: 10.4, hypertension_prevalence: 22.7, obesity_prevalence: 3.9, life_expectancy: 69.7, infant_mortality: 27.7, birth_rate: 17.8, death_rate: 7.3, smoking_prevalence: 21.1, doctors_per_1000: 0.7, health_expenditure_gdp: 3.5, vaccination_coverage: 91, pm25_exposure: 58.7, cardiovascular_mortality: 209, road_accident_mortality: 15.6, ubi_index: 57 },
  'AU': { diabetes_prevalence: 5.1, hypertension_prevalence: 22.9, obesity_prevalence: 29.0, life_expectancy: 83.0, infant_mortality: 3.1, birth_rate: 12.6, death_rate: 6.5, smoking_prevalence: 13.8, doctors_per_1000: 3.7, health_expenditure_gdp: 10.4, vaccination_coverage: 95, pm25_exposure: 7.2, cardiovascular_mortality: 98, road_accident_mortality: 5.3, ubi_index: 83 },
  'CA': { diabetes_prevalence: 7.8, hypertension_prevalence: 20.5, obesity_prevalence: 29.4, life_expectancy: 82.3, infant_mortality: 4.3, birth_rate: 9.8, death_rate: 7.7, smoking_prevalence: 13.0, doctors_per_1000: 2.7, health_expenditure_gdp: 12.9, vaccination_coverage: 93, pm25_exposure: 6.9, cardiovascular_mortality: 104, road_accident_mortality: 5.1, ubi_index: 82 },
  'ZA': { diabetes_prevalence: 13.2, hypertension_prevalence: 28.0, obesity_prevalence: 28.3, life_expectancy: 62.5, infant_mortality: 27.7, birth_rate: 20.6, death_rate: 9.9, smoking_prevalence: 21.0, doctors_per_1000: 0.9, health_expenditure_gdp: 8.1, vaccination_coverage: 84, pm25_exposure: 22.1, cardiovascular_mortality: 290, road_accident_mortality: 26.8, ubi_index: 53 },
  'NG': { diabetes_prevalence: 5.7, hypertension_prevalence: 28.9, obesity_prevalence: 8.9, life_expectancy: 55.7, infant_mortality: 74.2, birth_rate: 37.8, death_rate: 13.0, smoking_prevalence: 3.9, doctors_per_1000: 0.4, health_expenditure_gdp: 3.9, vaccination_coverage: 60, pm25_exposure: 47.0, cardiovascular_mortality: 393, road_accident_mortality: 27.2, ubi_index: 38 },
  'RU': { diabetes_prevalence: 7.4, hypertension_prevalence: 33.7, obesity_prevalence: 23.1, life_expectancy: 70.1, infant_mortality: 5.6, birth_rate: 9.6, death_rate: 13.0, smoking_prevalence: 35.4, doctors_per_1000: 3.8, health_expenditure_gdp: 5.3, vaccination_coverage: 97, pm25_exposure: 15.8, cardiovascular_mortality: 320, road_accident_mortality: 13.7, ubi_index: 66 },
  'MX': { diabetes_prevalence: 14.8, hypertension_prevalence: 26.2, obesity_prevalence: 28.9, life_expectancy: 74.1, infant_mortality: 12.3, birth_rate: 16.4, death_rate: 6.3, smoking_prevalence: 10.2, doctors_per_1000: 2.4, health_expenditure_gdp: 6.2, vaccination_coverage: 89, pm25_exposure: 20.2, cardiovascular_mortality: 206, road_accident_mortality: 15.0, ubi_index: 60 },
  'ES': { diabetes_prevalence: 7.8, hypertension_prevalence: 31.1, obesity_prevalence: 23.8, life_expectancy: 83.6, infant_mortality: 2.6, birth_rate: 7.7, death_rate: 9.9, smoking_prevalence: 27.6, doctors_per_1000: 4.4, health_expenditure_gdp: 9.0, vaccination_coverage: 97, pm25_exposure: 10.2, cardiovascular_mortality: 91, road_accident_mortality: 4.6, ubi_index: 77 },
  'SE': { diabetes_prevalence: 4.7, hypertension_prevalence: 27.1, obesity_prevalence: 20.6, life_expectancy: 82.7, infant_mortality: 2.0, birth_rate: 10.9, death_rate: 9.2, smoking_prevalence: 11.0, doctors_per_1000: 4.3, health_expenditure_gdp: 11.0, vaccination_coverage: 97, pm25_exposure: 6.5, cardiovascular_mortality: 113, road_accident_mortality: 2.2, ubi_index: 88 },
  'NO': { diabetes_prevalence: 4.9, hypertension_prevalence: 25.2, obesity_prevalence: 23.1, life_expectancy: 82.8, infant_mortality: 2.0, birth_rate: 10.4, death_rate: 7.9, smoking_prevalence: 13.3, doctors_per_1000: 5.2, health_expenditure_gdp: 10.5, vaccination_coverage: 97, pm25_exposure: 5.4, cardiovascular_mortality: 102, road_accident_mortality: 1.9, ubi_index: 89 },
  'NL': { diabetes_prevalence: 5.3, hypertension_prevalence: 29.7, obesity_prevalence: 20.4, life_expectancy: 81.9, infant_mortality: 3.1, birth_rate: 10.5, death_rate: 9.4, smoking_prevalence: 21.1, doctors_per_1000: 3.6, health_expenditure_gdp: 10.7, vaccination_coverage: 94, pm25_exposure: 11.3, cardiovascular_mortality: 96, road_accident_mortality: 3.7, ubi_index: 84 },
};

async function fetchWorldBankData(indicator, years = 3) {
  try {
    const response = await fetch(
      `${WORLD_BANK_URL}/country/all/indicator/${indicator}?format=json&mrv=${years}&per_page=500`,
      { signal: AbortSignal.timeout(15000) }
    );

    if (!response.ok) return null;
    const [meta, data] = await response.json();
    return data;
  } catch {
    return null;
  }
}

async function upsertMetricValues(metricKey, values) {
  if (!values || values.length === 0) return;

  const rows = values.map(v => ({
    metric_key: metricKey,
    geo_level: 'country',
    geo_code: v.geo_code,
    timestamp: v.timestamp,
    value: v.value,
    quality_flag: v.quality_flag || 'ok',
    trend_24h: null,
    trend_7d: null,
  }));

  const { error } = await supabase
    .from('health_metric_values')
    .upsert(rows, {
      onConflict: 'metric_key,geo_code,geo_level,timestamp',
      ignoreDuplicates: false,
    });

  if (error) console.error(`[HealthWorker] Upsert error for ${metricKey}:`, error.message);
}

async function loadStaticFallback() {
  console.log('[HealthWorker] Loading static fallback health dataset...');
  const metrics = Object.keys(Object.values(STATIC_HEALTH_DATA)[0]);
  const timestamp = new Date('2023-01-01').toISOString();
  const now = new Date();

  for (const metricKey of metrics) {
    const values = [];
    for (const [countryCode, data] of Object.entries(STATIC_HEALTH_DATA)) {
      if (data[metricKey] !== undefined) {
        values.push({
          geo_code: countryCode,
          timestamp,
          value: data[metricKey],
          quality_flag: 'ok',
        });
      }
    }

    await upsertMetricValues(metricKey, values);
    console.log(`[HealthWorker] Loaded static data for ${metricKey}: ${values.length} countries`);
  }
}

async function fetchAndStoreWorldBankIndicators() {
  console.log('[HealthWorker] Fetching World Bank data...');

  for (const [wbIndicator, metricKey] of Object.entries(WORLD_BANK_INDICATORS)) {
    try {
      const data = await fetchWorldBankData(wbIndicator);
      if (!data) {
        console.warn(`[HealthWorker] No data for ${wbIndicator}, using static fallback`);
        continue;
      }

      const values = [];
      for (const item of data) {
        if (!item.countryiso3code || item.value === null) continue;

        // Convert ISO3 to ISO2 lookup
        const { data: country } = await supabase
          .from('countries')
          .select('country_code')
          .eq('iso3', item.countryiso3code)
          .single();

        if (!country) continue;

        values.push({
          geo_code: country.country_code,
          timestamp: new Date(`${item.date}-01-01`).toISOString(),
          value: parseFloat(item.value),
          quality_flag: 'ok',
        });
      }

      await upsertMetricValues(metricKey, values);
      console.log(`[HealthWorker] Stored ${values.length} values for ${metricKey}`);

      // Rate limiting
      await new Promise(r => setTimeout(r, 500));

    } catch (err) {
      console.error(`[HealthWorker] Error fetching ${wbIndicator}:`, err.message);
    }
  }
}

async function calculateTrends() {
  console.log('[HealthWorker] Calculating trends...');

  // Get all metrics
  const { data: metrics } = await supabase.from('health_metrics').select('metric_key');

  for (const { metric_key } of metrics || []) {
    // Get all countries for this metric
    const { data: countries } = await supabase
      .from('countries')
      .select('country_code');

    for (const { country_code } of countries || []) {
      const { data: values } = await supabase
        .from('health_metric_values')
        .select('id, value, timestamp')
        .eq('metric_key', metric_key)
        .eq('geo_code', country_code)
        .order('timestamp', { ascending: false })
        .limit(5);

      if (!values || values.length < 2) continue;

      const latest = values[0].value;
      const previous = values[1]?.value;

      const trend7d = previous !== undefined ? ((latest - previous) / Math.abs(previous)) * 100 : null;

      await supabase
        .from('health_metric_values')
        .update({ trend_7d: trend7d })
        .eq('id', values[0].id);
    }
  }
}

async function runHealthDataRefresh() {
  const now = new Date();
  console.log(`[HealthWorker] Starting health data refresh at ${now.toISOString()}`);

  try {
    // Try World Bank API first
    await fetchAndStoreWorldBankIndicators();

    // Always ensure static data is present as fallback
    await loadStaticFallback();

    // Calculate trends
    await calculateTrends();

    await supabase.from('logs').insert({
      level: 'info',
      category: 'health_data_refresh_completed',
      message: 'Health data refresh completed',
      metadata: { timestamp: now.toISOString() },
    });

    console.log('[HealthWorker] Health data refresh completed successfully');

  } catch (err) {
    console.error('[HealthWorker] Error during refresh:', err);
    // Load static fallback on any error
    await loadStaticFallback();
  }
}

// Run daily at 3 AM
cron.schedule('0 3 * * *', runHealthDataRefresh);

// Run on startup to ensure data is present
runHealthDataRefresh();

console.log('[HealthWorker] Started - will refresh health data daily at 3 AM');

process.on('SIGTERM', () => {
  console.log('[HealthWorker] Shutting down...');
  process.exit(0);
});
