// backend/payments/stripe_engine.ts
import Stripe from 'stripe';
import { supabaseAdmin } from '../lib/db';
import { logger } from '../lib/logger';
import { reactivateUser, blockUser } from '../billing/billing_engine';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-06-20',
});

export { stripe };

// Create or retrieve Stripe customer
export async function ensureStripeCustomer(userId: string): Promise<string> {
  const { data: user } = await supabaseAdmin
    .from('users')
    .select('id, email, stripe_customer_id, role')
    .eq('id', userId)
    .single();

  if (!user) throw new Error('User not found');

  if (user.stripe_customer_id) {
    try {
      // Verify customer still exists in Stripe
      await stripe.customers.retrieve(user.stripe_customer_id);
      return user.stripe_customer_id;
    } catch {
      // Customer deleted in Stripe, create new one
    }
  }

  const customer = await stripe.customers.create({
    email: user.email,
    metadata: {
      userId: user.id,
      role: user.role,
      platform: 'homecareinternational',
    },
  });

  await supabaseAdmin
    .from('users')
    .update({ stripe_customer_id: customer.id })
    .eq('id', userId);

  logger.info('stripe_customer_created', { userId, customerId: customer.id });
  return customer.id;
}

// Save payment method to customer
export async function savePaymentMethod(
  userId: string,
  paymentMethodId: string
): Promise<void> {
  const customerId = await ensureStripeCustomer(userId);

  await stripe.paymentMethods.attach(paymentMethodId, { customer: customerId });
  await stripe.customers.update(customerId, {
    invoice_settings: { default_payment_method: paymentMethodId },
  });

  await supabaseAdmin
    .from('users')
    .update({ stripe_payment_method: paymentMethodId })
    .eq('id', userId);

  logger.info('payment_method_saved', { userId, paymentMethodId });
}

// Charge customer automatically
export async function chargeCustomer(
  userId: string,
  amountEUR: number,
  invoiceId: string,
  description: string
): Promise<{ success: boolean; paymentIntentId?: string; error?: string }> {
  try {
    const { data: user } = await supabaseAdmin
      .from('users')
      .select('stripe_customer_id, stripe_payment_method, email, currency')
      .eq('id', userId)
      .single();

    if (!user?.stripe_customer_id || !user?.stripe_payment_method) {
      return { success: false, error: 'No payment method on file' };
    }

    // Convert to cents
    const amountCents = Math.round(amountEUR * 100);
    if (amountCents < 50) {
      // Minimum charge 50 cents - accumulate until threshold
      return { success: true }; // Skip tiny charges
    }

    const paymentIntent = await stripe.paymentIntents.create({
      amount: amountCents,
      currency: (user.currency || 'EUR').toLowerCase(),
      customer: user.stripe_customer_id,
      payment_method: user.stripe_payment_method,
      off_session: true,
      confirm: true,
      description,
      metadata: {
        userId,
        invoiceId,
        platform: 'homecareinternational',
      },
    });

    if (paymentIntent.status === 'succeeded') {
      // Record payment
      await supabaseAdmin.from('payments').insert({
        user_id: userId,
        invoice_id: invoiceId,
        provider: 'stripe',
        status: 'succeeded',
        amount: amountEUR,
        currency: user.currency || 'EUR',
        stripe_payment_intent_id: paymentIntent.id,
        transaction_id: paymentIntent.id,
      });

      logger.info('payment_succeeded', { userId, invoiceId, amount: amountEUR });
      return { success: true, paymentIntentId: paymentIntent.id };
    }

    return { success: false, error: `Payment status: ${paymentIntent.status}` };

  } catch (err: any) {
    const errorCode = err.code || 'unknown';
    const errorMsg = err.message || 'Payment failed';

    // Record failed payment
    await supabaseAdmin.from('payments').insert({
      user_id: userId,
      invoice_id: invoiceId,
      provider: 'stripe',
      status: 'failed',
      amount: amountEUR,
      error_code: errorCode,
      error_message: errorMsg,
    });

    logger.error('payment_failed', { userId, invoiceId, error: errorMsg, code: errorCode });
    return { success: false, error: errorMsg };
  }
}

// Create setup intent for saving card
export async function createSetupIntent(userId: string): Promise<string> {
  const customerId = await ensureStripeCustomer(userId);

  const setupIntent = await stripe.setupIntents.create({
    customer: customerId,
    payment_method_types: ['card'],
    usage: 'off_session',
    metadata: { userId },
  });

  return setupIntent.client_secret!;
}

// Get customer payment methods
export async function getPaymentMethods(userId: string): Promise<Stripe.PaymentMethod[]> {
  const { data: user } = await supabaseAdmin
    .from('users')
    .select('stripe_customer_id')
    .eq('id', userId)
    .single();

  if (!user?.stripe_customer_id) return [];

  const methods = await stripe.paymentMethods.list({
    customer: user.stripe_customer_id,
    type: 'card',
  });

  return methods.data;
}

// Handle Stripe webhook events
export async function handleStripeWebhook(
  payload: string,
  signature: string
): Promise<void> {
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET!;
  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(payload, signature, webhookSecret);
  } catch (err) {
    throw new Error(`Webhook signature verification failed: ${err}`);
  }

  // Idempotency check
  const { data: existing } = await supabaseAdmin
    .from('webhook_events')
    .select('id')
    .eq('event_id', event.id)
    .eq('provider', 'stripe')
    .single();

  if (existing) {
    logger.info('webhook_duplicate_skipped', { eventId: event.id });
    return;
  }

  // Store event
  await supabaseAdmin.from('webhook_events').insert({
    provider: 'stripe',
    event_id: event.id,
    event_type: event.type,
    payload: event as any,
  });

  try {
    switch (event.type) {
      case 'payment_intent.succeeded':
        await handlePaymentSucceeded(event.data.object as Stripe.PaymentIntent);
        break;

      case 'payment_intent.payment_failed':
        await handlePaymentFailed(event.data.object as Stripe.PaymentIntent);
        break;

      case 'invoice.payment_succeeded':
        await handleInvoicePaymentSucceeded(event.data.object as Stripe.Invoice);
        break;

      case 'invoice.payment_failed':
        await handleInvoicePaymentFailed(event.data.object as Stripe.Invoice);
        break;

      case 'customer.subscription.deleted':
      case 'customer.subscription.updated':
        await handleSubscriptionUpdate(event.data.object as Stripe.Subscription);
        break;

      case 'setup_intent.succeeded':
        logger.info('setup_intent_succeeded', { id: (event.data.object as any).id });
        break;
    }

    // Mark as processed
    await supabaseAdmin
      .from('webhook_events')
      .update({ processed: true, processed_at: new Date().toISOString() })
      .eq('event_id', event.id)
      .eq('provider', 'stripe');

  } catch (err: any) {
    await supabaseAdmin
      .from('webhook_events')
      .update({ error: err.message })
      .eq('event_id', event.id)
      .eq('provider', 'stripe');

    logger.error('webhook_processing_failed', { eventId: event.id, error: err.message });
    throw err;
  }
}

async function handlePaymentSucceeded(paymentIntent: Stripe.PaymentIntent): Promise<void> {
  const { userId, invoiceId } = paymentIntent.metadata;
  if (!userId) return;

  // Update invoice status
  if (invoiceId) {
    await supabaseAdmin
      .from('invoices')
      .update({
        status: 'paid',
        paid_at: new Date().toISOString(),
        stripe_payment_id: paymentIntent.id,
      })
      .eq('id', invoiceId);
  }

  // Update payment record
  await supabaseAdmin
    .from('payments')
    .update({ status: 'succeeded' })
    .eq('stripe_payment_intent_id', paymentIntent.id);

  // Reactivate user if was suspended
  const { data: user } = await supabaseAdmin
    .from('users')
    .select('account_status')
    .eq('id', userId)
    .single();

  if (user?.account_status === 'suspended') {
    await reactivateUser(userId);
  }
}

async function handlePaymentFailed(paymentIntent: Stripe.PaymentIntent): Promise<void> {
  const { userId, invoiceId } = paymentIntent.metadata;
  if (!userId) return;

  if (invoiceId) {
    await supabaseAdmin
      .from('invoices')
      .update({ status: 'failed' })
      .eq('id', invoiceId);
  }

  await blockUser(userId, `Payment failed: ${paymentIntent.last_payment_error?.message}`);
}

async function handleInvoicePaymentSucceeded(invoice: Stripe.Invoice): Promise<void> {
  const customerId = invoice.customer as string;
  const { data: user } = await supabaseAdmin
    .from('users')
    .select('id, account_status')
    .eq('stripe_customer_id', customerId)
    .single();

  if (!user) return;
  if (user.account_status === 'suspended') await reactivateUser(user.id);
}

async function handleInvoicePaymentFailed(invoice: Stripe.Invoice): Promise<void> {
  const customerId = invoice.customer as string;
  const { data: user } = await supabaseAdmin
    .from('users')
    .select('id')
    .eq('stripe_customer_id', customerId)
    .single();

  if (!user) return;
  await blockUser(user.id, 'Stripe invoice payment failed');
}

async function handleSubscriptionUpdate(subscription: Stripe.Subscription): Promise<void> {
  await supabaseAdmin
    .from('subscriptions')
    .update({
      status: subscription.status === 'active' ? 'active' : 'past_due',
      current_period_start: new Date((subscription as any).current_period_start * 1000).toISOString(),
      current_period_end: new Date((subscription as any).current_period_end * 1000).toISOString(),
    })
    .eq('stripe_sub_id', subscription.id);
}
