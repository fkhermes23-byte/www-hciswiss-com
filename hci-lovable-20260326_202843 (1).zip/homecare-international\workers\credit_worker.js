// workers/credit_worker.js
'use strict';

const cron = require('node-cron');
const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

async function processCredits() {
  const now = new Date();
  console.log(`[CreditWorker] Running at ${now.toISOString()}`);

  try {
    // 1. Close stale sessions (no heartbeat in 3 minutes)
    const staleThreshold = new Date(now.getTime() - 3 * 60 * 1000).toISOString();
    const { data: staleSessions } = await supabase
      .from('usage_sessions')
      .select('id, user_id, start_time, price_per_minute')
      .is('end_time', null)
      .lt('last_heartbeat', staleThreshold);

    for (const session of staleSessions || []) {
      const durationSeconds = Math.floor((now.getTime() - new Date(session.start_time).getTime()) / 1000);
      const minutesUsed = durationSeconds / 60;
      const amountCharged = Math.round(minutesUsed * session.price_per_minute * 10000) / 10000;

      await supabase
        .from('usage_sessions')
        .update({
          end_time: now.toISOString(),
          duration_seconds: durationSeconds,
          minutes_used: minutesUsed,
          amount_charged: amountCharged,
        })
        .eq('id', session.id);

      console.log(`[CreditWorker] Closed stale session ${session.id}: ${minutesUsed.toFixed(2)} min, €${amountCharged}`);
    }

    // 2. Update all active sessions
    const { data: activeSessions } = await supabase
      .from('usage_sessions')
      .select('id, user_id, start_time, last_heartbeat, price_per_minute, currency')
      .is('end_time', null);

    for (const session of activeSessions || []) {
      const startTime = new Date(session.start_time);
      const durationSeconds = Math.floor((now.getTime() - startTime.getTime()) / 1000);
      const minutesUsed = durationSeconds / 60;
      const amountCharged = Math.round(minutesUsed * session.price_per_minute * 10000) / 10000;

      await supabase
        .from('usage_sessions')
        .update({
          duration_seconds: durationSeconds,
          minutes_used: minutesUsed,
          amount_charged: amountCharged,
          last_heartbeat: now.toISOString(),
        })
        .eq('id', session.id);
    }

    // 3. Check credit balances and suspend users with no credits and no payment method
    const { data: lowCreditUsers } = await supabase
      .from('users')
      .select('id, credit_balance, stripe_payment_method, paypal_customer_id, account_status')
      .eq('account_status', 'active')
      .neq('role', 'admin')
      .lte('credit_balance', 0);

    for (const user of lowCreditUsers || []) {
      const hasPaymentMethod = user.stripe_payment_method || user.paypal_customer_id;

      if (!hasPaymentMethod) {
        // No payment method and no credits - suspend
        await supabase
          .from('users')
          .update({ account_status: 'suspended' })
          .eq('id', user.id);

        // Revoke sessions
        await supabase
          .from('sessions')
          .update({ revoked: true, revoked_at: now.toISOString() })
          .eq('user_id', user.id)
          .eq('revoked', false);

        // End usage sessions
        await supabase
          .from('usage_sessions')
          .update({ end_time: now.toISOString() })
          .eq('user_id', user.id)
          .is('end_time', null);

        console.log(`[CreditWorker] Suspended user ${user.id} - no credits, no payment method`);

        // Log
        await supabase.from('logs').insert({
          level: 'warn',
          category: 'user_suspended_no_credits',
          message: `User suspended: no credits and no payment method`,
          user_id: user.id,
          metadata: { credit_balance: user.credit_balance },
        });
      }
    }

    // 4. Update monthly usage tracking
    const { data: activeUsers } = await supabase
      .from('users')
      .select('id, monthly_usage_reset_at')
      .eq('account_status', 'active');

    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

    for (const user of activeUsers || []) {
      const resetAt = user.monthly_usage_reset_at ? new Date(user.monthly_usage_reset_at) : null;
      if (!resetAt || resetAt < monthStart) {
        // Reset monthly counter
        await supabase
          .from('users')
          .update({
            monthly_usage_minutes: 0,
            monthly_usage_reset_at: now.toISOString(),
            price_multiplier: 1.0,
          })
          .eq('id', user.id);
      }
    }

    console.log(`[CreditWorker] Completed. Active: ${activeSessions?.length || 0}, Stale closed: ${staleSessions?.length || 0}`);

  } catch (err) {
    console.error('[CreditWorker] Error:', err);
    await supabase.from('logs').insert({
      level: 'error',
      category: 'credit_worker_error',
      message: err.message || 'Credit worker failed',
      metadata: { stack: err.stack },
    });
  }
}

// Run every 60 seconds
cron.schedule('* * * * *', processCredits);

// Also run immediately on start
processCredits();

console.log('[CreditWorker] Started - running every 60 seconds');

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('[CreditWorker] Shutting down gracefully...');
  process.exit(0);
});
