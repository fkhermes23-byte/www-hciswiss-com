// app/api/webhooks/crypto/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { handleCryptoWebhook, verifyCryptoWebhook } from '@/backend/payments/crypto_engine';
import { logger } from '@/backend/lib/logger';

export async function POST(req: NextRequest) {
  try {
    const rawBody = await req.text();
    const signature = req.headers.get('x-cc-webhook-signature') || '';

    if (!verifyCryptoWebhook(rawBody, signature)) {
      logger.warn('crypto_webhook_invalid_signature');
      return NextResponse.json({ error: 'Invalid signature' }, { status: 400 });
    }

    const event = JSON.parse(rawBody);
    await handleCryptoWebhook(event);
    return NextResponse.json({ received: true });
  } catch (err: any) {
    logger.error('crypto_webhook_error', { error: err.message });
    return NextResponse.json({ error: 'Webhook processing failed' }, { status: 500 });
  }
}
