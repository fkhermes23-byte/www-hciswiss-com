// app/api/subscription/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/backend/auth/auth';
import { supabaseAdmin } from '@/backend/lib/db';
import { chargeCustomer } from '@/backend/payments/stripe_engine';
import { logger } from '@/backend/lib/logger';

const SUBSCRIPTION_PRICES: Record<string, Record<string, number>> = {
  daily:   { private: 3.60,  professional: 7.20,  enterprise: 10.80 },
  weekly:  { private: 21.00, professional: 42.00, enterprise: 63.00 },
  monthly: { private: 72.00, professional: 144.00, enterprise: 216.00 },
  annual:  { private: 720.00, professional: 1440.00, enterprise: 2160.00 },
};

export async function GET(req: NextRequest) {
  try {
    const user = await requireAuth(req);
    const { data: sub } = await supabaseAdmin
      .from('subscriptions')
      .select('*')
      .eq('user_id', user.id)
      .eq('status', 'active')
      .order('created_at', { ascending: false })
      .limit(1)
      .single();
    return NextResponse.json({ subscription: sub });
  } catch (err: any) {
    if (err.message === 'UNAUTHORIZED') return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    return NextResponse.json({ subscription: null });
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await requireAuth(req);
    const { plan } = await req.json();

    if (!SUBSCRIPTION_PRICES[plan]) {
      return NextResponse.json({ error: 'Invalid plan' }, { status: 400 });
    }

    const { data: userData } = await supabaseAdmin
      .from('users')
      .select('role, currency')
      .eq('id', user.id)
      .single();

    const price = SUBSCRIPTION_PRICES[plan][userData?.role || 'private'];
    const taxAmount = Math.round(price * 0.077 * 100) / 100;
    const totalAmount = Math.round((price + taxAmount) * 100) / 100;

    // Calculate end date
    const startDate = new Date();
    const endDate = new Date();
    switch (plan) {
      case 'daily':   endDate.setDate(endDate.getDate() + 1); break;
      case 'weekly':  endDate.setDate(endDate.getDate() + 7); break;
      case 'monthly': endDate.setMonth(endDate.getMonth() + 1); break;
      case 'annual':  endDate.setFullYear(endDate.getFullYear() + 1); break;
    }

    // Create invoice
    const { data: invoice } = await supabaseAdmin.from('invoices').insert({
      user_id: user.id,
      amount: price,
      tax_amount: taxAmount,
      total_amount: totalAmount,
      currency: userData?.currency || 'EUR',
      status: 'pending',
      payment_provider: 'stripe',
      line_items: [{ description: `${plan} subscription`, amount: price }],
    }).select().single();

    if (!invoice) return NextResponse.json({ error: 'Failed to create invoice' }, { status: 500 });

    // Charge
    const result = await chargeCustomer(user.id, totalAmount, invoice.id, `${plan} subscription`);

    if (!result.success) {
      await supabaseAdmin.from('invoices').update({ status: 'failed' }).eq('id', invoice.id);
      return NextResponse.json({ error: result.error || 'Payment failed' }, { status: 402 });
    }

    await supabaseAdmin.from('invoices').update({ status: 'paid', paid_at: new Date().toISOString() }).eq('id', invoice.id);

    // Create subscription record
    const { data: sub } = await supabaseAdmin.from('subscriptions').insert({
      user_id: user.id,
      plan_type: plan,
      status: 'active',
      price: price,
      currency: userData?.currency || 'EUR',
      start_date: startDate.toISOString(),
      end_date: endDate.toISOString(),
      current_period_start: startDate.toISOString(),
      current_period_end: endDate.toISOString(),
    }).select().single();

    // Update user subscription status
    await supabaseAdmin.from('users').update({
      subscription_type: plan,
      subscription_status: 'active',
    }).eq('id', user.id);

    logger.info('subscription_created', { userId: user.id, plan, totalAmount });
    return NextResponse.json({ success: true, subscription: sub });

  } catch (err: any) {
    if (err.message === 'UNAUTHORIZED') return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
