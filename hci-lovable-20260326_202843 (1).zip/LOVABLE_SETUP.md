# 🚀 LOVABLE SETUP — PROMPT OMEGA HCI

## Importare il Progetto in Lovable

### **Opzione 1: Clonare e Importare** (Consigliato)

```bash
# 1. Da command line nel tuo workspace
cd homecare-international

# 2. Valida che tutto sia pronto
npm install
npm run build
npm run dev

# 3. Esporta il progetto in Lovable
# Vai su https://lovable.dev e crea nuovo progetto
# Seleziona "Import from Git" o "Upload Code"
# Carica la cartella: homecare-international/
```

---

## 📦 Struttura Progetto (Ottimizzato per Lovable)

```
homecare-international/
├── app/                      ← Next.js 14 pages (TSX)
│   ├── api/                  ← Backend API routes
│   ├── auth/                 ← Authentication flows
│   ├── dashboard/            ← Main UI
│   ├── billing/              ← Billing dashboard
│   ├── global-health/        ← Health monitoring (Cesium 3D)
│   ├── layout.tsx
│   ├── page.tsx
│   └── globals.css
├── backend/                  ← Node.js services (API, workers, auth)
│   ├── api/
│   ├── workers/              ← Background jobs
│   ├── billing/
│   ├── payments/
│   ├── invoices/
│   ├── auth/
│   └── lib/
├── database/
│   └── schema.sql            ← PostgreSQL (Supabase)
├── workers/                  ← Async workers
│   ├── billing_worker.js
│   ├── credit_worker.js
│   ├── health_data_worker.js
│   └── index.js
├── .env.example              ← COPY THIS & RENAME TO .env
├── .prettierrc.json
├── .eslintrc.json
├── .gitignore
├── next.config.ts
├── tailwind.config.ts
├── tsconfig.json
├── package.json              ← All deps unified ✅
├── DEPLOY.md                 ← Vercel deployment
├── Dockerfile
└── vercel.json
```

---

## ⚙️ Variabili d'Ambiente (.env)

**Copia `.env.example` → `.env` e compila:**

```bash
# Supabase
NEXT_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
SUPABASE_SERVICE_ROLE_KEY=eyJ...

# Stripe
STRIPE_PUBLIC_KEY=pk_live_...
STRIPE_SECRET_KEY=sk_live_...
STRIPE_WEBHOOK_SECRET=whsec_...

# PayPal
PAYPAL_CLIENT_ID=...
PAYPAL_CLIENT_SECRET=...

# SMTP Email
SMTP_HOST=smtp.example.com
SMTP_PORT=587
SMTP_USER=...
SMTP_PASS=...
EMAIL_FROM=noreply@homecareinternational.ch

# App
NODE_ENV=development
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

---

## 🎯 Quick Start in Lovable

### 1️⃣ **Installa Dipendenze**
```bash
npm install
```

### 2️⃣ **Setup Database**
```bash
# Vai a Supabase → SQL Editor
# Copia-incolla: database/schema.sql
# Esegui migrations
```

### 3️⃣ **Avvia Dev Server**
```bash
npm run dev
# Apri http://localhost:3000
```

### 4️⃣ **Build Produzione**
```bash
npm run build
npm start
```

---

## 🔑 Componenti Chiave

### **Frontend (React/Next.js)**
- ✅ **TypeScript** per type safety
- ✅ **Tailwind CSS** per styling
- ✅ **Framer Motion** per animazioni
- ✅ **Lucide Icons** per UI
- ✅ **Zustand** per state management
- ✅ **SWR** per data fetching
- ✅ **Recharts** per grafici

### **Backend (Node.js)**
- ✅ **Supabase PostgreSQL** per DB
- ✅ **Stripe + PayPal** per pagamenti
- ✅ **Workers** per async jobs (billing, crediti, health data)
- ✅ **Authentication** JWT-based
- ✅ **Audit logging** (immutabile)

### **Mapping 3D**
- ✅ **Cesium.js** per mappe 3D healthcare
- ✅ **Resium** per React wrapper

---

## 📝 File Importanti

| File | Descrizione |
|------|------------|
| `package.json` | ✅ Dipendenze unificate (Node >=18) |
| `.env.example` | Template variabili (mai committare .env!) |
| `.eslintrc.json` | Linting rules |
| `.prettierrc.json` | Formatting |
| `tsconfig.json` | TypeScript config |
| `next.config.ts` | Next.js config |
| `tailwind.config.ts` | Tailwind config |
| `DEPLOY.md` | Deploy su Vercel |
| `Dockerfile` | Container image |

---

## 🚀 Deploy (Post-Sviluppo)

### **Vercel (Consigliato)**
```bash
# 1. Installa Vercel CLI
npm i -g vercel

# 2. Deploy
vercel deploy

# 3. Configura env vars in Vercel dashboard
```

### **Docker**
```bash
docker build -t hci-app .
docker run -p 3000:3000 hci-app
```

### **Self-hosted**
```bash
npm run build
npm start
```

---

## ✅ Checklist Pre-Lovable

- [ ] Copia `.env.example` → `.env`
- [ ] Compila variabili d'ambiente reali
- [ ] `npm install` senza errori
- [ ] `npm run build` compila
- [ ] `npm run dev` avvia senza errors
- [ ] Hai credenziali Supabase, Stripe, SMTP
- [ ] Database schema.sql applicato su Supabase
- [ ] Workers configurati (optional per MVP)

---

## 📚 Risorse

- **Next.js Docs**: https://nextjs.org/docs
- **Tailwind Docs**: https://tailwindcss.com/docs
- **Supabase**: https://supabase.com/docs
- **Stripe**: https://stripe.com/docs
- **Cesium**: https://cesiumjs.org/docs/

---

## 🆘 Troubleshooting

**Port 3000 occupata?**
```bash
npm run dev -- -p 3001
```

**Node version mismatch?**
```bash
node --version
# Deve essere >=18.0.0
```

**Dipendenze non installate?**
```bash
rm -rf node_modules package-lock.json
npm install
```

**Next.js build lento?**
```bash
# Cancella cache
rm -rf .next
npm run build
```

---

**Sei pronto per Lovable! 🎉**

Carica il progetto e inizia a fare deploy in minuti.
